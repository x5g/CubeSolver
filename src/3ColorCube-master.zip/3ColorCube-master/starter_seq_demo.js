function show_starter_seq() {
document.write("<table class=tabdata3 style=\"border-collapse:collapse;border:1px solid black;\" border=1>\
 <tr>\
  <td style=text-align:center> Solve 2 <br>\
   <iframe width=86 height=86 scrolling=no frameborder=0\
    src=\"cube.html?config=small.cfg&initrevmove=%23&move=RD2RD2R&facelets=rlrlrlrlrrlrlrlrlrllllllllllllllllllllllllllllllllllll\">\
   </iframe>\
   <br> S1\
  </td>\
  <td style=text-align:center> Solve 4 <br>\
   <iframe width=86 height=86 scrolling=no frameborder=0\
    src=\"cube.html?config=small.cfg&initrevmove=%23&move=R2D2R&facelets=rlrlrlrlrrlrlrlrlrllllllllllllllllllllllllllllllllllll\">\
   </iframe>\
   <br> S2\
  </td>\
 </tr>\
</table>\
<br>\
<table class=tabdata2 style=\"border-collapse:collapse; border:1px solid black;\" border=1><tr><td>\
<table class=tabdata2 style=border-collapse:collapse border=0>\
 <tr>\
  <td colspan=3 style=text-align:center> Make S1 </td>\
 </tr>\
 <tr>\
  <td style=text-align:center>\
   <iframe width=86 height=86 scrolling=no frameborder=0\
    src=\"cube.html?config=small.cfg&initrevmove=B2'R'D2RD2R&move=B2'R2'&facelets=rlrlrlrlrrlrlrlrlrllllllllllllllllllllllllllllllllllll\">\
   </iframe>\
   <br> M1\
  </td>\
  <td style=text-align:center>\
   <iframe width=86 height=86 scrolling=no frameborder=0\
    src=\"cube.html?config=small.cfg&position=lluuu&initrevmove=R2'F'R'DR&move=R2'U'R2'&facelets=rlrlrlrlrrlrlrlrlrllllllllllllllllllllllllllllllllllll\">\
   </iframe>\
   <br> M2\
  </td>\
 </tr>\
</table>\
</td><td>\
<table class=tabdata2 style=border-collapse:collapse border=0>\
 <tr>\
  <td colspan=5 style=text-align:center> Make S2 </td>\
 </tr>\
 <tr>\
  <td style=text-align:center>\
   <iframe width=86 height=86 scrolling=no frameborder=0\
    src=\"cube.html?config=small.cfg&initrevmove=FDF'R2D2R&move=FDF'&facelets=rlrlrlrlrrlrlrlrlrllllllllllllllllllllllllllllllllllll\">\
   </iframe>\
   <br> M3\
  </td>\
  <td style=text-align:center>\
   <iframe width=86 height=86 scrolling=no frameborder=0\
    src=\"cube.html?config=small.cfg&position=lluuu&initrevmove=FD'F'R2D2R&move=FD'F'&facelets=rlrlrlrlrrlrlrlrlrllllllllllllllllllllllllllllllllllll\">\
   </iframe>\
   <br> M4\
  </td>\
  <td style=text-align:center>\
   <iframe width=86 height=86 scrolling=no frameborder=0\
    src=\"cube.html?config=small.cfg&position=lluuu&initrevmove=R'DRF2'D2F&move=R'DRZ&facelets=rlrlrlrlrrlrlrlrlrllllllllllllllllllllllllllllllllllll\">\
   </iframe>\
   <br> M5\
  </td>\
 </tr>\
</table>\
</td></tr></table>");
}
