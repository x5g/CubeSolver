function show_starter_seq() {
document.write("<table border=0>\
 <tr><td colspan=5 style=text-align:center> Solve Sequences </td></tr>\
 <tr><td style=text-align:center>Solve 2</td><td><td style=text-align:center>Solve 4</td></tr>\
 <tr>\
  <td>\
   <iframe width=100 height=100 scrolling=no frameborder=0\
    src=\"cube.html?config=small.cfg&initrevmove=%23&move=RD2RD2R&facelets=rlrlrlrlrrlrlrlrlrllllllllllllllllllllllllllllllllllll\">\
   </iframe>\
  </td>\
  <td width=40>\
  <td>\
   <iframe width=100 height=100 scrolling=no frameborder=0\
    src=\"cube.html?config=small.cfg&initrevmove=%23&move=R2D2R&facelets=rlrlrlrlrrlrlrlrlrllllllllllllllllllllllllllllllllllll\">\
   </iframe> \
  </td>\
 </tr>\
 <tr height=10>\
 <tr><td colspan=5 style=text-align:center> Make Setup </td></tr>\
 <tr>\
  <td>\
   <iframe width=100 height=100 scrolling=no frameborder=0\
    src=\"cube.html?config=small.cfg&initrevmove=B2'R'D2RD2R&move=B2'R2'&facelets=rlrlrlrlrrlrlrlrlrllllllllllllllllllllllllllllllllllll\">\
   </iframe>\
  </td>\
  <td width=40>\
  <td>\
   <iframe width=100 height=100 scrolling=no frameborder=0\
    src=\"cube.html?config=small.cfg&position=lluuu&initrevmove=R2'F'R'DR&move=R2'U'R2'&facelets=rlrlrlrlrrlrlrlrlrllllllllllllllllllllllllllllllllllll\">\
   </iframe>\
  </td>\
 </tr>\
 <tr>\
  <td colspan=5 style=text-align:center>\
   <iframe width=100 height=100 scrolling=no frameborder=0\
    src=\"cube.html?config=small.cfg&initrevmove=FDF'R2D2R&move=FDF'&facelets=rlrlrlrlrrlrlrlrlrllllllllllllllllllllllllllllllllllll\">\
   </iframe>\
  </td>\
 </tr>\
 <tr>\
  <td>\
   <iframe width=100 height=100 scrolling=no frameborder=0\
    src=\"cube.html?config=small.cfg&position=lluuu&initrevmove=FD'F'R2D2R&move=FD'F'&facelets=rlrlrlrlrrlrlrlrlrllllllllllllllllllllllllllllllllllll\">\
   </iframe>\
  </td>\
  <td width=40>\
  <td>\
   <iframe width=100 height=100 scrolling=no frameborder=0\
    src=\"cube.html?config=small.cfg&position=lluuu&initrevmove=R'DRF2'D2F&move=R'DRZ&facelets=rlrlrlrlrrlrlrlrlrllllllllllllllllllllllllllllllllllll\">\
   </iframe>\
  </td>\
 </tr>\
</table>");
}
