function show_edge_seq() {
document.write("<table border=0>\
 <tr><td colspan=5 style=text-align:center> Edge Sequences </td></tr>\
 <tr height=10>\
 <tr><td style=text-align:center>Solve 4</td><td><td style=text-align:center>Solve 2</td></tr>\
 <tr>\
  <td>\
   <iframe width=100 height=100 scrolling=no frameborder=0\
    src=\"cube.html?config=medium.cfg&initrevmove=%23&move=R'Um2'R&colorscheme=rryybb\">\
   </iframe>\
  </td>\
  <td width=40>\
  <td>\
   <iframe width=100 height=100 scrolling=no frameborder=0\
    src=\"cube.html?config=medium.cfg&initrevmove=%23&move=R'Um'R2'UmR&colorscheme=rryybb\">\
   </iframe>\
  </td>\
 </tr>\
 <tr height=20>\
 <tr>\
  <td>\
   <iframe width=100 height=100 scrolling=no frameborder=0\
    src=\"cube.html?config=medium.cfg&initrevmove=%23&move=R'UmL'D2LUm'R&colorscheme=rryybb\">\
   </iframe>\
  </td>\
  <td width=40>\
  <td>\
   <iframe width=100 height=100 scrolling=no frameborder=0\
    src=\"cube.html?config=medium.cfg&initrevmove=%23&move=R'UmLD2L'Um'R&colorscheme=rryybb\">\
   </iframe>\
  </td>\
 </tr>\
</table>");
}
