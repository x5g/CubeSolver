# 3ColorCube

The world's easiest cube solving method!
