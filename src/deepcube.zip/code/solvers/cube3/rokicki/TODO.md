Things to consider improving:

* Make phase1, phase2, twophase, hcoset with with ATM
* Improve nxopt table creation esp. in ATM by doing (e.g.) U2 then U1,
  D2 then D1, so we only do four 'moves' instead of 15 for each axis.
