Sources for Coset Solver and Two-Phase Solver

These are the sources for the proof of God's number for the
3x3x3 Rubik's Cube in the half-turn metric.

Right now these programs are in a state of flux and will not
fully work.  Email me if you need to know what commit works.
