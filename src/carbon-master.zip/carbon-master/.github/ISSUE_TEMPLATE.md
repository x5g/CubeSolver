<!--
Is your issue for a new theme or language? As of Carbon `3.0.0`, the core Carbon team is no
longer implementing new themes or languages ourselves, but we are happy to accept PRs to add new ones.

Please see https://github.com/carbon-app/carbon/blob/master/.github/CONTRIBUTING.md#adding-themeslanguages for notes on how to do so 😄
-->
<!-- Attach a screenshot where applicable -->

### Expected Behavior

### Actual Behavior

<details>
  <summary>Browser: </summary>
  <!-- Enter your Browser information here -->
</details>

<details>
  <summary>Code Snippet (If Applicable)</summary>
  <!-- Paste an example code snippet as plain text here for failure cases -->
</details>
