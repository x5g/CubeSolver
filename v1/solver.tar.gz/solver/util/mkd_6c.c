/* Author: Michael Feather

   This program lists all configs (or symmetry configs) up to the specified
   depth.  Output can be piped to "sort -u | wc -l" to yield the following
   counts which match those listed in cube-mail-25 of the cube-lovers
   archive (counts from this program are cumulative, counts from cube-mail
   are not so both are shown (subtract previous depth count from each
   cumulative count to get non-cumulative count)).

   Face Turn Metric (FTM)
                                   cumulative  cumulative
         configs      symmetry        configs    symmetry
    1         18             1             18           2
    2        243             9            261          11
    3       3240            75           3501          86
    4      43239           934          46740        1020
    5     574908         12077         621648       13097 
    6    7618438        159131        8240086      172228
    7                  2101575                    2273803
    8                 27762103                   30035906

   From cube-mail-25:
   Face Moves      Patterns       Positions   Branching   Positions/
   from Start                                    Factor     Patterns
      0                     1               1                 1.0
      1                     2              18     18          9.0
      2                     9             243     13.5       27.0
      3                    75            3240     13.333     43.2
      4                   934           43239     13.345     46.294
      5                 12077          574908     13.296     47.604
      6                159131         7618438     13.252     47.875
      7               2101575       100803036     13.231     47.965
      8              27762103      1332343288     13.217     47.991
      9             366611212     17596479795     13.207     47.998
     10            4838564147    232248063316     13.199     47.999

   Quarter Turn Metric (QTM):
                                   cumulative  cumulative 
          configs     symmetry        configs    symmetry   
    0           1            1              
    1          12            1             12           1
    2         114            5            126           6
    3        1068           25           1194          31
    4       10011          219          11205         250
    5       93840         1978         105045        2228
    6      878880        18395         983925       20623
    7     8221632       171529        9205557      192152
    8    76843595      1601725       86049152     1793877
    9   717789576     14956266      803838728    16750143
   10  6701836858    139629194     7505675586   156379337
*/

#include "rc.h"

// set the following three defines to 0 to match cumulative config counts above
// set to 1 to match cumulative symmetry counts

#define SHOW_SYM_CFG    1    // 0=config, 1=sym config
#define SYM_FIRST_MOVE  1    // 0=all first moves, 1=sym first moves
#define USE_CHK_DUP     1

#define SHOW_DEFINES    0
#define CHECK_RUNTIME 

char ep6c_stack[STACK_DEPTH][12];
int count, depth, seq[20];
char disp[6] = {'R', 'L', 'U', 'D', 'F', 'B'};
char disp2[3] = {' ', '2', '\'' };

unsigned short cp6c_sym[C_PERM][CUBE_SYM];   // 3.7 MB

main(argc, argv)
     int argc; 
     char **argv;
{
  int n;
  if (check_defines() != 0)
    exit(1);
  n = params(argc, argv);
  init();
  if (SHOW_DEFINES)
    show_defines();
  list_configs(n);
  exit(0);
}

list_configs(n)
{
  int i;
  struct S_CUBE c;

  c.ep = 0;
  c.et = c.cp = c.ct = 0;
  c.cpt.min = c.cpt.op = 0;
  c.epi = &ep_info[0];
  c.op = 0;
  c.epr[0] = c.epr[1] = c.epr[2] = 0; 
  c.cp6c = 0;
  c.cpt.min = c.cpt.op = 0;

  #if (CP6C_SYM_METHOD == 2)
  c.cp6cm.min = c.cp6cm.op = 0;
  #endif

  #if (EP_SYM_METHOD == 2)
  c.epm.min = c.epm.op = 0;
  #endif

  for (depth=1; depth <= n; depth++)
    {
      cfg_idx = count = 0;

      #if SYM_FIRST_MOVE
      search(&c, 1, mvlist1);
      #else
      search(&c, 1, mvlist2);
      #endif
    }
}

search(c, n, mvlist)
     struct S_CUBE *c;
     int n, *mvlist;
{
  char eprsym[3];
  int i, mv, cpsym, ctsym, EPRsym;
  int cp6csym;
  struct s_cpt *csym;
  struct S_CUBE m;
  // struct s_op_info *opi;
  struct s_min_op *opi;

  for (i=0; (mv=mvlist[i]) != NIL; i++)
    {
      EP_MOV_CODE
      ET_MOV_CODE
      CORNER_MOV_CODE
      CP6C_MOV_CODE
      EPR_MOV_CODE
      EPI_CODE
      OP_CODE
      ET_SYM_CODE

      #if CP6C_SYM_METHOD == 1
        #if CT_SYM_METHOD == 1
        EPT_MIN_OP_CODE(get_min_op_6c_m1)
        #elif CT_SYM_METHOD == 2
        EPT_MIN_OP_CODE(get_min_op_6c_m2)
        #endif
      #endif

      CORNER_SYM_CODE;
      cp6csym = cp6c_sym[m.cp6c][m.op];
      EPR_SYM_CODE_NEW

      if (n == depth)
	{
	  seq[n] = mv;
	  if (SHOW_SYM_CFG)
	    printf ("%03d %04d %02d %04d %03d %05d\n", 
		    EPMIN, m.etsym, CPSYM, CTSYM, 
		    cp6c_cpr[cp6csym], EPRsym);
          else
	    {
	      // m.ct = cpt_sym[m.cpt.min][m.cpt.op].ct;

	      printf ("%5d %4d %5d %5d %4d\n", m.ep, m.et, 
		      EPR(m.epr), m.cp6c, CTSYM);
	    }
	}
      else
	{
	  #if USE_CHK_DUP
	  if (n <= 5)
	    if (chk_dup_6c(EPMIN, m.etsym, EPRsym, cp6csym, CTSYM, n))
	      continue;
          #endif

	  seq[n] = mv;

	  if (QTM)
	    search(&m, n+1, SEQ_GEN(mv, seq[n-1]));
	  else
	    search(&m, n+1, seq_gen[mv]);
	}
    }
}

init()
{
  init3();
  load_bin_file("dat/cp6c_sym.dat", cp6c_sym, C_PERM*CUBE_SYM, SHORT);
  seq[0] = NIL;
  populate_min_ep();
}

params(argc, argv)
     int argc; 
     char **argv;
{
  int n;

  if (argc != 2)
    {
      printf("Usage: %s {depth}\n", argv[0]);
      exit(0);
    }
    
  n = atoi(argv[1]);
  
  if (n < 1 || n > 12)
    {
      printf("ERROR: Invalid max depth, range is 1-10\n");
      exit(0);
    }

  return(n);
}

show_defines()
{
  fprintf(stderr, "SHOW_SYM_CFG   = %d\n", SHOW_SYM_CFG);
  fprintf(stderr, "USE_CHK_DUP    = %d\n", USE_CHK_DUP);
  fprintf(stderr, "SYM_FIRST_MOVE = %d\n", SYM_FIRST_MOVE);
}

check_defines()
{
  int f = 0;
  if (CT_SYM_METHOD != 1 && CT_SYM_METHOD != 2) {
    printf("CT_SYM_METHOD must be set to 1 or 2 in rc.h\n");
    f = 1;
  }
  if (CP6C_SYM_METHOD != 1) {
    printf("CP6C_SYM_METHOD must be set to 1 in rc.h\n");
    f = 1;
  }
  return(f);
}
