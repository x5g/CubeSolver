/* Author: Michael Feather 

 sym48() {
   sym $1 24
   sym `sym $1 m` 24
 }
*/

#include "rc.h"
#include "sym.h"
#include "string.h"

#define SHOW_STARTING_CUBE  1
#define SHOW_SYM_OPS        0 
#define CUBE_FORMAT         0   // 0=normal, 1=single line
#define RECOLOR             0   // recolor to colorscheme UDFBLR -> ROGBYW

char display_op[CUBE_SYM][20];
char map[CUBE_SYM][FACELETS];
char centers[CUBE_SYM][6]; 

main(argc, argv)
     int argc;
     char **argv;
{
  char n, rtn, cubestr[FACELETS];
  char cubestr_sym[FACELETS];
  struct s_cube cube;

  if (argc != 3)
    usage(argv);

  n = strlen(argv[1]);
  if (n != 54)
  {
    printf("Invalid Input: cubestr length is %d, must be 54\n", n);
    exit(0);
  }
  strncpy(cubestr, argv[1], 54);

  init();
  argv[2][0]= tolower(argv[2][0]);

  if (strcmp(argv[2], "9") == 0) 
  {
    sym9(cubestr);
    exit(0);
  }

  if (strcmp(argv[2], "24") == 0) 
  {
    sym24(cubestr);
    exit(0);
  }

  if (strcmp(argv[2], "0") == 0)
    sym_op(cubestr_sym, cubestr, map[0]);   // UF3
  else if (strcmp(argv[2], "x") == 0)
    sym_op(cubestr_sym, cubestr, map[17]);   // UF3
  else if (strcmp(argv[2], "x2") == 0)
    sym_op(cubestr_sym, cubestr, map[7]);    // UF2
  else if (strcmp(argv[2], "x3") == 0)
    sym_op(cubestr_sym, cubestr, map[13]);   // UF1
  else if (strcmp(argv[2], "x'") == 0)
    sym_op(cubestr_sym, cubestr, map[13]);   // UF1
  else if (strcmp(argv[2], "y") == 0)
    sym_op(cubestr_sym, cubestr, map[21]);   // UR1
  else if (strcmp(argv[2], "y2") == 0)
    sym_op(cubestr_sym, cubestr, map[22]);   // UR2
  else if (strcmp(argv[2], "y3") == 0)
    sym_op(cubestr_sym, cubestr, map[23]);   // UR3
  else if (strcmp(argv[2], "y'") == 0)
    sym_op(cubestr_sym, cubestr, map[23]);   // UR3
  else if (strcmp(argv[2], "z") == 0)
    sym_op(cubestr_sym, cubestr, map[9]);    // FR3
  else if (strcmp(argv[2], "z2") == 0)
    sym_op(cubestr_sym, cubestr, map[5]);    // FR2
  else if (strcmp(argv[2], "z3") == 0)
    sym_op(cubestr_sym, cubestr, map[1]);    // FR1
  else if (strcmp(argv[2], "z'") == 0)
    sym_op(cubestr_sym, cubestr, map[1]);    // FR1
  else if (strcmp(argv[2], "m") == 0)
    sym_op(cubestr_sym, cubestr, reflect_LR);   
  else
  {
    printf("Invalid sym op: %s\n", argv[2]);
    usage(argv);
  }

  if (RECOLOR)
    recolor(cubestr_sym);
      
  show_cubestr(cubestr_sym, CUBE_FORMAT);

  exit(0);
}

recolor(c)
  char *c;
{
  int i;
  char U=c[4],  D=c[49],  L=c[22],  R=c[28],  F=c[25], B=c[31]; 
  for (i=0; i < FACELETS; i++)
    if      (c[i] == U) c[i] = 'R';
    else if (c[i] == D) c[i] = 'O';
    else if (c[i] == L) c[i] = 'G';
    else if (c[i] == R) c[i] = 'B';
    else if (c[i] == F) c[i] = 'Y';
    else if (c[i] == B) c[i] = 'W';
    else c[i] = 'Z';
}

sym_op2(dst, src, op)
     char *dst, *src, *op;
{
  int i;

  for (i=0; i < FACELETS; i++)
      dst[i] = src[op[i]];

  if (RECOLOR)
    recolor(dst);
      
  show_cubestr(dst, CUBE_FORMAT);
}

usage(argv)
  char **argv;
{
  printf("Usage: %s {cube string} {x|x2|x3|y|y2|y3|z|z2|z3|m}\n", argv[0]);
  exit();
}

init_display_op()
{
  int i;

/*
      0                1            2                3
0     "None",          "FR1",       "FR1 UR1",       "FR1 UR2", 
4     "FR1 UR2",       "FR2",       "FR2 UR1",       "FR2 UR2", 
8     "FR2 UR3",       "FR3",       "FR3 UR1",       "FR3 UR2", 
12    "FR3 UR3",       "UF1",       "UF1 UR1",       "UF1 UR2",    
16    "UF1 UR3",       "UF3",       "UF3 UR1",       "UF3 UR2",      
20    "UF3 UR3",       "UR1",       "UR2",           "UR3",
*/

  char init_op[CUBE_SYM][15] =
    {
      "None",          "FR1",       "FR1 UR1",       "FR1 UR2", 
      "FR1 UR2",       "FR2",       "FR2 UR1",       "FR2 UR2", 
      "FR2 UR3",       "FR3",       "FR3 UR1",       "FR3 UR2", 
      "FR3 UR3",       "UF1",       "UF1 UR1",       "UF1 UR2",    
      "UF1 UR3",       "UF3",       "UF3 UR1",       "UF3 UR2",      
      "UF3 UR3",       "UR1",       "UR2",           "UR3",
      "REFLECT",       "FR1 REFL",  "FR1 UR1 REFL",  "FR1 UR2 REFL",
      "FR1 UR2 REFL",  "FR2 REFL",  "FR2 UR1 REFL",  "FR2 UR2 REFL",
      "FR2 UR3 REFL",  "FR3 REFL",  "FR3 UR1 REFL",  "FR3 UR2 REFL",
      "FR3 UR3 REFL",  "UF1 REFL",  "UF1 UR1 REFL",  "UF1 UR2 REFL",
      "UF1 UR3 REFL",  "UF3 REFL",  "UF3 UR1 REFL",  "UF3 UR2 REFL",
      "UF3 UR3 REFL",  "UR1 REFL",  "UR2 REFL",      "UR3 REFL"
    };

  for (i=0; i < CUBE_SYM; i++)
    strcpy(display_op[i], init_op[i]);
}

init()
{
  // init2();
  init_display_op();
  init_map(map, sym_op_FR, sym_op_UR, reflect);
  init_centers();
}

init_centers()
{
  int i, j;
  char c1[54], c2[54];

  memcpy(c1,"000000000111222333444111222333444111222333444555555555",
	 FACELETS);

  for (i=0; i < FACELETS; i++)
    c1[i] -= 48;

  for (i=0; i < CUBE_SYM; i++)
    {
      sym_op(c2, c1, map[i]);
      
      for (j=0; j < 6; j++)
	  centers[i][j] = c2[center_idx[j]];
    }
}

assign_centers(s)
     char *s;
{
  char U, L, F, R, B, D;

  U = s[4];     L = s[22];    F = s[25];
  R = s[28];    B = s[31];    D = s[49];    

  set_colors_6c(R, F, U, L, B, D);
}

apply_sym_op_centers(cubestr_sym, cubestr, op)
     char *cubestr_sym, *cubestr, op;
{
  int i;
  char tmp[6];

  for (i=0; i < 6; i++)
    tmp[i] = cubestr[center_idx[i]];

  for (i=0; i < 6; i++)
    cubestr_sym[center_idx[i]] = tmp[centers[op][i]]; 

  assign_centers(cubestr_sym);

}

sym9(cubestr)
  char *cubestr;
{
    char cubestr_sym[FACELETS], sym2[FACELETS];
    // show_cubestr(cubestr, CUBE_FORMAT);
    sym_op2(cubestr_sym, cubestr, map[17]);   // X 
    sym_op2(cubestr_sym, cubestr, map[7]);    // X2 
    sym_op2(cubestr_sym, cubestr, map[13]);   // X3 
    sym_op2(cubestr_sym, cubestr, map[21]);   // Y
    sym_op2(cubestr_sym, cubestr, map[22]);   // Y2
    sym_op2(cubestr_sym, cubestr, map[23]);   // Y3
    sym_op2(cubestr_sym, cubestr, map[9]);    // Z 
    sym_op2(cubestr_sym, cubestr, map[5]);    // Z2
    sym_op2(cubestr_sym, cubestr, map[1]);    // Z3
}

sym24(cubestr)
  char *cubestr;
{
    char cubestr_sym[FACELETS], sym2[FACELETS];
    if (SHOW_STARTING_CUBE)
      show_cubestr(cubestr, CUBE_FORMAT);
    sym_op2(cubestr_sym, cubestr, map[17]);   // X 
    sym_op2(cubestr_sym, cubestr, map[7]);    // X2 
    sym_op2(cubestr_sym, cubestr, map[13]);   // X3 
    sym_op2(cubestr_sym, cubestr, map[21]);   // Y
    sym_op2(cubestr_sym, cubestr, map[22]);   // Y2
    sym_op2(cubestr_sym, cubestr, map[23]);   // Y3
    sym_op2(cubestr_sym, cubestr, map[9]);    // Z 
    sym_op2(cubestr_sym, cubestr, map[5]);    // Z2
    sym_op2(cubestr_sym, cubestr, map[1]);    // Z3
    vv(cubestr,13,1);                         // X3 Z3
    vv(cubestr,17,1);                         // X Z3
    vv(cubestr,17,5);                         // X Z2
    vv(cubestr,7,21);                         // X2 Y 
    vv(cubestr,17,22);                        // X Y2 
    vv(cubestr,13,21);                        // X3 Y
    vv(cubestr,13,23);                        // X3 Y3
    vv(cubestr,7,23);                         // X2 Y3
    vv(cubestr,17,21);                        // X Y
    vv(cubestr,17,23);                        // X Y3
    vv(cubestr,7,1);                          // X2 Z3
    vv(cubestr,23,13);                        // Y3 X3
    vv(cubestr,7,9);                          // X2 Z
    vv(cubestr,17,9);                         // X Z
}

vv(cubestr, s1, s2)
  char *cubestr;
  int s1, s2;
{
    char cubestr_sym[FACELETS], sym2[FACELETS];
    sym_op(cubestr_sym, cubestr, map[s1]); 
    sym_op2(sym2, cubestr_sym, map[s2]);
}
