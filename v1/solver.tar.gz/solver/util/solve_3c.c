// Author: Michael Feather

#include <stdio.h>
#include <stdlib.h>
#include "rc.h"
#include "dist.h"
#include "time.h"
#include <sys/timeb.h>

#define USE_ALT_QTM_NOTATION    FALSE   

#define MAX_DEP_DFLT_QTM    26
#define MAX_DEP_DFLT_FTM    20

#define CHECK_RUNTIME

int count, depth, max_depth, solution_found;
char seq[STACK_DEPTH];

char    disp[6] = {'R', 'L', 'U', 'D', 'F', 'B'};
char    alt_disp[12] = {'R','r','L','l','U','u','D','d','F','f','B','b'};

#if (QTM)
  char    disp2[2] = {' ', '\'' };
#else
  char    disp2[3] = {' ', '2', '\'' };
#endif

int nodes, tests;

time_t  time1, time2, get_time();
struct timeb ftime1, ftime2;

main(argc, argv)
     int argc;
     char **argv;
{
  char rtn, cubestr[54];
  struct S_CUBE c;

  time1 = time(0);
  ftime(&ftime1);

  if (argc < 2)
  {
    printf("Usage: %s {file}\n", argv[0]);
    exit(0);
  }
  
  if (argc == 2)
    {
      if (QTM)
        max_depth = MAX_DEP_DFLT_QTM;
      else
        max_depth = MAX_DEP_DFLT_FTM;
    }
  else if (check_max_depth(argv) != 0)
    return(1);

  init3();
  printf("Initializing:\n");
  load_dist_files();
  show_ftime(ftime1, "Init Time:");

  time2 = time(0);
  ftime(&ftime2);
  rtn = load_cube(argv[1], cubestr);
  convert_cube_3C(cubestr, &c);
  printf("\n");
  show_cubestr(cubestr, 0);
  solve(&c);
}

check_max_depth(argv)
     char **argv;
{
  if (argv[2][0] < '0' || argv[2][0] > '9')
    {
      printf("Invalid search depth: <%s>\n", argv[2]);
      printf("Usage: %s {file} [max optimal search depth]\n",
             argv[0]);
      return(1);
    }

  max_depth = atoi(argv[2]);

  if (max_depth < 1 || max_depth > ((QTM)?26:20))
    {
      printf("Max optimal search depth must be between 1 & %d\n", ((QTM)?26:20));
      return(1);
    }

  return(0);
}

show(argc, argv)
     int argc;
     char **argv;
{
  printf("Input File: %s\n", argv[1]);
  printf("Optimal Search Depth Max: %d\n", max_depth);
  printf("Metric: %s\n", ((QTM)?"Quarter Turn":"Face Turn"));
}

solve(c)
  struct S_CUBE *c;
{
  int i, j, n;

  n = c->cp*C_TWIST + c->ct;
  c->cpt.min = cpt_min[n];
  c->cpt.op  = inv_op[cpt_min_op[n]];
  
  c->epi = &ep_info[c->ep];

  //  these are for EP_SYM_METHOD 2 
  c->epm.min = ep_min[c->ep];
  c->epm.op = inv_op[ep_min_op[c->ep]];

  for (depth=1; depth <= max_depth; depth++)
    {
      count = nodes = tests = 0;
      search(c, 1, mvlist2);
      printf("Depth %2d completed  ", depth);
      show_node_counts();
      if (solution_found)
      {
          printf("%d Optimal Solution%s Found\n", 
            solution_found, (solution_found>1)?"s":"");
        show_ftime(ftime2, "Search Time:");
        show_ftime(ftime1, "Total Time: ");

        printf("\n");
        exit(0);
      }
    }
}

search(c, n, mvlist)
     struct S_CUBE *c;
     int n, *mvlist;
{   
  int i, ix, mv, op, tmp, cpsym, ctsym;
  struct s_cpt *csym;
  int dst;
  struct S_CUBE m;
  struct s_min_op *opi;
  
  for (i=0; (mv=mvlist[i]) != NIL; i++)
    {
      nodes++;

      EP_MOV_CODE;
      ET_MOV_CODE;
      CORNER_MOV_CODE

      if (n == depth)
	{
          tests++;

	  if (m.ep == 0 && m.et == 0 && CORNER_3C_SOLVED) 
	    {
	      seq[n] = mv;
              display_optimal_solution();
              solution_found++;
	    }
	}
      else
	{
	  EPI_CODE;
	  OP_CODE;
	  ET_SYM_CODE;
	  EPT_MIN_OP_CODE(GET_MIN_OP_3C)
	  CORNER_SYM_CODE;

	  tmp = dist1[EPMIN][CPSYM][CTSYM>>(D1_RS+1)];
	  dst = n + (((CTSYM>>D1_RS)&1) ? tmp>>4 : tmp&0xF);
	  if (dst > depth)
	    continue;

	  tmp = dist2[EPMIN][CPSYM][m.etsym>>(D2_RS+1)];
	  dst = n + (((m.etsym>>D2_RS)&1) ? tmp>>4: tmp&0xF);
	      
	  if (dst > depth)
	    continue;

	  m.epi = &ep_info[m.ep];
	  seq[n] = mv;

	  if (QTM)
	    search(&m, n+1, SEQ_GEN(mv, seq[n-1]));
	  else
	    search(&m, n+1, seq_gen[mv]);
	}
    }
}

display_optimal_solution()
{
  display_moves(&seq[1], depth);
  
  if (QTM)
    printf("(%dq*)\n", depth);
  else
    printf("(%df*)\n", depth);

  fflush(stdout);
}

display_moves(s, n)
     char *s;
     int n;
{
  int i;

  for (i=0; i < n; i++)
    display_move(s[i]);

  if (QTM && USE_ALT_QTM_NOTATION)
    printf(" ");
}

display_move(m)
     int m;
{ 	
  if (QTM)
    {
      if (USE_ALT_QTM_NOTATION)
        printf("%c ", alt_disp[m]); 
      else
        printf("%c%c ", disp[m/2], disp2[m%2]); 
    }
  else
    printf("%c%c ", disp[m/3], disp2[m%3]); 
}

convert_cube_3C(cubestr, c)
  char *cubestr;
  struct S_CUBE *c;
{
  FILE *cube_file;
  struct s_cube cube;
  int i, cp;

  convert_cnr_6c(cubestr, cube.cps, cube.cts);
  conv_perm_3C(cube.cps, 8);
  convert_edg_6c(cubestr, cube.eps, cube.ets);
  conv_perm_3C(cube.eps, 12);

  c->cp = b2_cp[str_to_int(cube.cps,7,2)];
  c->ct = str_to_int(cube.cts,7,3);
  c->ep = b3_ep[str_to_int(cube.eps,11,3)];
  c->et = str_to_int(cube.ets,11,2);

  verify_cubestr_3C(cubestr, &cube);   // return codes: 0=ok  1=home  >1=error
}

conv_perm_3C(s, n)
  char *s, n;
{
  int i;
  for (i=0; i < n; i++) 
  {
    if (s[i] == 4) 
      s[i] = 1;
    if (s[i] == 8) 
      s[i] = 2;
  }
}

load_dist_files()
{
  char fname [50];

  if (USE_DIST1 == 0 || USE_DIST2 == 0)
    {
      printf("USE_DIST1 or USE_DIST2 is not set\n");
      exit(0);
    }

  snprintf(fname, DAT_FNAME_LEN, "dat/D1_%04dH_%02d%c.dat", 
	   DIST1_SIZE, D1_GEN_DEPTH, metric);

  load_dist_file(fname, dist1, sizeof(dist1)); 

  snprintf(fname, DAT_FNAME_LEN, "dat/D2_%04dH_%02d%c.dat", 
	   DIST2_SIZE, D2_GEN_DEPTH, metric);

  load_dist_file(fname, dist2, sizeof(dist2));
}

verify_cubestr_3C(s, c)     // return codes: 0=ok  1=home  >1=error
     char *s;
     struct s_cube *c;
{
  char check[12];
  int  i, pos, tw;

  for (i=0; i < 8; i++)
    check[i] = 0;

  for (i=0; i < 8; i++)
    check[c->cps[i]]++;

  if (check[0] != 4 || check[1] != 4)
  {
    printf("ERROR: Invalid Corner Configuration\n");
    exit(0);
  }

  for (i=0; i < 12; i++) 
    check[i] = 0;

  for (i=0; i < 12; i++)
    check[c->eps[i]]++;

  if (check[0] != 4 || check[1] != 4 || check[2] != 4)
  {
    printf("ERROR: Invalid Edge Configuration\n");
    exit(0);
  }

  return(0);
}

show_time(start_time, s)
     time_t start_time;
     char *s;
{
  int n;

  n = get_time(start_time);
  printf("%s %02d:%02d:%02d\n", s, n/3600, (n%3600)/60, n%60);
}

time_t
get_time(start_time)
     time_t start_time;
{
  time_t end_time, n;
  end_time = time((long*)0);
  n = end_time - start_time;
  return(n);
}

show_ftime(start_ftime, s)
     struct timeb start_ftime;
     char *s;
{
  int n, m;
  n = get_ftime(start_ftime, &m);
  printf("%s %02d:%02d.%02d\n", s, n/60, n%60, m);
}

show_ftime2(start_ftime)
     struct timeb start_ftime;
{
  int n, m;
  n = get_ftime(start_ftime, &m);
  printf("%02d:%02d.%02d ", n/60, n%60, m);
}

get_ftime(start_ftime, m)
     struct timeb start_ftime;
     int *m;
{
  int n, x, v;
  struct timeb end_ftime;
  ftime(&end_ftime);
  x = (end_ftime.time - start_ftime.time) * 1000 + 
      (end_ftime.millitm - start_ftime.millitm);
  n = x/1000;
  *m = (x%1000)/10;
  return(n);
}

show_node_counts()
{	
  printf("%10d nodes %10d tests\n", nodes, tests);
  fflush(stdout);	
}

