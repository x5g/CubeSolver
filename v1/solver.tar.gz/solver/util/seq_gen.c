// Author: Michael Feather 

#include "rc.h"

int count, depth, seq[20];
char disp[6] = {'R', 'L', 'U', 'D', 'F', 'B'};

main(argc, argv)
     int argc; 
     char **argv;
{
  int n;
  init_seq();
  n = params(argc, argv);
  list_configs(n);
  exit(0);
}

list_configs(n)
{
  for (depth=1; depth <= n; depth++)
    {
      count = 0;

      #if SYM_FIRST_MOVE
      search(1, mvlist1);
      #else
      search(1, mvlist2);
      #endif
    }
  // printf("%d\n", count);
}

search(n, mvlist)
     int n, *mvlist;
{
  int i, mv;

  for (i=0; (mv=mvlist[i]) != NIL; i++)
    {
      seq[n] = mv;
      if (n == depth)
	{
          show_seq();
          count++;
	}
      else
	{
	  if (QTM)
	    search(n+1, SEQ_GEN(mv, seq[n-1]));
	  else
	    search(n+1, seq_gen[mv]);
	}
    }
}

char    disp2[3] = {' ', '2', '\'' };
show_seq()
{
  int i;
  // printf("%d: ", depth);
  for (i=1; i <= depth; i++)
    //printf("%d ", seq[i]);
    printf("%c%c ", disp[seq[i]/3], disp2[seq[i]%3]);
  printf("\n");
}

params(argc, argv)
     int argc; 
     char **argv;
{
  int n;

  if (argc != 2)
    {
      printf("Usage: %s {depth}\n", argv[0]);
      exit(0);
    }
    
  n = atoi(argv[1]);
  
  if (n < 1 || n > 12)
    {
      printf("ERROR: Invalid max depth, range is 1-10\n");
      exit(0);
    }

  return(n);
}
