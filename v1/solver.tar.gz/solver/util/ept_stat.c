/* Author: Michael Feather
  
   This program gets the stats that are used as the "expected" values shown
   by show_ept_stats() by looking at all the ep + et (ept) configurations.
  
   Output:

   Nodes: 70963200

   Phase 0 stats:
   EP min op not uniq  =  4214784   0.0594   expected = .0594
   EPT min op not uniq =   170928   0.0024   expected = .0024
   Second etsym op     =  2368513   0.0334   expected = .0334

   Note: EP_OPT_METHOD must be set to 2 in rc.h to get the last entry shown
   above (second etsym) because method 1 never needs to do a second et sym op.

   --------------------------------------------------------------------------

   The above expected value for "EP min op not uniq" (.0594) can also be
   calculated by dividing the number of ep configs that have less than 48
   unique symmetries into the total number of ep configs (2058/34650).

   The above count for "EPT min op not uniq" (170928) can also be derived
   from ept_min_ops.dat which stores the list of symmetry min ops for each
   of the 7331 EPT configs which have multiple sym ops that yield min:

   cat dat/ept_min_ops.dat | awk '{print $3}' | sort -n | uniq -c | 
     awk '{printf("%9d %2d\n", $1*48/($2+1), $2+1)}' | 
     awk '{total+=$1}END{print total}'

    nodes mins
   ------ ----
   165504  2
     2384  3
     2640  4
      176  6
      192  8
        8 12
       18 16
        4 24
        2 48
   ------
   170928
*/

#include "rc.h"

int phase;
unsigned int nodes[2];

#define CHECK_RUNTIME

main()
{
  if (SHOW_EPT_STATS != TRUE)
    {
      printf("set SHOW_EPT_STATS in rc.h to TRUE\n");
      exit(0);
    }
  // show_methods();
  init3();
  phase = 0;
  init_ept_stats(0);
  doit();
  show_ept_stats(0);
  exit(0);
}

doit()
{
  int etsym;
  struct s_cube3 m;
  struct s_min_op *opi;
  
  m.cp = m.ct = 0;
  m.cpt.min = m.cpt.op= 0;

  for (m.ep=0; m.ep < E_PRM; m.ep++)
    {
      if (EP_SYM_METHOD == 2)
	{
	  m.epm.min = ep_min[m.ep];
	  m.epm.op = ep_min_op[m.ep];
	}

      EPI_CODE;

      for (m.et=0; m.et < E_TWIST; m.et++)
	{
	  nodes[0]++;
	  OP_CODE;
	  ET_SYM_CODE;
	  EPT_MIN_OP_CODE(GET_MIN_OP_3C)
	}
    }
}
