/* Author: Michael Feather
 
   This program determines the number of accessible nodes for the combination
   of edge position & twist (reduced by symmetry).
   To do this, cube symmetry is applied to each of the 70 million 3-Color edge
   position & twist combinations and the resulting (symmetry min) configs are
   marked in an array which is then counted for the total.

   The size of the dist arrays can be varied depending on how many bits of 
   edge twist are used.
   This means the total numbe of accessible nodes varies depending on the
   value of ET_RS which is the number of bits the edge twist variable is
   right-shifted.
   
   These totals are used to more accurately determine the percentage of configs
   at a given depth (as opposed to using the total number of configs that the
   array can store).
   
   Output:
                                    Pct
   ET_RS Accessible Array Nodes Inaccessible
   ----- ---------- ----------- ------------
     0      1482170     1601536    7.45%
     1       748239      800768    6.56%
     2       376749      400384    5.90%
     3       189322      200192    5.43%
     4        95333      100096    4.76%
     5        47920       50048    4.25%
     6        24146       25024    3.51%
     7        12126       12512    3.09%
     8         6157        6256    1.58%
     9         3091        3128    1.18%
    10         1564        1564    0.00%
    11          782         782    0.00%
*/

#include "rc.h"

char ept[MIN_EP][E_TWIST];

main()
{
  int i, j;

  if (check_defines() != 0)
    exit(0);

  init3();

  printf("                                 Pct\n");
  printf("ET_RS Accessible Array Nodes Inaccessible\n");
  printf("----- ---------- ----------- ------------\n");

  for (i=0; i < 12; i++)
    get_ept_count(i);

  printf("\n");
  exit(0);
}

get_ept_count(et_rs)
     int et_rs;
{
  int ep, et, count, etsym, op;
  struct s_info *epi;
  struct s_op_info *opi;
  struct S_CUBE m;

  for (ep=count=0; ep < MIN_EP; ep++)
    for (et=0; et < E_TWIST; et++)
      ept[ep][et] = 0;

  for (m.ep=count=0; m.ep < E_PRM; m.ep++)
    {
      EPI_CODE;
      for (m.et=0; m.et < E_TWIST; m.et++)
	{
	  OP_CODE;
	  ET_SYM_CODE;
	  if (ept[EPMIN][m.etsym>>et_rs] == 0)
	    {
	      ept[EPMIN][m.etsym>>et_rs] = 1;
	      count++;
	    }
	}
    }

  printf("%3d   %10d  %10d  %6.2f%\n", et_rs, count, 
	 MIN_EP*(E_TWIST>>et_rs), 
	 (float)100*(1-(float)count/(MIN_EP*(E_TWIST>>et_rs))));
}

check_defines()
{
  int f = 0;
  if (EP_SYM_METHOD != 1) {
    printf("EP_SYM_METHOD must be set to 1 in rc.h\n");
    f = 1;
  }
  if (EPT_OP_METHOD != 1) {
    printf("EPT_OP_METHOD must be set to 1 in rc.h\n");
    f = 1;
  }
  return(f);
}
