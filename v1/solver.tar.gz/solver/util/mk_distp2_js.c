// This uncompresses a P2_0004H_NNF.dat for use with the JS Solver

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define FILE_SIZE  576*13824  // Dist P2

unsigned char in[FILE_SIZE/2];
unsigned char out[FILE_SIZE];

main(int argc, char **argv)
{
  int i, j;
  FILE *fp;

  if (argc != 3) {
    printf("Usage:\n%s {infile} {outfile}\n\n", argv[0]);
    printf("Example:\n%s P2_0004H_15F.dat DistP2_15F.dat\n", argv[0]);
    exit(0);
  }
  fp = fopen(argv[1], "r");
  if (fp == NULL) {
    printf("Error opening input file: %s\n", argv[1]);
    exit(0);
  }
  fread(in, 1, FILE_SIZE/2, fp);
  fclose(fp);
  for (i=j=0; i < FILE_SIZE/2; i++, j+=2) {
    out[j] = in[i]&0xF;
    out[j+1] = in[i]>>4;
  }
  char s[1000];
  if (strncmp(&argv[1][strlen(argv[1])-7], "15F.dat", 7) == 0) {
    // printf("Updating 0's to 16\n");
    for (i=1; i < FILE_SIZE; i++)
      if (out[i] == 0)
        out[i] = 16;
  }
  fp = fopen(argv[2], "w");
  if (fp == NULL) {
    printf("Error opening output file: %s\n", argv[2]);
    exit(0);
  }
  fwrite(out, 1, FILE_SIZE, fp);  
  fclose(fp);
}
