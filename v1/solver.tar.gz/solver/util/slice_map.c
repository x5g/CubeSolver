// Author: Michael Feather 

#include "rc.h"

unsigned short ep_sym[E_PRM][CUBE_SYM];  // 3.2 MB

main()
{
  init2();
  load_bin_file("dat/ep_sym.dat", ep_sym, E_PRM*CUBE_SYM, SHORT);
  load_bin_file("dat/ep_sym.dat", ep_sym, E_PRM*CUBE_SYM, SHORT);
  load_text_file("dat/inv_op.dat", inv_op, CUBE_SYM, CHAR);
  populate_slice_map();
}

populate_slice_map()
{
  /* this function lists the slice_map init values for hardcoding into
     init_slice_map() in rclib.c.  this eliminates the need to load array
     ep_sym which is not needed by mkd or the solver.  the mapping is 
     as shown:
                       slice
                     ----------
    op#  op          UD  LR  FB
    ---  -------     --  --  --
      0  none        UD  LR  FB
      1  FR1         UD  FB  LR
      2  FR1 UR1     LR  FB  UD
      3  FR1 UR2     UD  FB  LR
      4  FR1 UR3     LR  FB  UD
      5  FR2         UD  LR  FB
      6  FR2 UR1     LR  UD  FB
      7  FR2 UR2     UD  LR  FB
      8  FR2 UR3     LR  UD  FB
      9  FR3         UD  FB  LR
     10  FR3 UR1     LR  FB  UD
     11  FR3 UR2     UD  FB  LR
     12  FR3 UR3     LR  FB  UD
     13  UF1         FB  LR  UD
     14  UF1 UR1     FB  UD  LR
     15  UF1 UR2     FB  LR  UD
     16  UF1 UR3     FB  UD  LR
     17  UF3         FB  LR  UD
     18  UF3 UR1     FB  UD  LR
     19  UF3 UR2     FB  LR  UD
     20  UF3 UR3     FB  UD  LR
     21  UR1         LR  UD  FB
     22  UR2         UD  LR  FB
     23  UR3         LR  UD  FB
  */

  int i, n, ep, op, slice;
  int tmp [2][CUBE_SYM];
  char tmp_slice_map[CUBE_SYM][3];

  for (slice=0; slice < 3; slice++)
    {
      /*  populate tmp with the first two rows from ep_sym 
	  where epslice = 0 for the current slice:

	              epslice
                  ---------------
             ep    s0    s1    s2
	  -----   ---   ---   ---
          17359     0   494    69 
          17534     0   493   104 
             69   494     0    69 
            384   493     0   104 
              0   494    69     0 
             70   493   104     0 
      */

      for (ep=n=0; n < 2; ep++)
	if (ep_slice[ep][slice] == 0)
	  {
	    for (op=0; op < CUBE_SYM; op++)
	      tmp[n][op] = ep_sym[ep][op];
	    n++;
	  }
      
      // populate tmp_slice_map by finding the sym op that equates the
      // epslice values between the two rows in tmp

      for (op=0; op < CUBE_SYM; op++)
	{
	  for (i=0; i < 3; i++)
	      if (ep_slice[tmp[0][op]][i] == ep_slice[tmp[1][op]][i])
		break;

	  tmp_slice_map[op][slice] = i;
	}
    }

  // verify

  for (slice=0; slice < 3; slice++)
    for (op=0; op < CUBE_SYM; op++)
      if (tmp_slice_map[op][slice] != slice_map[op][slice])
        printf("ERROR: slice mismatch: slice_map[%d][%d]\n", op, slice);

  printf("\nslice_map:\n");

  for (op=0; op < CUBE_SYM; op++)
    {
      for (slice=0; slice < 3; slice++)
	printf("%d,", tmp_slice_map[op][slice]); 
      
      if ((op+1)%8 == 0)
	printf("\n");
    }
}
