// Author: Michael Feather 

#include "rc.h"

/*         00 01 02
           03 04 05
           06 07 08
  09 10 11 12 13 14 15 16 17 18 19 20
  21 22 23 24 25 26 27 28 29 30 31 32
  33 34 35 36 37 38 39 40 41 42 43 44
           45 46 47
           48 49 50
           51 52 53
*/

char CENTERS[6] = {4, 22, 25, 28, 31, 49};

char CORNERS[24] = {
   0,  2,  6,  8,  9, 11, 33, 35, 12, 14, 36, 38, 
  15, 17, 39, 41, 18, 20, 42, 44, 45, 47, 51, 53
};

char EDGES[24] =  {
   1,  3,  5,  7, 10, 21, 23, 34, 13, 24, 26, 37, 
  16, 27, 29, 40, 19, 30, 32, 43, 46, 48, 50, 52
};

char * color();
int cmp();

main(argc, argv)
     int argc;
     char **argv;
{
  if (argc != 2) 
  {
    printf("Usage: %s {cube file}\n", argv[0]);
    exit(0);
  }

  if (process_file(argv[1]) != 0)
    exit(1);
}

process_file(fname)
     char *fname;
{
  FILE *cube_file;
  char rtn, cubestr[54];
  struct s_cube cube;
  char msg[100];

  if ((cube_file = fopen(fname,"r")) == NULL)
    {
      printf("Error opening file: %s\n", fname);
      exit(99);
    }

  rtn = load_cube_fp(cube_file, cubestr);

  if (rtn != FACELETS)
  {
    if (rtn == 0)
    {
      printf("\nERROR: Empty File: %s\n", fname);
      exit(98);
    }
    else
    {
      // printf("\nERROR: Not enough facelets: %s\n", fname);
      // rclib puts out an error for this
    }
  }

  check_blank(cubestr);
  check_centers(cubestr);
  check_corners(cubestr);
  check_edges(cubestr);
 
  rtn = verify_cubestr(cubestr, &cube);

  if (rtn == 1)
    printf("Cube already solved\nNo moves required\n");

  // all errors except parity should have been detected previously
  // to get this error flip one edge
  if (rtn == 2)
    printf("There is a problem with the input, check the CORNERS\n");  

  // to get this error twist one corner
  if (rtn == 3)
    printf("There is a problem with the input, check the EDGES\n");  

  // to get this error switch colors on opposite sides for one pair of edge facelets
  if (rtn == 4)
  {
    printf("Parity Error\nThere is a problem with the input, check all corners and edges\n");
  }
  fclose(cube_file);
  exit(rtn);
}

check_centers(c)
  char *c;
{
  int f, i, j, rtn;
  char centers[6];

  for (i=0; i < 6; i++)
    centers[i] = c[CENTERS[i]];

  for (i=0; i < 6; i++)
    if (centers[i] == 'L')
    {
      printf("There is a problem with the CENTERS, one or more is blank\n");
      exit(5);
    }

  qsort(centers, 6, 1, cmp);
  rtn = uniq(centers, 6, 1, 0);

  if (rtn != 0)
  {
    printf("There is a problem with the CENTERS, ");
    printf("there should be one of each color but you have:\n"); 
    uniq(centers, 6, 1, 1);
    exit(5);
  }
}

check_blank(c)
  char *c;
{ 
  int i, n;

  for (i=n=0; i < 54; i++)
    if (c[i] == 'L')
      n++;

  if (n == 54)
  {
    printf("No colors have been entered\nColor the cube layout before solving");
    exit(1);
  }
}

check_corners(c)
  char *c;
{
  int i, j, rtn;
  char corners[24];

  for (i=0; i < 24; i++)
    corners[i] = c[CORNERS[i]];

  for (i=0; i < 24; i++)
    if (corners[i] == 'L')
    {
      printf("There is a problem with the CORNERS, one or more is blank\n");
      exit(2);
    }

  qsort(corners, 24, 1, cmp);
  rtn = uniq(corners, 24, 4, 0);

  if (rtn != 0)
  {
    printf("There is a problem with the CORNERS, ");
    printf("there should be four of each color but you have:\n"); 
    uniq(corners, 24, 4, 1);
    exit(2);
  }
}

check_edges(c)
  char *c;
{
  int i, j, rtn;
  char edges[24];

  for (i=0; i < 24; i++)
    edges[i] = c[EDGES[i]];

  for (i=0; i < 24; i++)
    if (edges[i] == 'L')
    {
      printf("There is a problem with the EDGES, one or more is blank\n");
      exit(3);
    }

  qsort(edges, 24, 1, cmp);
  rtn = uniq(edges, 24, 4, 0);

  if (rtn != 0)
  {
    printf("There is a problem with the EDGES, ");
    printf("there should be four of each color but you have:\n"); 
    uniq(edges, 24, 4, 1);
    exit(3);
  }
}

char *
color(c)
  char c;
{   
  static char s[2];
  if      (c == 'W') return "White";
  else if (c == 'Y') return "Yellow";
  else if (c == 'R') return "Red";
  else if (c == 'O') return "Orange";
  else if (c == 'B') return "Blue";
  else if (c == 'G') return "Green";
  else 
  {
    sprintf(s, "%c", c);
    return s;
  }
}

cmp(a, b)
  char *a, *b;
{
  return(memcmp(a, b, 1));
}

show(s, n)
  char *s;
  int n;
{
  int i;
  for (i=0; i < n; i++) 
    printf("%c", s[i]); 
  printf("\n");
}

uniq(s, n, v, f)
  char *s, f;
  int n, v;
{
  int i, j, stat=0;
  char p;

  p = s[0]; 
  for (i=j=1; i < n; i++) 
    if (s[i] == p)
      j++; 
    else
    {
      if (j != v) 
      {
         stat = 1;
         if (f) printf("%d %s\n", j, color(s[i-1]));
      }
      p = s[i];
      j = 1;
    }
  if (j != v) 
  {
     stat = 1;
     if (f) printf("%d %s\n", j, color(s[i-1]));
  }
  return(stat);
}
