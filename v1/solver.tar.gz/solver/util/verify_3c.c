// Author: Michael Feather

#include <stdio.h>
#include <stdlib.h>
#include "rc.h"

/*         00 01 02
           03 04 05
           06 07 08
  09 10 11 12 13 14 15 16 17 18 19 20
  21 22 23 24 25 26 27 28 29 30 31 32
  33 34 35 36 37 38 39 40 41 42 43 44
           45 46 47
           48 49 50
           51 52 53
*/

char CENTERS[6] = {4, 22, 25, 28, 31, 49};

char CORNERS[24] = {
   0,  2,  6,  8,  9, 11, 33, 35, 12, 14, 36, 38, 
  15, 17, 39, 41, 18, 20, 42, 44, 45, 47, 51, 53
};

char EDGES[24] =  {
   1,  3,  5,  7, 10, 21, 23, 34, 13, 24, 26, 37, 
  16, 27, 29, 40, 19, 30, 32, 43, 46, 48, 50, 52
};

char *color();
int cmp();

main(argc, argv)
     int argc;
     char **argv;
{
  char rtn, cubestr[54];
  struct S_CUBE c;

  if (argc < 2)
  {
    printf("Usage: %s {file}\n", argv[0]);
    exit(0);
  }
 
  init2(); 
  rtn = load_cube(argv[1], cubestr);

  check_blank(cubestr);
  check_centers(cubestr);
  check_corners(cubestr);
  check_edges(cubestr);
 
  convert_cube_3C(cubestr, &c);
  verify_cubestr_3C(cubestr, &c);  
}

convert_cube_3C(cubestr, c)
  char *cubestr;
  struct s_cube *c;
{
  convert_cnr_6c(cubestr, c->cps, c->cts);
  conv_perm_3C(c->cps, 8);
  convert_edg_6c(cubestr, c->eps, c->ets);
  conv_perm_3C(c->eps, 12);
}

conv_perm_3C(s, n)
  char *s, n;
{
  int i;
  for (i=0; i < n; i++) 
  {
    if (s[i] == 4) 
      s[i] = 1;
    if (s[i] == 8) 
      s[i] = 2;
  }
}

verify_cubestr_3C(s, c)
     char *s;
     struct s_cube *c;
{
  char check[12];
  int  i, cp, ct, ep, et, sum;

  for (i=0; i < 8; i++)
    check[i] = 0;

  for (i=0; i < 8; i++)
    check[c->cps[i]]++;

  if (check[0] != 4 || check[1] != 4)
    err(2, "There is a problem with the input, check the CORNERS");

  for (i=sum=0; i < 8; i++)
    sum += c->cts[i];

  if (sum%3)
    err(2, "There is a problem with the input, check the CORNERS");

  for (i=sum=0; i < 12; i++)
    sum += c->ets[i];

  if (sum%2)
    err(3, "There is a problem with the input, check the EDGES");
  for (i=0; i < 12; i++) 
    check[i] = 0;

  for (i=0; i < 12; i++)
    check[c->eps[i]]++;

  if (check[0] != 4 || check[1] != 4 || check[2] != 4)
    err(3, "There is a problem with the input, check the EDGES");

  cp = b2_cp[str_to_int(c->cps,7,2)];
  ct = str_to_int(c->cts,7,3);
  ep = b3_ep[str_to_int(c->eps,11,3)];
  et = str_to_int(c->ets,11,2);

  if (cp == 0 && ct == 0 && ep == 0 && et == 0)
    err(1, "Cube already solved\nNo moves required");

  return(0);
}


err(n, s)
  int n;
  char *s;
{
    printf("%s\n", s);
    exit(n);
}

check_centers(c)
  char *c;
{
  int f, i, j, rtn;
  char centers[6];

  for (i=0; i < 6; i++)
    centers[i] = c[CENTERS[i]];

  for (i=0; i < 6; i++)
    if (centers[i] == 'L')
    {
      printf("There is a problem with the CENTERS, one or more is blank\n");
      exit(5);
    }

  if (centers[0] != centers[5] || 
      centers[1] != centers[3] || 
      centers[2] != centers[4])
  {
    printf("There is a problem with the CENTERS, ");
    printf("colors must match on opposite sides\n"); 
    exit(5);
  }

  qsort(centers, 6, 1, cmp);
  rtn = uniq(centers, 6, 2, 0);

  if (rtn != 0)
  {
    printf("There is a problem with the CENTERS, ");
    printf("there should be two of each color but you have:\n"); 
    uniq(centers, 6, 2, 1);
    exit(5);
  }
}

check_blank(c)
  char *c;
{ 
  int i, n;

  for (i=n=0; i < 54; i++)
    if (c[i] == 'L')
      n++;

  if (n == 54)
  {
    printf("No colors have been entered\nColor the cube layout before solving");
    exit(1);
  }
}

check_corners(c)
  char *c;
{
  int i, j, rtn;
  char corners[24];

  for (i=0; i < 24; i++)
    corners[i] = c[CORNERS[i]];

  for (i=0; i < 24; i++)
    if (corners[i] == 'L')
    {
      printf("There is a problem with the CORNERS, one or more is blank\n");
      exit(2);
    }

  qsort(corners, 24, 1, cmp);
  rtn = uniq(corners, 24, 8, 0);

  if (rtn != 0)
  {
    printf("There is a problem with the CORNERS, ");
    printf("there should be eight of each color but you have:\n"); 
    uniq(corners, 24, 8, 1);
    exit(2);
  }
}

check_edges(c)
  char *c;
{
  int i, j, rtn;
  char edges[24];

  for (i=0; i < 24; i++)
    edges[i] = c[EDGES[i]];

  for (i=0; i < 24; i++)
    if (edges[i] == 'L')
    {
      printf("There is a problem with the EDGES, one or more is blank\n");
      exit(3);
    }

  qsort(edges, 24, 1, cmp);
  rtn = uniq(edges, 24, 8, 0);

  if (rtn != 0)
  {
    printf("There is a problem with the EDGES, ");
    printf("there should be eight of each color but you have:\n"); 
    uniq(edges, 24, 8, 1);
    exit(3);
  }
}

char *
color(c)
  char c;
{   
  static char s[2];
  if      (c == 'W') return "White";
  else if (c == 'Y') return "Yellow";
  else if (c == 'R') return "Red";
  else if (c == 'O') return "Orange";
  else if (c == 'B') return "Blue";
  else if (c == 'G') return "Green";
  else 
  {
    sprintf(s, "%c", c);
    return s;
  }
}

cmp(a, b)
  char *a, *b;
{
  return(memcmp(a, b, 1));
}

show(s, n)
  char *s;
  int n;
{
  int i;
  for (i=0; i < n; i++) 
    printf("%c", s[i]); 
  printf("\n");
}

uniq(s, n, v, f)
  char *s, f;
  int n, v;
{
  int i, j, stat=0;
  char p;

  p = s[0]; 
  for (i=j=1; i < n; i++) 
    if (s[i] == p)
      j++; 
    else
    {
      if (j != v) 
      {
         stat = 1;
         if (f) printf("%d %s\n", j, color(s[i-1]));
      }
      p = s[i];
      j = 1;
    }
  if (j != v) 
  {
     stat = 1;
     if (f) printf("%d %s\n", j, color(s[i-1]));
  }
  return(stat);
}

