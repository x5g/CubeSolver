/* Author: Michael Feather

   This program lists all configs (or symmetry configs) for a 3-Color Cube
   up to the specified depth.
   Output can be piped to "sort -u | wc -l" to yield the following counts:

       Quarter Turn Metric (QTM)     Face Turn Metric (FTM)
       -------------------------     -------------------------    
          cumulative  cumulative     cumulative  cumulative 
             configs    symmetry        configs    symmetry   
    1              6           1              7           2
    2             58           4             82           5
    3            526          16            970          28
    4           4804         108          12052         269
    5          44464         946         154282        3265
    6         412885        8638        1982725       41464
    7                      79867                     529371
    8                     738902                    6764737
    9                    6836099
   10                   
*/

#include "rc.h"
// #include "dist.h"

// set the following three defines to 0 to match cumulative config counts above
// set to 1 to match cumulative symmetry counts

#define SHOW_SYM_CFG    1    // 0=config, 1=sym config
#define SYM_FIRST_MOVE  1    // 0=all first moves, 1=sym first moves
#define USE_CHK_DUP     1

#define SHOW_DEFINES    0
#define CHECK_RUNTIME

char ep6c_stack[STACK_DEPTH][12];
int count, depth, seq[20];

main(argc, argv)
     int argc; 
     char **argv;
{
  int n;
  n = params(argc, argv);
  init();
  if (SHOW_DEFINES)
    show_defines();
  list_configs(n);
  exit(0);
}

list_configs(n)
{
  int i;
  struct S_CUBE c;

  c.ep = 0;
  c.et = c.cp = c.ct = 0;
  c.epm.min = c.epm.op = 0;
  c.cpt.min = c.cpt.op = 0;
  c.epi = &ep_info[0];
  c.op = 0;

  for (depth=1; depth <= n; depth++)
    {
      cfg_idx = count = 0;

      #if SYM_FIRST_MOVE
      search(&c, 1, mvlist1);
      #else
      search(&c, 1, mvlist2);
      #endif
    }
}

search(c, n, mvlist)
     struct S_CUBE *c;
     int n, *mvlist;
{
  int i, mv, cpsym, ctsym;
  struct S_CUBE m;
  struct s_cpt *csym;
  struct s_min_op *opi;

  for (i=0; (mv=mvlist[i]) != NIL; i++)
    {
      APPLY_MOVE_3C;

      if (n == depth)
	{
	  if (SHOW_SYM_CFG)
	    printf ("%03d%04d%02d%04d\n", 
		    EPMIN, m.etsym, CPSYM, CTSYM);
	  else
	    {
	      #if (CT_SYM_METHOD == 2)
                m.cp = cpt_sym[m.cpt.min][m.cpt.op].cp;
                m.ct = cpt_sym[m.cpt.min][m.cpt.op].ct;
	      #elif (CT_SYM_METHOD == 3)
	        m.ct = cpt_sym2[m.cpt.min][m.cpt.op];
              #endif
	      printf ("%5d%4d%2d%4d\n", m.ep, m.et, m.cp, m.ct);
	    }
	}
      else
	{
	  #if USE_CHK_DUP
	  if (n <= 5)
	    if (chk_dup_3c(EPMIN, m.etsym, CPSYM, CTSYM, n))
	      continue;
          #endif

	  seq[n] = mv;

	  if (QTM)
	    search(&m, n+1, SEQ_GEN(mv, seq[n-1]));
	  else
	    search(&m, n+1, seq_gen[mv]);
	}
    }
}

init()
{
  init3();
  seq[0] = NIL;
  populate_min_ep();
}

params(argc, argv)
     int argc; 
     char **argv;
{
  int n;

  if (argc != 2)
    {
      printf("Usage: %s {depth}\n", argv[0]);
      exit(0);
    }
    
  n = atoi(argv[1]);
  
  if (n < 1 || n > 12)
    {
      printf("ERROR: Invalid max depth, range is 1-10\n");
      exit(0);
    }

  return(n);
}

show_defines()
{
  fprintf(stderr, "SHOW_SYM_CFG   = %d\n", SHOW_SYM_CFG);
  fprintf(stderr, "USE_CHK_DUP    = %d\n", USE_CHK_DUP);
  fprintf(stderr, "SYM_FIRST_MOVE = %d\n", SYM_FIRST_MOVE);
}
