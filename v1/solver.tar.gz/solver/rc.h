// Author: Michael Feather

#include <stdio.h>
#include <setjmp.h>

#define TRUE                 1
#define FALSE                0

#define QUARTER_TURN_METRIC  0   // 0=FTM, 1=QTM

#if QUARTER_TURN_METRIC
#define QTM                  1 
#define MOVES                12
#define P2_GEN_DEPTH         12 
#else
#define QTM                  0
#define MOVES                18
#define P2_GEN_DEPTH         8 
#endif

#define SHOW_EPT_STATS       FALSE 

#define ET_SYM_METHOD        1     // 1-5
#define CT_SYM_METHOD        2     // 1-5
#define EP_SYM_METHOD        1     // 1-2
#define CP6C_SYM_METHOD      1     // 1-2
#define EPR_MOV_METHOD       2     // 1-2
#define EPR_SYM_METHOD       2     // 1-2
#define EPT_OP_METHOD        1     // 1-2

// for use with dist7

#define USE_EPR_MIN_OP       1
#define USE_GET_MIN_OP_E6C   1
#define USE_CHK_DUP_6C       1

#if USE_GET_MIN_OP_E6C
#define MIN_OP_E6C_CODE      m.op_ept = m.op; m.ops_idx = NIL;
#else
#define MIN_OP_E6C_CODE      
#endif

#define ET_MOV_CODE          m.et = et_mov[c->et][mv];
#define CP_MOV_CODE          m.cp = cp_mov[c->cp][mv];
#define CT_MOV_CODE          m.ct = ct_mov[c->ct][mv];
#define EP_MOV2_CODE_L1      m.epm = ep_mov2[c->epm.min][op_mv[c->epm.op][mv]];
#define EP_MOV2_CODE_L2      m.epm.op = op_op[m.epm.op][c->epm.op];
#define EP_MOV2_CODE_L3      m.ep = ep_sym2[m.epm.min][m.epm.op];
#define CPT_MOV_CODE_L1      m.cpt = cpt_mov[c->cpt.min][op_mv[c->cpt.op][mv]];
#define CPT_MOV_CODE_L2      m.cpt.op = op_op[m.cpt.op][c->cpt.op];
#define CP_SYM_CODE          cpsym = cp_sym[m.cp][m.op];
#define CT_SYM_CODE          ctsym = ct_sym[m.cp][m.ct][m.op];
#define CPT_SYM_CODE         csym = &cpt_sym[m.cpt.min][op_op[m.cpt.op][m.op]];
#define CPT_SYM2_CODE        ctsym = cpt_sym2[m.cpt.min][op_op[m.cpt.op][m.op]];
#define ET_SYM_CODE          m.etsym = GET_ETSYM(&m);
#define CP6C_MOV2_CODE_L1    m.cp6cm = cp6c_mov2[c->cp6cm.min][op_mv[c->cp6cm.op][mv]];
#define CP6C_MOV2_CODE_L2    m.cp6cm.op = op_op[m.cp6cm.op][c->cp6cm.op]; 
#define EPI_CODE             m.epi =  &ep_info[m.ep];

#define EPT_OPS_IX1          ept_ops_ix1[EPMIN]

#if (EP_SYM_METHOD == 1)
#define USE_EP_MOV           1
#define EPMIN                m.epi->min
#define EPMINC               c->epi->min
#define EP_MIN_OP            m.epi->op
#define EP_MOV_CODE          m.ep = ep_mov[c->ep][mv];
#endif

#if (EP_SYM_METHOD == 2)
#define USE_EP_MOV2          1
#define USE_EP_SYM2          1
#define EPMIN                m.epm.min
#define EPMINC               c->epm.min
// #define EP_MIN_OP            ep_min_op[m.ep]
#define EP_MIN_OP            inv_op[m.epm.op]  // see note below
#define EP_MOV_CODE          EP_MOV2_CODE_L1 EP_MOV2_CODE_L2 EP_MOV2_CODE_L3
#endif

/* note regarding EP_MIN_OP: 
   inv_op[m.epm.op] does not match ep_min_op[m.ep] for ep's with multiple
   sym min ops hence mkd6 cannot use it nor can solve (in the dist6 section),
   but all other cases are ok because whenever there is an ep with multiple
   sym min ops, ept_min_op is used instead.
*/

#if (ET_SYM_METHOD == 1)
#define USE_ET_SYM           1
#define USE_ET_SYM_FR        1
#define USE_ET_SYM_UF        1
#define USE_GET_ETSYM_M1     1
#define GET_ETSYM            get_etsym_m1
#endif

#if (ET_SYM_METHOD == 2)
#define USE_ET_SYM           1
#define USE_ET_SYM_FR        1
#define USE_GET_ETSYM_M2     1
#define GET_ETSYM            get_etsym_m2
#endif

#if (ET_SYM_METHOD == 3)
#define USE_ET_FR            1
#define USE_ET_UF            1
#define USE_GET_ETSYM_M3     1
#define USE_ET_SYM16         1
#define GET_ETSYM            get_etsym_m3
#endif

#if (ET_SYM_METHOD == 4)
#define USE_ET_FR            1
#define USE_ETSYM_M4         1
#define USE_GET_ETSYM_M4     1
#define USE_ET_SYM32         1
#define GET_ETSYM            get_etsym_m4
#endif

#if (ET_SYM_METHOD == 5)
#define USE_ET_FR            1
#define USE_ET_UF            1
#define USE_GET_ETSYM_M5     1
#define USE_ET_SYM16         1
#define GET_ETSYM            get_etsym_m5
#endif

#if (CP6C_SYM_METHOD == 1)
#define USE_CP6C_MOV         1
#define USE_CP6C_INFO        1
//#define USE_CP6C_SYM       1
#define CP6C_MIN             cpi->min
#define CP6C_MOV_CODE        m.cp6c = cp6c_mov[c->cp6c][mv];
#endif

#if (CP6C_SYM_METHOD == 2)
#define USE_CP6C_SYM2        1
#define USE_CP6C_MOV2        1
#define CP6C_MIN             m.cp6cm.min
#define CP6C_MOV_CODE        CP6C_MOV2_CODE_L1; CP6C_MOV2_CODE_L2;
#endif

#if (CT_SYM_METHOD == 1)
#define USE_CP_SYM           1
#define USE_CT_SYM           1
#define USE_GET_MIN_OP_3C_M1 1 
#define CPSYM                cpsym
#define CTSYM                ctsym
#define GET_MIN_OP_3C        get_min_op_3c_m1
#define CORNER_MOV_CODE      CP_MOV_CODE CT_MOV_CODE
#define CORNER_SYM_CODE      CP_SYM_CODE CT_SYM_CODE
#define CORNER_3C_SOLVED     (m.cp == 0 && m.ct == 0)
#define CT_SYM_DECLARE       int cpsym, ctsym;
#endif

#if (CT_SYM_METHOD == 2)
#define CT_SYM_DECLARE
#define USE_CPT_MOV          1
#define USE_CPT_SYM          1
#define USE_GET_MIN_OP_3C_M2 1 
#define CPSYM                csym->cp
#define CTSYM                csym->ct
#define GET_MIN_OP_3C        get_min_op_3c_m2
#define CORNER_MOV_CODE      CPT_MOV_CODE_L1 CPT_MOV_CODE_L2
#define CORNER_SYM_CODE      CPT_SYM_CODE
#define CORNER_3C_SOLVED     (m.cpt.min == 0)
#endif

#if (CT_SYM_METHOD == 3)
#define USE_CP_SYM           1
#define USE_CPT_MOV          1
#define USE_CP_SYM_MAP       1
#define USE_CPT_SYM2         1
#define USE_GET_MIN_OP_3C_M3 1 
#define CPSYM                cpsym
#define CTSYM                ctsym
#define GET_MIN_OP_3C        get_min_op_3c_m3
#define CORNER_MOV_CODE      CP_MOV_CODE CPT_MOV_CODE_L1 CPT_MOV_CODE_L2
#define CORNER_SYM_CODE      CP_SYM_CODE CPT_SYM2_CODE
#define CORNER_3C_SOLVED     (m.cpt.min == 0)
#define CT_SYM_DECLARE       int cpsym, ctsym;
#endif

#if (CT_SYM_METHOD == 4)
#define USE_CP_SYM           1
#define USE_CT_SYM3          1
#define USE_CT_SYM_UF        1
#define USE_CT_SYM_UR        1
#define USE_GET_MIN_OP_3C_M4 1 
#define USE_GET_CTSYM_M4     1
#define USE_OP16C            1
#define USE_CT_SYM2          1
#define USE_CT_SYM_ARR       1
#define CPSYM                cpsym
#define CTSYM                ctsym
#define GET_CTSYM            get_ctsym_m4
#define GET_MIN_OP_3C        get_min_op_3c_m4
#define CORNER_MOV_CODE      CP_MOV_CODE CT_MOV_CODE
#define CORNER_SYM_CODE      CP_SYM_CODE ctsym = GET_CTSYM(m.cp, m.ct, m.op)
#define CORNER_3C_SOLVED     (m.cp == 0 && m.ct == 0)
#define CT_SYM_DECLARE       int cpsym, ctsym;
#endif

#if (CT_SYM_METHOD == 5)
#define USE_CP_SYM           1
#define USE_CT_SYM3          1
#define USE_CT_UF            1
#define USE_CT_UR            1
#define USE_GET_MIN_OP_3C_M4 1   // uses method 4 code
#define USE_GET_CTSYM_M5     1
#define USE_DIV_81           1
#define USE_OP16C            1
#define USE_CT_SYM2          1
#define USE_CT_SYM_ARR       1
#define CPSYM                cpsym
#define CTSYM                ctsym
#define GET_CTSYM            get_ctsym_m5
#define GET_MIN_OP_3C        get_min_op_3c_m4
#define CORNER_MOV_CODE      CP_MOV_CODE CT_MOV_CODE
#define CORNER_SYM_CODE      CP_SYM_CODE ctsym = GET_CTSYM(m.cp, m.ct, m.op)
#define CORNER_3C_SOLVED     (m.cp == 0 && m.ct == 0)
#define CT_SYM_DECLARE       int cpsym, ctsym;
#endif

#if (EPR_SYM_METHOD == 1)
#define USE_EPR_SYM_M1       1
#define USE_EPR_SYM2         0
#define USE_GET_EPRSYM_M1    1
#define GET_EPRSYM           get_eprsym_m1
#define EPR_SYM_CODE_NEW     EPRsym = epr_sym_m1(&m);
#define EPR_SYM_CODE_NEW     EPRsym = epr_sym_m1(&m);
#else
#define USE_EPR_SYM_M2       1
#define USE_EPR_SYM2         1
#define USE_GET_EPRSYM_M2    1 
#define GET_EPRSYM           get_eprsym_m2  
#define EPR_SYM_CODE_NEW     EPRsym = epr_sym_m2(&m);
#endif

#if (EPR_MOV_METHOD == 1)
#define USE_EPR_MOV2         0
#define USE_EPR_MOV_M1       1
#define EPR_MOV_CODE_NEW     EPRsym = epr_mov_m1(&m);
#else
#define USE_EPR_MOV2         1
#define USE_EPR_MOV_M2       1
#define EPR_MOV_CODE_NEW     EPRsym = epr_mov_m2(&m);
#endif

#if (SHOW_EPT_STATS)
#define STAT1_COUNT ept_min_op_count[phase]++;
#define STAT2_COUNT get_min_op_count[phase]++;
#define STAT3_COUNT second_etsym_count[phase]++;
#else
#define STAT1_COUNT 
#define STAT2_COUNT 
#define STAT3_COUNT 
#endif

#if (EP_SYM_METHOD == 1)
#define EPT_OP_IX m.epi->op_ix
#else
#if (EPT_OP_METHOD == 1)
#define EPT_OP_IX ept_op_idx[m.ep]
#else
#define EPT_OP_IX ept_op_ix2[EPMIN]
#endif
#endif

#if (EPT_OP_METHOD == 1)
#define USE_EPT_MIN_OP_M1    1
#define USE_EPT_MIN_OP       1
#define GET_MIN_OP_TEST      (m.ops_idx != NIL)
#define OP_CODE				        \
  if (EPT_OP_IX != NIL)				\
    m.op = ept_min_op[EPT_OP_IX][m.et];		\
  else					        \
    m.op = EP_MIN_OP;
#define EPT_MIN_OP_CODE(get_min_op)		\
  if (EPT_OP_IX != NIL)				\
    { STAT1_COUNT				\
      m.op_ept = m.op;				\
      m.ops_idx =ept_ops_ix2[EPT_OPS_IX1][m.etsym];	\
      if (m.ops_idx != NIL)			\
	{ STAT2_COUNT				\
          CHECK_RUNTIME            		\
	  get_min_op(&m);			\
	}					\
    }
#endif  // #if (EPT_OP_METHOD == 1)

#if (EPT_OP_METHOD == 2)
#define USE_EPT_MIN_OP2      1
#define OP_CODE              m.op = EP_MIN_OP;
#define GET_MIN_OP_TEST      (opi->f)
#define USE_EPT_MIN_OP_M2    0
#define EPT_MIN_ET           GET_ETSYM(&m);

#define EPT_MIN_OP_CODE(get_min_op)				\
  if (EPT_OP_IX != NIL)						\
    { STAT1_COUNT						\
      opi = &ept_min_op2[EPT_OP_IX][m.etsym];	                \
      if (opi->op)				                \
	{ STAT3_COUNT						\
	  m.op = op_op[m.op][opi->op];				\
	  m.etsym = EPT_MIN_ET;		                        \
	}							\
      m.op_ept = m.op;                                          \
      if (opi->f)					        \
 	{ STAT2_COUNT						\
          CHECK_RUNTIME                         		\
	  m.ops_idx = ept_ops_ix2[EPT_OPS_IX1][m.etsym];	\
	  get_min_op(&m);					\
	}							\
    }
#endif  // #if (EPT_OP_METHOD == 2)

#define APPLY_MOVE_3C				\
  EP_MOV_CODE					\
  ET_MOV_CODE					\
  CORNER_MOV_CODE				\
  EPI_CODE					\
  OP_CODE					\
  ET_SYM_CODE					\
  EPT_MIN_OP_CODE(GET_MIN_OP_3C)		\
  CORNER_SYM_CODE

#define APPLY_MOVE_E6C				\
  EP_MOV_CODE					\
  ET_MOV_CODE					\
  EPR_MOV_CODE  				\
  EPI_CODE					\
  OP_CODE					\
  ET_SYM_CODE					\
  EPT_MIN_OP_CODE(get_min_op_e6c)		\
  EPR_SYM_CODE_NEW

#define  EP0 c->epi->s0
#define  EP1 c->epi->s1
#define  EP2 c->epi->s2

#define  EP0m m.epi->s0
#define  EP1m m.epi->s1
#define  EP2m m.epi->s2

#if USE_EPR_MOV2
#define EPR_MOV_CODE  \
  m.epr[0] = epr_mov2[epr_mov_idx[EP0][mv]][c->epr[0]]; \
  m.epr[1] = epr_mov2[epr_mov_idx[EP1][mv]][c->epr[1]]; \
  m.epr[2] = epr_mov2[epr_mov_idx[EP2][mv]][c->epr[2]];
#else
#define EPR_MOV_CODE  \
  m.epr[0] = epr_mov[EP0][c->epr[0]][mv]; \
  m.epr[1] = epr_mov[EP1][c->epr[1]][mv]; \
  m.epr[2] = epr_mov[EP2][c->epr[2]][mv];
#endif

#if USE_EPR_SYM2
#define EPR_SYM_CODE  \
  eprsym[slice_map[m.op][0]] = epr_sym2[epr_idx[m.op][EP0m][0]][m.epr[0]]; \
  eprsym[slice_map[m.op][1]] = epr_sym2[epr_idx[m.op][EP1m][1]][m.epr[1]]; \
  eprsym[slice_map[m.op][2]] = epr_sym2[epr_idx[m.op][EP2m][2]][m.epr[2]];
#else
#define EPR_SYM_CODE  \
  eprsym[slice_map[m.op][0]] = epr_sym[m.op][EP0m][m.epr[0]][0]; \
  eprsym[slice_map[m.op][1]] = epr_sym[m.op][EP1m][m.epr[1]][1]; \
  eprsym[slice_map[m.op][2]] = epr_sym[m.op][EP2m][m.epr[2]][2];
#endif

#if (SHOW_EPT_STATS)
int ept_min_op_count[2];
int get_min_op_count[2];
int second_etsym_count[2];
#endif

#define SHOW_DEPENDENCY_MSGS 0

#define SHOW_MIN_OP_COUNT    TRUE   // see ept_stat.c

// 3C = 3 Color cube, 6C = 6 Color cube

#define C_PERM          40320   // 6C corner perms
#define C_PRM           70      // 3C corner perms
#define C_PRMr          576     // 6C/3C corner perms
#define C_PRM_TW        153090  // 3C corners
#define C_TWIST         2187    // corner twist
#define E_PRM           34650   // 3C edge perms
#define E_PRMr          13824   // 6C/3C edge perms
#define E_TWIST         2048    // edge twist (flip)
#define MIN_EP          782     // 3C edge perms reduced by symmetry
#define MIN_CP6C        984     // 6C corner perms  reduced by symmetry
#define MIN_CPT         3393    // 3C corners reduced by symmetry
#define MIN_EP_ET       1601536 // MIN_EP * E_TWIST
#define MIN_EPT         1482170 // 3C edges reduced by symmetry
#define EP_MULTI_MIN_OP 2058    // EPs with multiple symmetry min ops
#define N_EPT_MIN_OP    1290    // #rows in ept_min_op (deduplicated)
#define N_EPT_OPS_IX2   103     // #rows in ept_ops_ix2
#define N_EPT_MIN_OP2   57      // #uniq rows in ept_min_op2
#define N_EPT_MIN_OPS   7331    // #rows in ept_min_ops
#define N_EPR_SYM2      176     // #rows in epr_sym2 (uniq)
#define N_ET_FR         114     // #rows in et_fr (uniq)
#define N_ET_UF         114     // #rows in et_uf (uniq)
#define N_CT_UF         24
#define N_CT_UR         24
#define N_CT_IX3        24
#define N_POP_LIST      100     // max #rows in pop_list used by populated2
#define N_POP_WIDTH     15      // max length of array name
#define CP6C_OP_ROW     32      // row in cp6c_sym with 48 uniq sym
#define OP_FR           1       // sym op that moves cube Front->Right
#define OP_UF           13      // sym op that moves cube Up->Front
#define OP_UFc          2       // see notes in init_op16c() in rclib.c
#define OP_URc          20      // see notes in init_op16c() in rclib.c
#define B2_MAX          128     // 2^7
#define B3_MAX          177147  // 3^11
#define SLICE_PERM_TW   190080  // 6C slice perm + twist
#define SLICE_PRM       495     // 3C slice permutations
#define CUBE_SYM        48      // cube symmetries
#define DAT_FNAME_LEN   21      // dat file name length
#define STACK_DEPTH     30      
#define FACELETS        54
#define CHAR            1
#define SHORT           2
#define INT             4
#define ETIX_TYPE       4
#define NIL             -1
#define MEG             1048576 

// max size of cfg lists used by chk_dup_3c & chk_dup_6c

#if (QTM)
#define CFG_LIST_3C     1000   // 946
#define CFG_LIST_6C     2300   // 2228
#else
#define CFG_LIST_3C     3400   // 3307
#define CFG_LIST_6C     14000  // 13100
#endif

#define EPR(arr) ((arr[0]*24 + arr[1])*24 + arr[2])

#define SEQ_GEN(mv, prev) (((mv&1)||mv==prev) ? seq_gen[mv] : seq_gen2[mv])

#define S_CUBE s_cube3

struct s_cube
{
  char cps[8];
  char cts[8];
  char eps[12];
  char ets[12];
  int cp6c;
  int ct;
  int ep;
  int et; 
  char epr[3];
};

struct s_info
{
  #if (EP_SYM_METHOD == 1)
  #if (EPT_OP_METHOD == 1)
  short op_ix;                 // ept_op_idx
  unsigned short op  : 6;
  unsigned short min : 10;
  #elif (EPT_OP_METHOD == 2)
  char op_ix;                  // ept_op_ix2
  unsigned char op;
  unsigned short min;
  #endif
  #endif
  unsigned int s0  : 9;
  unsigned int s1  : 9;
  unsigned int s2  : 9;
};

struct s_min
{	
  short op;
  short min;
};

struct s_cptmin
{	
  char op;
  unsigned char min[2];
};

struct s_cpt
{	
  short cp;
  short ct;
};

struct s_op16 
{
  char op1;
  char op2;
};

struct s_epmin
{
  unsigned short op:    6;
  unsigned short min:  10;
};

struct s_cube2
{
  int ep;
  int et;
  int cp6c;
  char epr[3];
  struct s_min cpt;
  struct s_info *epi;
};

struct s_op_info2
{
  unsigned char op:      6;
  unsigned char f:       1;
};

struct s_op_info
{
#if USE_EPT_MIN_OP2
  // unsigned char op:     6;
  // char idx:             1;
  unsigned int op:      6;
  unsigned int etsym:  11;
  int idx:    14;
#else
  short idx;
#endif
};

struct s_cube3
{
  int op;
  int op_ix;
  int ops_idx;
  int ep;
  int epmin;
  int etsym;
  struct s_epmin epm;
  int et;
  char cp;
  short ct;
  struct s_min cpt;
  struct s_info *epi;
  char epr[3];
  int cp6c;
  struct s_min cp6cm;

  #if USE_GET_MIN_OP_E6C
  int op_ept;
  #endif

};

struct s_et_ix
{
  short base;
  char ix;
};

struct s_ct_ix
{
  short base;
  char ix;
};

FILE *fp;
void exit(), *memcpy();
char *strcpy(), *strncpy();

char    metric;
char	untwc[3]; 
char    center_idx[6];
char    pop_list_ix;
char    pop_list[N_POP_LIST][N_POP_WIDTH];
char	b2_cp[B2_MAX],  cp_b2[C_PRM];
char	cnr[8][3],      edg[12][2];
char    cnr2[8][3],     edg2[12][2];
char	cnr_idx[8][3],  edg_idx[12][2];
char	cmv[18][8],     emv[18][12];
char    qtm_ftm[12],    ftm_qtm[18];
char    ccw_mv[18];
char    cp6c_cp3c[C_PERM];
short	cp6c_cpr[C_PERM];
unsigned short b3_ep[B3_MAX];
int	cfg_idx;
int     phase;
int     mvlist1[3], mvlist2[MOVES+1];
int	ep_b3[E_PRM];
int     p2_dist_in[24], p2_dist_out[16];
int	(*etw[18])(), (*ctw[18])();
unsigned int nodes_total[2];

/****************************** move arrays ******************************/

#if USE_EP_MOV
unsigned short ep_mov[E_PRM][MOVES];
#endif

#if USE_CPT_MOV
struct s_min cpt_mov[MIN_CPT][MOVES];
#endif

#if USE_CP6C_MOV
unsigned short cp6c_mov[C_PERM][MOVES];
#endif

struct s_epmin3
{
  unsigned short op;
  unsigned short min;
};

/*************************** symmetry arrays ******************************/

char    cpt_min_op[C_PRM_TW];
char    epr_min_op[E_PRMr];
char    slice_map[CUBE_SYM][3];
short   ep_slice[E_PRM][3];
short   min_ep[MIN_EP];
short	ept_ops_ix2[N_EPT_OPS_IX2][E_TWIST];
short	cpt_min[C_PRM_TW];
int     b2_slice[4096];
int     slice_ep[SLICE_PRM][3];
int	min_cp6c[MIN_CP6C];
int     ep_min[E_PRM];
int     cp6c_min[C_PERM];
int     min_op_count, min_op_count2;

struct  s_op16 op16e[CUBE_SYM];

#if (ET_SYM_METHOD == 3 || ET_SYM_METHOD == 4)
struct s_et_ix et_fr_ix[SLICE_PRM][16];
struct s_et_ix et_uf_ix[SLICE_PRM][32];
#endif

#if USE_EPT_MIN_OP
char ept_min_op[N_EPT_MIN_OP][E_TWIST];
int  ept_op_idx[E_PRM];
#endif

unsigned short ept_min_ops[N_EPT_MIN_OPS][27];

#if USE_OP16C
struct   s_op16 op16c[CUBE_SYM];
#endif

int op_new[CUBE_SYM];

#if USE_CT_SYM_UF
unsigned short ct_sym_uf[C_PRM][C_TWIST];
unsigned short ct_sym_ur[C_PRM][C_TWIST];
#endif

#if USE_CPT_SYM
struct s_cpt cpt_sym[MIN_CPT][CUBE_SYM];
#endif

#if USE_CPT_SYM2
short cpt_sym2[MIN_CPT][CUBE_SYM];
#endif

#if USE_ET_SYM
short et_sym[E_TWIST][CUBE_SYM];
#endif

#if USE_ET_SYM_FR
short et_sym_FR[SLICE_PRM][E_TWIST];
#endif

#if USE_ET_SYM_UF
short et_sym_UF[SLICE_PRM][E_TWIST];
#endif

#if USE_CP6C_INFO
struct s_min cp6c_info[C_PERM];
#endif

#if USE_CT_SYM
short ct_sym[C_PRM][C_TWIST][CUBE_SYM];
#endif

struct s_min_op
{
  unsigned char op : 6;
  unsigned char f  : 1;
};

/************************ cache  ************************/

struct s_info ep_info[E_PRM];

struct s_min_op ept_min_op2[57][E_TWIST];

#if USE_CP6C_SYM2
unsigned short cp6c_sym2[MIN_CP6C][CUBE_SYM];
#endif

#if USE_EP_SYM2
unsigned short ep_sym2[MIN_EP][CUBE_SYM];
#endif

#if USE_CT_SYM3
short ct_sym3[C_TWIST][16];
#endif

#if USE_ET_SYM16
short   et_sym16[E_TWIST][16];
#endif

#if USE_ET_SYM32
short   et_sym32[E_TWIST][32];
#endif


short	ct_mov[C_TWIST][MOVES];
short   et_mov[E_TWIST][MOVES];

#if USE_CP6C_MOV2
struct s_min cp6c_mov2[MIN_CP6C][MOVES];
#endif

char    cp6c_min_op[C_PERM];
char	ep_min_op[E_PRM];

#if USE_EP_MOV2
struct s_epmin ep_mov2[MIN_EP][MOVES];
#endif 

#if (ET_SYM_METHOD == 5)
short et_uf_ixb[SLICE_PRM*32];
char  et_uf_ixv[SLICE_PRM*32];
short et_fr_ixb[SLICE_PRM*16];
char  et_fr_ixv[SLICE_PRM*16];
#endif

#if USE_ET_FR
char et_fr[N_ET_FR][128];
#endif

#if USE_ET_UF
short et_uf[N_ET_UF][64];
#endif

struct s_ct_ix ct_uf_ix[70][27];
struct s_ct_ix ct_ur_ix[70][27];

#if USE_EPR_MOV2
char    epr_mov2[24][24];
char    epr_mov_idx[SLICE_PRM][MOVES];
#else 
char    epr_mov[SLICE_PRM][24][MOVES];
#endif

#if USE_EPR_SYM2
char    epr_sym2[N_EPR_SYM2][24];
unsigned char epr_idx[CUBE_SYM][SLICE_PRM][3];
#else
char    epr_sym[CUBE_SYM][SLICE_PRM][24][3];
#endif

#if USE_CP_SYM
char cp_sym[C_PRM][CUBE_SYM];
#endif

char    op_op[CUBE_SYM][CUBE_SYM];
char    op_mv[CUBE_SYM][MOVES];
char	inv_op[CUBE_SYM];

#if USE_DIV_81
char div_81[C_TWIST];
char mod_81[C_TWIST];
#endif

#if USE_CT_UF
char  ct_uf[24][81];
#endif

#if USE_CT_UR
char  ct_ur[24][81];      
#endif

char	cp_mov[C_PRM][MOVES];
char    ept_ops_ix1[MIN_EP];
char    ept_op_ix2[MIN_EP];
int     seq_gen[MOVES][MOVES];
int     seq_gen2[MOVES][MOVES];
