// Author: Michael Feather 
// This file contains routines used for multi-processing

#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>

#define PID_LIST_SIZE 30
#define SHOW_DEBUG_MESSAGES 0

int ppid, child_procs, pid_list[PID_LIST_SIZE];

wait_for_proc()
{		  
  int pid, status;	

  pid = wait(&status);
  clear_pid(pid);
  --child_procs;

  if (WIFEXITED(status) != 0)		    
      return(WEXITSTATUS(status));
  else
    printf("Warning: sub-process error, abnormal exit code received\n");
  
}

add_pid(pid)
     int pid;
{
  int i, f;
  
  for (i=f=0; i < PID_LIST_SIZE; i++)
    if (pid_list[i] == 0)
      {
	#if SHOW_DEBUG_MESSAGES
	printf("add: %2d %d\n", i, pid);
	#endif

	pid_list[i] = pid;
	f=1;
	break;
      }

  if (f != 1)
    {
      printf("ERROR: Too many pids\n");
      exit(0);
    }
  return;
}

clear_pid(pid)
     int pid;
{
  int i, f;

  for (i=f=0; i < PID_LIST_SIZE; i++)
    if (pid_list[i] == pid)
      {
	#if SHOW_DEBUG_MESSAGES
	printf("del: %2d %d\n", i, pid);
	#endif

	pid_list[i] = 0;
	f = 1;
	break;
      }
  if (f != 1)
  {
    printf("ERROR: Pid not found: %d\n", pid);
    exit(0);
  }
}

term_pid_list()
{
  int i, status;

  for (i=0; i < PID_LIST_SIZE; i++)
    if (pid_list[i] != 0)
      {

	#if SHOW_DEBUG_MESSAGES
	printf("term: %2d %d\n", i, pid_list[i]);
	#endif

	kill(pid_list[i], SIGTERM);
	(void)wait(&status);

	if (WIFEXITED(status) == 0 && WTERMSIG(status) != SIGTERM)
	{
	  printf("Warning: abnormal exit on pid: %d\n", pid_list[i]);
	  printf("         WIFEXITED=%d\n", WIFEXITED(status));
	  printf("         WIFSIGNALED=%d\n", WIFSIGNALED(status)); 
	  printf("         WTERMSIG=%d\n", WTERMSIG(status));
	  printf("         WEXITSTATUS=%d\n", WEXITSTATUS(status));
	}
	pid_list[i] = 0;
	--child_procs;
      }
}

new_proc(child, max)
     int *child, max;
{
  int pid;

  if (child_procs >= max)
    wait_proc();
  
  child_procs++;
  pid = fork();
  
  if (pid == 0)
      *child = 1;
  else
    {
      add_pid(pid);
      return(1);
    }
  return(0);
}
