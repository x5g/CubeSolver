// Author: Michael Feather

#include "rc.h"
#include "dist.h"
#include "ctype.h"
#include "time.h"
#include <sys/timeb.h>

// Default maximum optimal search depth (can be passed as a parameter)

#define MAX_DEP_DFLT_QTM    26
#define MAX_DEP_DFLT_FTM    20

// Default maximum depth when opt_only is in effect

#define MAX_DEP_OPTO_QTM    15 
#define MAX_DEP_OPTO_FTM    16

/* Normal Search runs until the first optimal solution is found, a
   sub-optimal solution is proved optimal or the max optimal search 
   depth is reached.
*/

#define STOP_FIRST_SUBOPT   FALSE  // stop after first sub-optimal solution
#define STOP_FIRST_DEPTH    FALSE  // complete depth of first subopt soln
#define STOP_SOLN_LEN       0      // stop after first soln with len <= N, 0 = not used
#define FIND_ALL_OPTIMAL    FALSE  // find all optimal solutions

#define SHOW_NODE_COUNTS    TRUE   // show #nodes generated at each depth
#define SHOW_PRUNE_COUNTS   FALSE  // show #nodes pruned by each dist array 
#define SHOW_PRUNE_DEPTH    14     // depth to start showing prune counts
#define SHOW_PRUNE_PHASE    1      // 1=phase1, 2=phase2, 3=both

#define RUNTIME_LIMIT       0      // 0 = unlimited, overrides MAX_RTLP
#define RTL_PER_CUBE        0      // 0 = unlimited
#define USE_RTL_PARAM       1      // param is rtl instead of depth
#define MAX_RTLP            30
#define SHOW_RTL_LIMITS     FALSE
#define MAX_INVALID_CUBES   3

#define SHOW_DEFINES        FALSE
#define SHOW_METHODS        FALSE

#define USE_MAX_D1_DIST     FALSE
#define USE_MAX_D2_DIST     FALSE

#define BLANK_ARRAYS        FALSE

#if QUARTER_TURN_METRIC
  #define MAX_D1_DIST       11
  #define MAX_D2_DIST       11
  #define MAX_D5_DIST       12
  #define MAX_D6_DIST       10
  #define MAX_D7_DIST       12
  #define MAX_P2_DIST       12   // must be <= P2_GEN_DEPTH
  #define OVERREACH_6C      8    // #moves 6C search dep > opt search dep
  #define OPT_ONLY_DEPTH    18
  #define OPT_ONLY_TIME     120 
#else
  #define MAX_D1_DIST       10
  #define MAX_D2_DIST       10
  #define MAX_D5_DIST       10 
  #define MAX_D6_DIST       9
  #define MAX_D7_DIST       11 
  #define MAX_P2_DIST       8
  #define OVERREACH_6C      6
  #define OPT_ONLY_DEPTH    14
  #define OPT_ONLY_TIME     20 
#endif

// Show an alert if P2_GEN_DEPTH is too low to prune a 3C solution 

#define SHOW_ALERT          TRUE 

/* For QTM, the following option will yield single-letter per move solutions:
   uppercase = clockwise
   lowercase = anti-clockwise
 */

#define USE_ALT_QTM_NOTATION FALSE   

/* Multi-processing is implemented by forking a separate search process for
   each node generated at the first depth, hence up to 12 for QTM & 18 for
   FTM.  There is no communication between the sub-processes so the output
   may show more than one solution at the same depth or they may be out of
   order (one child finds a solution with length greater than another has
   already found). Also, node & prune counts should be turned off as they
   will be zero after MULTI_PROC_MIN_DEPTH is reached.  
   Note: to use multi-processing, append mplib.o to entry "solve" in Makefile
*/

#define MULTI_PROC_ENABLED   FALSE
#define MULTI_PROC_MIN_DEPTH 14    // depth to start multi-processing
#define MAX_CHILD_PROCS      3     // up to 12 for QTM, 18 for FTM

#define MINMV_INIT           99
#define CPT                  (csym->cp*C_TWIST + csym->ct) 
#define FAO                  FIND_ALL_OPTIMAL

#define CHECK_RUNTIME        check_runtime();

char    disp[6] = {'R', 'L', 'U', 'D', 'F', 'B'};
char    alt_disp[12] = {'R','r','L','l','U','u','D','d','F','f','B','b'};

#if (QTM)
  char    disp2[2] = {' ', '\'' };
#else
  char    disp2[3] = {' ', '2', '\'' };
#endif

char    advance[MOVES];
char    eps_sav[2][12];
char    seq[2][STACK_DEPTH];

int     max_depth_param;
int     p2dist;
int     runtime_exceeded;
int     minmv_flag, opt_only;
int	max_depth, minmv, phase;
int     cube_3C_soln;
int     ppid, child_procs, pid_list[MOVES];
int     tests[2], solutions_3C[2], depth[2], depth_6C[2];
int     rtlp;
int     search_extended;
int     opt_soln_ct;

time_t  time1, time2, get_time();
struct timeb ftime1, ftime2;

unsigned int nodes[2];

jmp_buf env1, env2;

struct s_count
{
  unsigned long long nodes;
  unsigned long long pruned;
};

struct s_count counts[2][10];

size_t strlen();

main(argc, argv)
     int argc;
     char **argv;
{
  time1 = time(0);
  ftime(&ftime1);

  if (check_params(argc, argv) != 0)
    exit(1);

  if (process_file(argv[1]) != 0)
    exit(1);
}

process_file(fname)
     char *fname;
{
  FILE *cube_file;
  int valid_cubes=0, invalid_cubes=0, scrambled_cubes=0;
  char initdone=0, rtn, cubestr[54];
  struct s_cube cube;

  if (SHOW_DEFINES || SHOW_METHODS)
    show_settings();

  if ((cube_file = fopen(fname,"r")) == NULL)
    {
      printf("Error opening file: %s\n", fname);
      return(1);
    }

  while (runtime_exceeded == 0)
    {
      rtn = load_cube_fp(cube_file, cubestr);

      if (rtn != FACELETS)
	{
	  if (rtn != 0)
	    invalid_cubes++;

	  if (rtn == 0 && valid_cubes+invalid_cubes == 0)
	    printf("\nERROR: Empty File: %s\n", fname);
	  
	  break;
	}
  
      rtn = verify_cubestr(cubestr, &cube);
      
      if (rtn == 0)
	{
	  valid_cubes++;
	  scrambled_cubes++;

	  if (!initdone)
	    {
	      if (init() != 0)
		return;

	      initdone = 1;
	      show_ftime(ftime1, "Init Time:");
	    }

	  printf("\n");
	  show_cubestr(cubestr, 0);
	  minmv = MINMV_INIT;
	  depth_6C[0] = MINMV_INIT;
	  minmv_flag = 0;
	  time2 = time(0);
	  ftime(&ftime2);

	  if (setjmp(env1) == 0)
	    solve(&cube);
	}
      else
	{
	  printf("\n");
	  show_cubestr(cubestr, 0);
	  cube_status_msg(rtn);

	  if (rtn == 1)
	    valid_cubes++;
	  else
	    {
	      invalid_cubes++;

	      if (valid_cubes == 0)
		break;

	      if (invalid_cubes >= MAX_INVALID_CUBES)
		{
		  printf("\nERROR: Too Many Invalid Cubes\n");
		  break;
		}
	    }
	}
    }

  fclose(cube_file);

  if (invalid_cubes == 1 && valid_cubes == 0)
    show_cube_file_format();
  
  if (valid_cubes+invalid_cubes > 1)
      printf("\nEnd of Cube File\n");

  if (scrambled_cubes > 0)
  {
    show_ftime(ftime1, "Total Time: ");
  }

  printf("\n");
  return(0);
}

solve(cube)
     struct s_cube *cube;
{
  int cp, n, dst, tmp, first, incr, cube_parity;
  struct s_min cpt;
  struct S_CUBE c;

  update_cube_in(cube);  // assign cp6c, ct, ep, et, epr

  // assign to structure cpt the symmetry minimum corner config 
  // and the operation that converts it to the actual config

  cp = cp6c_cp3c[cube->cp6c];
  n = cp*C_TWIST + cube->ct;
  cpt.min = cpt_min[n];
  cpt.op  = inv_op[cpt_min_op[n]];
  
  memcpy(eps_sav[0], cube->eps, 12);
  phase = 0;
  cube_3C_soln = (cube->ep==0 && cube->et==0 && cpt.min==0) ? 1 : 0;
  cube_parity = parity(cube->eps,12);

  opt_only = FALSE;

  if (QTM) 
    {
      first = 2-cube_parity;
      incr = 2;
      printf("Solutions will have an %s number of moves\n\n",
	     ((cube_parity) ? "Odd": "Even"));
      fflush(stdout);
    }
  else
    first = incr = 1;

  c.cp = cp;
  c.ct = cube->ct;

  c.ep = cube->ep;
  c.et = cube->et;

  c.epm.min = ep_min[c.ep];
  c.epm.op = inv_op[ep_min_op[c.ep]];

  memcpy(c.epr, cube->epr, 3);
  c.cp6c = cube->cp6c;
  c.cp6cm.min = cp6c_min[c.cp6c];
  c.cp6cm.op = inv_op[cp6c_min_op[c.cp6c]];
  c.cpt.min = cpt.min;
  c.cpt.op = cpt.op;
  c.epi = &ep_info[c.ep];

  p2dist = 0;

    if ((QTM && P2_GEN_DEPTH == 21) || (!QTM && P2_GEN_DEPTH == 15))
    if (c.ep == 0 && c.et == 0 && c.cp == 0 && c.ct == 0)
      {
        tmp = EPR(c.epr);
        dst = distp2[cp6c_cpr[c.cp6c]][tmp>>1];
        if (QTM)
          dst = p2_dist_out[((tmp&1) ? dst>>4 : dst&0xF)];
        else
        {
          dst = ((tmp&1) ? dst>>4 : dst&0xF);

          if (dst == 0)
 	    if(c.cp6c != 0 || tmp != 0)
              dst = 16;
        }

        // for QTM, one & only one 23 move 3C solution

        if (dst == 22 && cube_parity) 
          p2dist = 23;   
        else
          p2dist = dst;

        printf("This cube can be solved in %d moves\n\n", p2dist);

      }

  if (BLANK_ARRAYS)
    blank_arrays();

  search_extended = 0;
  opt_soln_ct = 0;
  nodes_total[0] = nodes_total[1] = 0;

  if (SHOW_EPT_STATS)
    {
      init_ept_stats(0);
      init_ept_stats(1);
    }

  for (depth[0]=first; depth[0] <= max_depth; depth[0]+=incr)
    {
      set_depth_6C();
      nodes[0] = tests[0] = solutions_3C[0] = 0;

      if (SHOW_MIN_OP_COUNT)
	min_op_count = min_op_count2 = 0;

      if (SHOW_PRUNE_COUNTS)
	init_prune_counts();

      search(&c, 1, mvlist2);

      nodes_total[0] += nodes[0];
      nodes_total[1] += nodes[1];

      if (SHOW_NODE_COUNTS)
	{
	  printf("Depth %2d completed", depth[0]);
	  show_node_counts();
	}
      else if (depth[0] > 5)
	printf("Depth %2d completed\n", depth[0]);

      if (SHOW_PRUNE_COUNTS)
	show_prune_counts();

      if (SHOW_MIN_OP_COUNT)
	show_min_op_count();

      // end search if completed depth = optimal solution length
      
      if (depth[0] == minmv) 
	end_search(1);

      // end search if "proved" optimal

      if (depth[0] == minmv-incr && FAO == FALSE)
	  end_search(2);

      // end search if completed depth where first solution found

      if (STOP_FIRST_DEPTH && minmv != MINMV_INIT)
	end_search(6);
    }
  end_search(3);
}

//  The main search routine

search(c, n, mvlist)
     struct S_CUBE *c;
     int n, *mvlist;
{
  char eprsym[3];
  int i, dist, mv, rs, tmp, EPRsym, epmin;
  struct S_CUBE m;
  struct s_cpt *csym;
  struct s_min *cpi;
  struct s_min_op *opi;
  CT_SYM_DECLARE;

  #if MULTI_PROC_ENABLED
  int child=0;
  #endif

  for (i=0; (mv=mvlist[i]) != NIL; i++)
    {
      #if MULTI_PROC_ENABLED
      if (n == 1 && depth[phase] >= MULTI_PROC_MIN_DEPTH)
	if (new_proc(&child, MAX_CHILD_PROCS))
	  continue;
      #endif

      nodes[phase]++;

      EP_MOV_CODE;
      ET_MOV_CODE;
      CORNER_MOV_CODE;
      EPI_CODE;

      if (n == depth[phase])
	{  
	  tests[phase]++; 

	  // if 3C solution, test if 6C solution

	  if (m.ep == 0 && m.et == 0 && CORNER_3C_SOLVED)
	    {
	      CP6C_MOV_CODE;
	      EPR_MOV_CODE;
	      test_6C_solution(&m, n, mv); 
	    }

	  check_opt_only();
	}
      else    
	{
	  OP_CODE;
	  ET_SYM_CODE;
	  EPT_MIN_OP_CODE(GET_MIN_OP_3C);

          CORNER_SYM_CODE;

	  /******************************************************************/
          /*                              Dist3                             */
	  /******************************************************************/

	  if (USE_DIST3)
	    {
	      if (SHOW_PRUNE_COUNTS)
		counts[phase][3].nodes++;

	      rs = m.etsym>>D3_RS;
		  
	      if (DIST3_TYPE == 0)
		{
		  tmp = dist3[EPMIN][CTSYM][rs>>3] & (1<<(rs&7));
		  dist = (tmp) ? 0 : D3_RET+n;
		}
	      else if (DIST3_TYPE == 1)
		{
		  tmp = ((dist3[EPMIN][CTSYM][rs>>2]>>((rs&3)<<1))&3);
		  dist = (tmp) ? tmp+D3_RET+n : 0;
		}
	      else if (DIST3_TYPE == 2)
                {
	          tmp = dist3[EPMIN][CTSYM][rs>>1];
	          dist = n + ((rs&1) ? tmp>>4 : tmp&0xF);
                }

	      if (dist > depth[phase]) 
		{
		  if (SHOW_PRUNE_COUNTS)
		    counts[phase][3].pruned++;

		  continue;
		}
	    }

	  /******************************************************************/
          /*                              Dist4                             */
	  /******************************************************************/

	  if (USE_DIST4)
	    {
	      if (SHOW_PRUNE_COUNTS)
		counts[phase][4].nodes++;

	      rs = m.etsym>>D4_RS;

	      if (DIST4_TYPE == 0)
		{
		  tmp = dist4[CPT][EPMIN][rs>>3] & (1<<(rs&7));
		  dist = (tmp) ? 0 : D4_RET+n;
		}
	      else
		{
		  tmp = ((dist4[CPT][EPMIN][rs>>2]>>((rs&3)<<1))&3);
		  dist = (tmp) ? tmp+D4_RET+n : 0;
		}
		  
	      if (dist > depth[phase])
		{
		  if (SHOW_PRUNE_COUNTS)
		    counts[phase][4].pruned++;

		  continue;
		}
	    }

	  /******************************************************************/
          /*                              Dist1                             */
	  /******************************************************************/

	  if (USE_DIST1)
	    {
              #if USE_MAX_D1_DIST
	      if (depth[phase]-n < MAX_D1_DIST)
	      #endif
		{
		  if (SHOW_PRUNE_COUNTS)
		    counts[phase][1].nodes++;

		  tmp = dist1[EPMIN][CPSYM][CTSYM>>(D1_RS+1)];
		  dist = n + (((CTSYM>>D1_RS)&1) ? tmp>>4 : tmp&0xF);

		  if (dist > depth[phase])
		    {
		      if (SHOW_PRUNE_COUNTS)
			counts[phase][1].pruned++;
		      
		      continue;
		    }
		}
	    }

	  /******************************************************************/
          /*                              Dist2                             */
	  /******************************************************************/

	  if (USE_DIST2)
	    {
              #if USE_MAX_D2_DIST
	      if (depth[phase]-n < MAX_D2_DIST)
              #endif
		{
		  if (SHOW_PRUNE_COUNTS)
		    counts[phase][2].nodes++;
		  
		  tmp = dist2[EPMIN][CPSYM][m.etsym>>(D2_RS+1)];
		  dist = n + (((m.etsym>>D2_RS)&1) ? tmp>>4 : tmp&0xF);

		  if (dist > depth[phase])
		    {
		      if (SHOW_PRUNE_COUNTS)
			counts[phase][2].pruned++;

		      continue;
		    }
		}
	    }

	  /******************************************************************/

	  CP6C_MOV_CODE;
	  EPR_MOV_CODE;

	  seq[phase][n] = mv;

	  /******************************************************************/
          /*                              Dist7                             */
	  /******************************************************************/

	  #if USE_DIST7

	  if (depth_6C[phase]-n < MAX_D7_DIST)
	    {
	      if (SHOW_PRUNE_COUNTS)
		counts[phase][7].nodes++;

	      if (EPT_OP_IX == NIL)
		m.op = EP_MIN_OP;
	      else
                {
		  m.op = m.op_ept;

		  if (GET_MIN_OP_TEST)
		    get_min_op_e6c(&m);
		}
		
	      GET_EPRSYM(eprsym, m.epi, m.epr, m.op);

	      EPRsym = EPR(eprsym);
	      rs = m.etsym>>D7_RS;

	      if (DIST7_TYPE == 0)
		{
		  tmp = dist7[EPMIN][EPRsym][rs>>3] & (1<<(rs&7));
		  dist = (tmp) ? 0 : D7_RET+n;
		}
	      else if (DIST7_TYPE == 1)
		{
		  tmp = ((dist7[EPMIN][EPRsym][rs>>2]>>((rs&3)<<1))&3);
		  dist = (tmp) ? tmp+D7_RET+n : 0;
		}
	      else if (DIST7_TYPE == 2)
		{
		  tmp = dist7[EPMIN][EPRsym][rs>>1];
	          dist = n + ((rs&1) ? tmp>>4 : tmp&0xF);
		}

	      if (dist > depth_6C[phase])
		{
		  if (SHOW_PRUNE_COUNTS)
		    counts[phase][7].pruned++;
		  
		  continue;
		}
	    }
	  #endif
	  /******************************************************************/
          /*                              Dist5                             */
	  /******************************************************************/

          #if USE_DIST5
	  if (depth_6C[phase]-n < MAX_D5_DIST)
	    {
	      if (SHOW_PRUNE_COUNTS)
		counts[phase][5].nodes++;

              #if (CP6C_SYM_METHOD == 1)
	      cpi = &cp6c_info[m.cp6c];
	      m.op = cpi->op;

              #elif (CP6C_SYM_METHOD == 2)
	      m.cp6c = cp6c_sym2[m.cp6cm.min][m.cp6cm.op];
	      m.op = cp6c_min_op[m.cp6c];
              #endif

	      CORNER_SYM_CODE;

	      dist = dist5[CTSYM][CP6C_MIN>>1]; 
	      dist = n + ((CP6C_MIN&1) ? dist>>4 : dist&0xF);

	      if (dist > depth_6C[phase])
		{
		  if (SHOW_PRUNE_COUNTS)
		    counts[phase][5].pruned++;
		  
		  continue;
		}
	    }
          #endif

	  /******************************************************************/
          /*                              Dist6                             */
	  /******************************************************************/

          #if USE_DIST6
	  if (depth_6C[phase]-n < MAX_D6_DIST)
	    {  
              #if (EP_SYM_METHOD == 1)
              m.op = m.epi->op;
              #else
              m.op = ep_min_op[m.ep];
              #endif

              #if ! USE_DIST7
	      EPR_SYM_CODE;
	      EPRsym = EPR(eprsym);
              #endif

	      if (SHOW_PRUNE_COUNTS)
		counts[phase][6].nodes++;
	      
	      dist = dist6[EPMIN][EPRsym>>1];
	      dist = n + ((EPRsym&1) ? dist>>4 : dist&0xF);

	      if (dist > depth_6C[phase])
		{
		  if (SHOW_PRUNE_COUNTS)
		    counts[phase][6].pruned++;

		  continue;
		}
	    }
          #endif

	  /******************************************************************/
          /*                            Dist P2                             */
	  /******************************************************************/

	  if (m.ep == 0 && m.et == 0 && CORNER_3C_SOLVED)
	    {
	      if (SHOW_PRUNE_COUNTS)
		counts[phase][0].nodes++;

	      tmp = EPR(m.epr);

              #if (CP6C_SYM_METHOD == 2)
              m.cp6c = cp6c_sym2[m.cp6cm.min][m.cp6cm.op];
              #endif

	      dist = distp2[cp6c_cpr[m.cp6c]][tmp>>1];
	      dist = ((tmp&1) ? dist>>4 : dist&0xF);

              if (QTM) 
	        dist = p2_dist_out[dist];
              else
                if (dist == 0)
 	          if(c->cp6c != 0 || tmp != 0)
                    dist = 16;

	      check_opt_only();

	      if (dist+n > depth[phase]) 
		{
		  if (SHOW_PRUNE_COUNTS)
		    counts[phase][0].pruned++;
		  continue;
		}

	      #if SHOW_ALERT
	      if (phase == 0)
		{
	          if (depth[0]-n > P2_GEN_DEPTH)
		    {
                      // N  Depth  Dist  Prune  Dep-N  GenDep  (Dep-N > GenDep)
                      // 6   14     9      Y      8       8           N
                      // 6   15     9      N      9       8           Y
		      printf("\nALERT: 3C solution not pruned ");
		      printf("at depth %d, ", n);
		      printf("P2_GEN_DEPTH should be set higher\n");
		      printf("       currently: %d, ", P2_GEN_DEPTH); 
		      printf("needs: %d \n\n", depth[0]-n);
                      fflush(stdout);
		    }
		}
	      #endif
	    }

          // search the next depth by recursively calling search()

	  if (QTM)
	    search(&m, n+1, SEQ_GEN(mv, seq[phase][n-1]));
	  else
	    search(&m, n+1, seq_gen[mv]);

          #if MULTI_PROC_ENABLED
	  if (child)
	    exit(minmv);  // exit child process
          #endif
	}
    }

  #if (MULTI_PROC_ENABLED)
    if (n == 1 && depth[phase] >= MULTI_PROC_MIN_DEPTH)
      while (child_procs > 0)
	wait_proc();
  #endif
}

set_depth_6C()
{
  int n;

  if (opt_only)
    depth_6C[0] = depth[0];
  else
    {
      n = (FAO)? 0 : (QTM) ? 2 : 1 ;

      if (minmv-n < depth[0] + OVERREACH_6C)
	depth_6C[0] = minmv-n;
      else
	depth_6C[0] = depth[0] + OVERREACH_6C;
    }
}

display_moves(s, n)
     char *s;
     int n;
{
  int i;

  for (i=0; i < n; i++)
    display_move(s[i]);

  if (QTM && USE_ALT_QTM_NOTATION)
    printf(" ");
}

display_move(m)
     int m;
{ 	
  if (QTM)
    {
      if (USE_ALT_QTM_NOTATION)
        printf("%c ", alt_disp[m]); 
      else
        printf("%c%c ", disp[m/2], disp2[m%2]); 
    }
  else
    printf("%c%c ", disp[m/3], disp2[m%3]); 
}

show_node_counts()
{	
  printf("%12u nodes %10d tests %7d 3C\n",
	 nodes[0], tests[0], solutions_3C[0]);
  fflush(stdout);	
}

end_search(status)
     int status;
{	
  if (status >= 4 && status != 6)
    {
      if (SHOW_NODE_COUNTS)
	{
	  printf("Depth %2d          ", depth[0]);
	  show_node_counts();
	}
      
      if (SHOW_PRUNE_COUNTS)
	show_prune_counts(0);

      if (SHOW_MIN_OP_COUNT)
	show_min_op_count();
    }

  if (SHOW_EPT_STATS)
    {
      if (status > 3 && status != 6) {
        nodes_total[0] += nodes[0];
        nodes_total[1] += nodes[1];
      }
      show_ept_stats(0);
      // show_ept_stats(1);
    }
  
  if (status == 1)
    printf("%d Optimal Solutions Found\n", opt_soln_ct);

  else if (status == 2)
      printf("Optimal Solution Found (proved optimal)\n");

  else if (status == 3)                    
    {
      printf("Optimal Search Stopped at Max Depth: %d\n", max_depth);
      if (minmv == MINMV_INIT)
	printf("No Solution Found, Use Larger Optimal Search Depth Max\n");
    }

  else if (status == 4)
    printf("Optimal Solution Found\n");

  else if (status == 5)
    printf("Search Stopped After First Solution Found\n");

  else if (status == 6)
    printf("Search Stopped After Depth of First Sub-Optimal Solution\n");

  else if (status == 7)
    printf("Search Stopped: STOP_SOLN_LEN = %d\n", STOP_SOLN_LEN);

  else if (status == 8)
  {
    runtime_exceeded = 1;
    if (RUNTIME_LIMIT % 60)
      printf("Search Stopped: RUNTIME_LIMIT = %d seconds\n", RUNTIME_LIMIT);
    else
      printf("Search Stopped: RUNTIME_LIMIT = %d minutes\n", RUNTIME_LIMIT/60);
  }

  else if (status == 9)
  {
    printf("Search Stopped: Runtime Limit Per Cube Exceeded\n");
    if (RTL_PER_CUBE % 60)
      printf("                RTL_PER_CUBE = %d seconds\n", RTL_PER_CUBE);
    else
      printf("                RTL_PER_CUBE = %d minutes\n", RTL_PER_CUBE/60);
    
    if (minmv == MINMV_INIT)
      printf("No Solution Found, Increase Runtime Limit (RTL_PER_CUBE)\n");
    else
      printf("Solution Length Found: %d%c\n", minmv, tolower(metric));
  }

  else if (status == 10)
  {
    printf("Optimal Solution Found (minimum distance known from distp2)\n", 
      STOP_SOLN_LEN);
    printf("Solution Length Found: %d%c\n", p2dist, tolower(metric));
  }

  else if (status == 11)
  {
    printf("Search Stopped: Runtime Limit = %d seconds", rtlp);

    if (search_extended)
      printf(" (search was extended)");

    printf("\n");
 
    if (minmv == MINMV_INIT)
      printf("No Solution Found, Increase Search Time\n");
  }

  if ( !(status == 3 && minmv == MINMV_INIT) && 
       !(status == 11 && minmv == MINMV_INIT) && 
        status != 9 && status != 10 )
       printf("Solution Length Found: %d%c\n", minmv, tolower(metric));
 
  show_ftime(ftime2, "Search Time:");
  longjmp(env1,1);
}

time_t
get_time(start_time)
     time_t start_time;
{
  time_t end_time, n;
  end_time = time((long*)0);
  n = end_time - start_time;
  return(n);
}

show_ftime(start_ftime, s)
     struct timeb start_ftime;
     char *s;
{
  int n, m;
  char ts[20];
  n = get_ftime(start_ftime, &m);
  convert_time(n, m, ts);
  printf("%s %s\n", s, ts);
}

show_ftime2(start_ftime)
     struct timeb start_ftime;
{
  int n, m;
  char ts[20];
  n = get_ftime(start_ftime, &m);
  convert_time(n, m, ts);
  printf("%s", ts);
}

convert_time(n, m, s)
     int n, m;
     char *s;
{
  if (n < 3600)
    sprintf(s, "%02d:%02d.%02d", n/60, n%60, m);
  else
    sprintf(s, "%d:%02d:%02d.%02d", n/3600, (n/60)%60, n%60, m);
}

get_ftime(start_ftime, m)
     struct timeb start_ftime;
     int *m;
{
  int n, x, v;
  struct timeb end_ftime;
  ftime(&end_ftime);
  x = (end_ftime.time - start_ftime.time) * 1000 + 
      (end_ftime.millitm - start_ftime.millitm);
  n = x/1000;
  *m = (x%1000)/10;
  return(n);
}

display_suboptimal_solution()
{	
  int i, j, len, n;
  char tmp[50];
  char inv_mv[18] = {2,1,0,5,4,3,8,7,6,11,10,9,14,13,12,17,16,15};

  for (i=0; i < depth[0]; i++)
    tmp[i] = seq[0][i+1];

  for (j=0; j < depth[1]; i++, j++)
    tmp[i] = seq[1][j+1];

  len = depth[0] + depth[1];
  n = depth[0];

  if (QTM)
    {
      // if ccw move follows cw move on same face, remove the pair

      if (tmp[n-1] == tmp[n]-1 && tmp[n]&1)
	for (len-=2, j=depth[0]-1; j < len; j++)
	  tmp[j] = tmp[j+2];

      // if three cw moves in a row on same face, skip this solution
      // as a better one will immediately follow (ccw instead of 3 cw)

      if (tmp[n] == tmp[n-1] && tmp[n] == tmp[n+1])
	return;
    }
  else  // Face-Turn Metric
    {
      /* For seqs with two moves in a row to the same face, if the 
         moves cancel each other out remove the pair from the seq, 
	 otherwise skip the solution.
      */
      
      if (tmp[n-1]/3 == tmp[n]/3)
	if (tmp[n-1] == inv_mv[tmp[n]])
	  {
	    for (len-=2, j=depth[0]-1; j < len; j++)
	      tmp[j] = tmp[j+2];
	  }
	else
	  {
	    return;
	  }
    }

  display_moves(tmp, len);

  if (len == p2dist)
    {
      printf("(%d%c*)\n", len, QTM?'q':'f');
      end_search(10);
    }
    else
      printf("(%d%c)\n", len, QTM?'q':'f');
  
  fflush(stdout);

  if (len < minmv)
    {
      minmv = len;
      minmv_flag = 1;
      depth_6C[0] = (FAO) ? minmv : minmv-1;
    }

  set_depth_6C();
}

display_optimal_solution()
{
  display_moves(&seq[0][1], depth[0]);
  
  if (QTM)
    printf("(%dq*)\n", depth[0]);
  else
    printf("(%df*)\n", depth[0]);

  minmv = depth[0];
  fflush(stdout);
}

show_cube_file_format()
{
  printf("\n---------------------------------------------------------\n");
  printf("INPUT FILE FORMAT:\n\n");
  printf("    UUU\n");
  printf("    UUU\n");
  printf("    UUU\n");
  printf("LLL FFF RRR BBB\n");
  printf("LLL FFF RRR BBB\n");
  printf("LLL FFF RRR BBB\n");
  printf("    DDD\n");
  printf("    DDD\n");
  printf("    DDD\n\n");
  printf("U=Up, L=Left, F=Front, R=Right, B=Back, D=Down\n\n");
  printf("Can also be entered on one line as:\n");
  printf("UUUUUUUUULLLFFFRRRBBBLLLFFFRRRBBBLLLFFFRRRBBBDDDDDDDDD\n");
  printf("---------------------------------------------------------\n");
}

init()
{
  int i, n;
  char fname[100];

  if (MAX_P2_DIST > P2_GEN_DEPTH)
    {
      printf("ERROR: MAX_P2_DIST must be <= P2_GEN_DEPTH\n");
      return(1);

    }

  if (USE_DIST7)
    if (MAX_D7_DIST < MAX_D6_DIST)
      {
	printf("MAX_D7_DEPTH must be >= MAX_D6_DEPTH in solve.c\n");
	return(1);
      }

  /*
  for (i=1; i <= 4; i++)
    if (check_gen_depth(i, use_dist, dist_depth))
      return(1);
  */

  if (FAO)
    printf("Searching For ALL Optimal Solutions\n");

  if (USE_DIST1 == 0 && USE_DIST2 == 0)
    {
      printf("ERROR: Both DIST1 & DIST2 are set to 0, ");
      printf("at least one must be used\n");
      return(1);
    }

  if (MULTI_PROC_ENABLED)
    {
      printf("\nMAX_CHILD_PROCS = %d\n", MAX_CHILD_PROCS);
      printf("MULTI_PROC_MIN_DEPTH = %d\n", MULTI_PROC_MIN_DEPTH);

      if (SHOW_NODE_COUNTS == TRUE || SHOW_PRUNE_COUNTS == TRUE)
	{
	  printf("\nNOTE: ");
	  printf("Node counts will be zero after MULTI_PROC_MIN_DEPTH is reached.\n");
	}

      n = (QTM) ? 12 : 18;

      if (MAX_CHILD_PROCS < 2 || MAX_CHILD_PROCS > n)
	{
	  printf("\nERROR: MAX_CHILD_PROCS must be between 2 & %d\n\n", n);
	  return(1);
	}
    }

  if (load_dist_files(0))  // 0 = check dist files exist (don't load)
    return(1);

  // init_dist();
  printf("Initializing\n");
  fflush(stdout);
  minmv = 99;
  init3();
  seq[0][0] = seq[1][0] = NIL;

  for (i=0; i < MOVES; i++)
    advance[i]=i/3*3+2;

  load_dist_files(1);

  if (USE_DIST7)
    populate_epr_min_op();

  return(0);
}

check_params(argc, argv)
     int argc;
     char **argv;
{	
  if (argc != 2 && argc != 3)
    {         
      printf("\nUsage: %s {file} [max depth or time (append s for time)]\n",
	     argv[0]);
      show_cube_file_format();
      return(1);
    }

  if (argc == 2) 
    {
      if (QTM)
	max_depth = MAX_DEP_DFLT_QTM;
      else
	max_depth = MAX_DEP_DFLT_FTM;
    }
  else if (check_max_depth(argv) != 0)
    return(1);

  /*
  printf("Input File: %s\n", argv[1]);
  printf("Optimal Search Depth Max: %d\n", max_depth);
  printf("Metric: %s\n", ((QTM)?"Quarter Turn":"Face Turn"));

  printf("Notation: %s = Counterclockwise\n", 
    ((USE_ALT_QTM_NOTATION)?"Lowercase":"Quote"));
  */

  if (SHOW_RTL_LIMITS)
  {
  if (RUNTIME_LIMIT == 0)
    printf("Runtime Limit (total): None\n");
  else
    if (RTL_PER_CUBE % 60)
      printf("Runtime Limit (total): %d seconds\n", RUNTIME_LIMIT);
    else
      printf("Runtime Limit (total): %d minutes\n", RUNTIME_LIMIT/60);

  if (RTL_PER_CUBE == 0)
    printf("Runtime Limit (per cube): None\n");
  else
    if (RTL_PER_CUBE % 60)
      printf("Runtime Limit (per cube): %d seconds\n", RTL_PER_CUBE);
    else
      printf("Runtime Limit (per cube): %d minutes\n", RTL_PER_CUBE/60);
  }

  fflush(stdout);
  return(0);
}

check_max_depth(argv)
     char **argv;
{	
  char *p;
  p = argv[2];

  if (p[strlen(p)-1] == 's')
  {
    p[strlen(p)-1] = 0;
    rtlp = atoi(p);
    // printf("Runtime limit = %ds\n\n", rtlp);
    if (rtlp < 1 || rtlp > MAX_RTLP)
    {
      printf("Runtime limit must be between 1 and %d\n", MAX_RTLP);
      exit(0);
    }
    max_depth = 30; 
    max_depth_param = 1; 
    return(0);
  }
  else
    rtlp = 0;

  if (argv[2][0] < '0' || argv[2][0] > '9')
    {
      printf("Invalid search depth: <%s>\n", argv[2]);
      printf("Usage: %s {file} [max optimal search depth]\n",
	     argv[0]);
      return(1);
    }

  max_depth = atoi(argv[2]);
  max_depth_param = 1; 

  if (max_depth < 1 || max_depth > ((QTM)?26:20))
    {
      printf("Max optimal search depth must be between 1 & %d\n", ((QTM)?26:20));
      return(1);
    }

  return(0);
}

#if MULTI_PROC_ENABLED
wait_proc()
{
  int n;

  n = wait_for_proc();
  
  if (n < minmv)
    minmv = n;

  if (minmv <= STOP_SOLN_LEN)
      {
	term_pid_list();
	end_search(7);
      }

  if (STOP_FIRST_SUBOPT)
    if (minmv != MINMV_INIT)
      {
	term_pid_list();
	end_search(5);
      }

  if (FAO == FALSE)
    if (minmv == depth[0])
      {
	term_pid_list();
	end_search(4);
      }
}
#endif

init_prune_counts()
{
  int i, j;

  for (i=0; i  < 2; i++)
    for (j=0; j  < 10; j++)
      {
	counts[i][j].nodes = 0;
	counts[i][j].pruned = 0;
      }
}

show_prune_counts()
{
  if (depth[0] >= SHOW_PRUNE_DEPTH)
    {
      printf("\n");
      
      if (SHOW_PRUNE_PHASE == 1 || SHOW_PRUNE_PHASE == 3)
	show_prune_counts_phase(0);
      
      if (SHOW_PRUNE_PHASE == 2 || SHOW_PRUNE_PHASE == 3)
	show_prune_counts_phase(1);
      
    }

  fflush(stdout);

}

show_prune_counts_phase(i)
     int i;
{
  printf("Phase %d prune counts:\n", i+1);
  
  if (USE_DIST3)
    show_prune_count_line("dist3", counts[i][3].nodes, counts[i][3].pruned);

  if (USE_DIST4)
    show_prune_count_line("dist4", counts[i][4].nodes, counts[i][4].pruned);

  if (USE_DIST1)
    show_prune_count_line("dist1", counts[i][1].nodes, counts[i][1].pruned);

  if (USE_DIST2)
    show_prune_count_line("dist2", counts[i][2].nodes, counts[i][2].pruned);

  if (USE_DIST7)
    show_prune_count_line("dist7", counts[i][7].nodes, counts[i][7].pruned);

  show_prune_count_line("dist5", counts[i][5].nodes, counts[i][5].pruned);

  if (USE_DIST6)
    show_prune_count_line("dist6", counts[i][6].nodes, counts[i][6].pruned);

  // show_prune_count_line("distp", counts[i][0].nodes, counts[i][0].pruned);

  printf("\n");
}

show_prune_count_line(s, nodes, pruned)
     char *s;
     long long nodes, pruned;
{
  printf(" %s: %10lld nodes %10lld pruned  ", s, nodes, pruned);

  if (nodes != 0)
    printf("%5.1f%\n", (float)pruned*100/(float)nodes);
  else
    printf("%5.1f%\n", 0);
}

test_6C_solution(c, n, mv)
     struct S_CUBE *c;
     int n, mv;
{
  int tmp, dist;

  solutions_3C[phase]++;
  seq[phase][n] = mv;

  #if (CP6C_SYM_METHOD == 2)
  c->cp6c = cp6c_sym2[c->cp6cm.min][c->cp6cm.op];
  #endif

  if (phase == 0)
    {
      tmp = EPR(c->epr);

      dist = distp2[cp6c_cpr[c->cp6c]][tmp>>1];
      dist = ((tmp&1) ? dist>>4 : dist&0xF);

      if (QTM) 
	dist = p2_dist_out[dist];
      else
        if (dist == 0)
 	  if(c->cp6c != 0 || tmp != 0)
            dist = 16;

      if (dist == 0)
	{
          opt_soln_ct++;
	  display_optimal_solution(dist);
	  
	  if (FAO == FALSE)
	    if (MULTI_PROC_ENABLED)
	      exit(minmv);  // exit child process
	    else
	      end_search(4);
	}
      else if (dist <= MAX_P2_DIST && dist+n < minmv)
	{   
	  phase = 1;

	  if (setjmp(env2) == 0)
	    for (depth[1]=1; depth[1] <= dist; depth[1]++)  
	      {
		depth_6C[1] = depth[1];
		search(c, 1, mvlist2);
	      }
	  
	  phase = 0;

	  if (minmv <= STOP_SOLN_LEN)
	    if (MULTI_PROC_ENABLED)
	      exit(minmv);  // exit child process
	    else
	      end_search(7);
	  
	  if (STOP_FIRST_SUBOPT)
	    if (MULTI_PROC_ENABLED)
	      exit(minmv);  // exit child process
	    else
	      end_search(5);
	}
    }
  else 
    {

      if (c->cp6c == 0 && EPR(c->epr) == 0)
	{
	  display_suboptimal_solution();
	  longjmp(env2,depth[1]);
	}
    }
}

show_defines()
{
  if (USE_MAX_D1_DIST)
    printf("  MAX_D1_DIST      = %d\n", MAX_D1_DIST);
    
  if (USE_MAX_D2_DIST)
    printf("  MAX_D2_DIST      = %d\n", MAX_D2_DIST);
      
  if (USE_DIST5)
    printf("  MAX_D5_DIST      = %d\n", MAX_D5_DIST);

  if (USE_DIST6)
    printf("  MAX_D6_DIST      = %d\n", MAX_D6_DIST);

  #if USE_DIST7
  printf("  MAX_D7_DIST      = %d\n", MAX_D7_DIST);
  #endif

  printf("  MAX_P2_DIST      = %d\n", MAX_P2_DIST);
  printf("  OVERREACH_6C     = %d\n", OVERREACH_6C);

  printf("  OPT_ONLY_DEPTH   = %d\n", OPT_ONLY_DEPTH);
  printf("  OPT_ONLY_TIME    = %d\n", OPT_ONLY_TIME);
}

load_dist_files(load)
     int load;
{
  int n = 0;
  char dtype[3]={'B','Q','H'};

  metric = (QTM) ? 'Q' : 'F' ;

  if (USE_DIST1)
    n += chk_load_file(dist1, "D1", sizeof(dist1), 'H', D1_GEN_DEPTH, load);

  if (USE_DIST2)
    n += chk_load_file(dist2, "D2", sizeof(dist2), 'H', D2_GEN_DEPTH, load);

  if (USE_DIST3)
    n += chk_load_file(dist3, "D3", sizeof(dist3), get_dist_type(DIST3_TYPE),
		       D3_GEN_DEPTH, load);

  if (USE_DIST4)
    n += chk_load_file(dist4, "D4", sizeof(dist4), (DIST4_TYPE)?'Q':'B',
		       D4_GEN_DEPTH, load);

  #if USE_DIST6
    n += chk_load_file(dist5, "D5", sizeof(dist5), 'H', 11, load);
  #endif
  
  #if USE_DIST6
    n += chk_load_file(dist6, "D6", sizeof(dist6), 'H', 10, load);
  #endif

  #if (USE_DIST7)
  n += chk_load_file(dist7, "D7", sizeof(dist7), dtype[DIST7_TYPE], 
		     D7_GEN_DEPTH, load);
  #endif

  n += chk_load_file(distp2, "P2", sizeof(distp2), 'H', P2_GEN_DEPTH, load);

  return(n);
}

chk_load_file(arr, prefix, size, type, depth, load)
     unsigned char *arr;
     char *prefix;
     int size, type, depth, load;
{
  char fname[DAT_FNAME_LEN];

  snprintf(fname, DAT_FNAME_LEN, "dat/%s_%04.0f%c_%02d%c.dat", 
	   prefix, (float)size/MEG, type, depth, metric);

  if (load)
    load_dist_file(fname, arr, size, CHAR);
  else
    {
      if ((fp = fopen(fname,"r")) == NULL)
	{
	  printf("\nERROR: File not found: %s\n\n", fname);
	  return(1);
	}
      
      fclose(fp);
    }

  return(0);
}

show_min_op_count()
{
  if (min_op_count >= 100000)
    {
      printf("\nCalls to get_min_op_3c(): %d\n", min_op_count);
      printf("  Ratio:    %8.5f\n", (float)min_op_count/nodes[0]);
      printf("  Expected:  0.00241\n");
      printf("  Diff:     %8.5f\n", ((float)min_op_count/nodes[0])-.00241);
      printf("  Number of sym ops applied: %d\n", min_op_count2);
      printf("  Avg per call: %6.5f\n\n", (float)min_op_count2/min_op_count);
    }
}

check_opt_only()
{
  int m;
  if (phase == 0 && opt_only == FALSE)
    if (depth[0] < OPT_ONLY_DEPTH && get_ftime(ftime2, &m) >= OPT_ONLY_TIME)
      {
	show_ftime(ftime2, "Switching to optimal only search, time: ");
	opt_only = TRUE;
	set_depth_6C();
        /*
        if (max_depth_param == 0)
          if (QTM)
          {
            printf("Max depth set to: %d\n", MAX_DEP_OPTO_QTM);
            max_depth = MAX_DEP_OPTO_QTM;
          }
          else
          {
            printf("Max depth set to: %d\n", MAX_DEP_OPTO_FTM);
            max_depth = MAX_DEP_OPTO_FTM;
          }
        */
      }
}

check_runtime()
{
  if (RUNTIME_LIMIT > 0)
    if (get_time(time1) >= RUNTIME_LIMIT)
        end_search(8);

  if (RTL_PER_CUBE > 0)
    if (get_time(time2) >= RTL_PER_CUBE)
        end_search(9);

  int m;
  if (USE_RTL_PARAM)
    if (rtlp > 0)
      if (get_ftime(ftime2, &m) >= rtlp)
        if (minmv < 99)
          end_search(11);
        else
          if (!search_extended) 
          {
            show_ftime2(ftime2);
            printf(" Runtime Limit reached but solution not found, extending search\n");
            search_extended = 1;
          }
}

show_settings()
{
  printf("Settings:\n");
  if (SHOW_DEFINES)
    show_defines();
  if (SHOW_METHODS)
    show_methods();
  printf("\n");
}
