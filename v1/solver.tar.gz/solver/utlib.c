// Author: Michael Feather 

#include "rc.h"

unsigned short cp6c_sym[C_PERM][CUBE_SYM];

//  The following method settings are required in rc.h for these functions 
//  CT_SYM_METHOD    1 or 2
//  CP6C_SYM_METHOD  1

#if (CT_SYM_METHOD == 1)
get_min_op_6c_m1(c)
struct S_CUBE *c;
{	
  char eprsym[3], eprtmp[3];
  int i, n, dif, ep, cp, ct, cp6c, cpsym, ctsym, cp6csym, min_op;
  int oplist[CUBE_SYM];
  long long min, sym;
  n = ept_min_ops[c->ops_idx][2];
  if (n == CUBE_SYM-1)
    for (i=0; i < n; i++)
      oplist[i] = i+1;
  else
    for (i=0; i < n; i++)
      oplist[i] = ept_min_ops[c->ops_idx][i+3];
  get_eprsym(eprtmp, c->ep, c->epr, c->op); 
  ep = min_ep[ep_min[c->ep]];
  cp6c = cp6c_sym[c->cp6c][c->op];
  cp = cp_sym[c->cp][c->op];
  ct = ct_sym[c->cp][c->ct][c->op];
  min = (long long) ((cp*C_TWIST + ct)*C_PRMr +
		     cp6c_cpr[cp6c])*E_PRMr + EPR(eprtmp);
  for (i=dif=0; i < n; i++)
    {
      cp6csym = cp6c_sym[cp6c][oplist[i]];
      get_eprsym(eprsym, ep, eprtmp, oplist[i]);
      cpsym = cp_sym[cp][oplist[i]];
      ctsym = ct_sym[cp][ct][oplist[i]];
      sym = (long long) ((CPSYM*C_TWIST + CTSYM)*C_PRMr + 
			 cp6c_cpr[cp6csym])*E_PRMr + EPR(eprsym);
      if (sym < min)
	{
	  min = sym;
	  min_op = oplist[i];
	  dif = 1;
	}
    }

  if (dif)
   c->op = op_op[c->op][min_op];
}
#endif

#if (CT_SYM_METHOD == 2)
get_min_op_6c_m2(c)
struct S_CUBE *c;
{	
  char eprsym[3], eprtmp[3];
  int i, n, dif, min_op, cp6csym, ep, cp6c;
  int oplist[CUBE_SYM];
  struct s_cpt *csym;
  long long min, sym;
  struct s_min cpt;
  n = ept_min_ops[c->ops_idx][2];
  if (n == CUBE_SYM-1)
    for (i=0; i < n; i++)
      oplist[i] = i+1;
  else
    for (i=0; i < n; i++)
      oplist[i] = ept_min_ops[c->ops_idx][i+3];
  get_eprsym(eprtmp, c->ep, c->epr, c->op); 
  ep = min_ep[ep_min[c->ep]];
  cp6c = cp6c_sym[c->cp6c][c->op];
  cpt.op = op_op[c->cpt.op][c->op];
  cpt.min = c->cpt.min;
  csym = &cpt_sym[cpt.min][cpt.op];
  min = (long long) ((CPSYM*C_TWIST + CTSYM)*C_PRMr +
		     cp6c_cpr[cp6c])*E_PRMr + EPR(eprtmp);
  for (i=dif=0; i < n; i++)
    {
      cp6csym = cp6c_sym[cp6c][oplist[i]];
      get_eprsym(eprsym, ep, eprtmp, oplist[i]);
      csym = &cpt_sym[cpt.min][op_op[cpt.op][oplist[i]]];
      sym = (long long) ((CPSYM*C_TWIST + CTSYM)*C_PRMr + 
			 cp6c_cpr[cp6csym])*E_PRMr + EPR(eprsym);
      if (sym < min)
	{
	  min = sym;
	  min_op = oplist[i];
	  dif = 1;
	}
    }

  if (dif)
   c->op = op_op[c->op][min_op];
}
#endif
