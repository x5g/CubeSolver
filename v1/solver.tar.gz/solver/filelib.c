// Author: Michael Feather 

#include <stdio.h>
#include <stdlib.h>

#define CHAR		1
#define SHORT		2
#define INT  		4

FILE *fp;
size_t strlen();

open_file(fname, mode)
     char *fname, *mode;
{
  if ((fp = fopen(fname,mode)) == NULL)
    {
      printf("Error opening file: <%s>\n", fname);
      exit(1);
    }
}

make_text_file(fname, arr, n, type)
     char *fname, *arr;
     int n, type;
{
  int i, *ip;
  short *sp;

  sp = (short*)arr;
  ip = (int *)arr;
  open_file(fname, "w");  // assigns fp

  for (i=0; i < n; i++) 
    switch (type)
      {
      case CHAR : fprintf(fp, "%d\n", arr[i]); break;
      case SHORT: fprintf(fp, "%d\n",  sp[i]); break;
      case INT  : fprintf(fp, "%d\n",  ip[i]); break;
      };
  fclose(fp);
}

load_text_file(fname, arr, n, type)
     char *fname, *arr;
     int n, type;
{
  char s[30];
  short *sp;
  int i, *ip;

  sp = (short*)arr;
  ip = (int *)arr;
  open_file(fname, "r");

  for (i=0; i < n; i++)
    {
      if (fgets(s, 10, fp) == NULL)
	{
	  printf("Error loading file: %s\n", fname);
	  exit(1);
	}

      switch (type)
	{
	case CHAR : arr[i]= atoi(s); break;
	case SHORT: sp[i] = atoi(s); break;
	case INT  : ip[i] = atoi(s); break;
	};
    }

  fclose(fp);
  sprintf(s, "%.*s", strlen(fname)-8, &fname[4]);
  populated(s);
}

make_bin_file(fname, arr, n, type)
     char *fname, *arr;
     int n, type;
{
  int total=0;

  n *= type;
  open_file(fname, "w");
  total = fwrite(arr, 1, n, fp);
  fclose(fp);

  if (total != n) 
    {
      printf("Error Writing File: <%s>\n", fname);
      printf("  Bytes Written: %d\n", total);
      printf("  Bytes Expected: %d\n", n);
      exit(1);
    }
}

load_bin_file(fname, arr, n, type)
     char *fname, *arr;
     int n;
{
  char s[30];
  int total=0;

  n *= type;
  open_file(fname, "r");
  total = fread(arr, 1, n, fp);
  fclose(fp);

  if (total != n) 
    {
      printf("Error Loading File: <%s>\n", fname);
      printf("  Bytes Expected: %d\n", n);
      printf("  Bytes Read: %d\n", total);
      exit(1);
    }

  sprintf(s, "%.*s", strlen(fname)-8, &fname[4]);
  populated(s);
  return(total);
}
