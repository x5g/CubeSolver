// Author: Michael Feather

#include "rc.h"

int phase;

#if USE_EPR_SYM_M1
epr_sym_m1(c)
struct S_CUBE *c;
{
  char eprsym[3];
  eprsym[slice_map[c->op][0]] = epr_sym[c->op][EP0][c->epr[0]][0];
  eprsym[slice_map[c->op][1]] = epr_sym[c->op][EP1][c->epr[1]][1];
  eprsym[slice_map[c->op][2]] = epr_sym[c->op][EP2][c->epr[2]][2];
  return((eprsym[0] * 24 + eprsym[1]) * 24 + eprsym[2]);
}
#endif

#if USE_EPR_SYM_M2
epr_sym_m2(c)
  struct S_CUBE *c;
{
  char eprsym[3];
  eprsym[slice_map[c->op][0]] = epr_sym2[epr_idx[c->op][EP0][0]][c->epr[0]];
  eprsym[slice_map[c->op][1]] = epr_sym2[epr_idx[c->op][EP1][1]][c->epr[1]];
  eprsym[slice_map[c->op][2]] = epr_sym2[epr_idx[c->op][EP2][2]][c->epr[2]];
  return((eprsym[0] * 24 + eprsym[1]) * 24 + eprsym[2]);
}
#endif
