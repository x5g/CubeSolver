"use strict";

var gtime0;
var facelets;
var time_format = 1;
var fnames;
var dist_loaded;
var dist3_gen_depth = 10;

function batch_heading()
{
  var msg = '';
  if (USE_DIST3 == 1 && load_dist_files == 0) {
    load_dist_files = 1;
    msg = '<br>Dist3 can only be used if loading dist files' +
      '<br>Setting load_dist_files = 1<br>';
  }
  var stoptxt = (stoplen==0) ? '' : 'Stop at First Solution <= ' + 
    stoplen + ' moves <br>';
  if (load_dist_files) {
    init_fnames();
    dist_loaded = [0, 0, 0];
    if (USE_DIST3)
      dist_loaded = [0, 0, 0, 0];
    var flist = '<br>Required Files:<br>';
    for (var i=0, n=0; i < fnames.length; i++)
      if (dist_loaded[i] == 0)
        flist += fnames[i]+'<br>'; 
    document.getElementById('title').innerHTML = 
      'Batch Solve of ' + cubes.length + ' cubes<br>' +
      'Search Time Limit (per cube) = ' + stl + ' seconds<br>' +
      stoptxt + msg + flist + '<br>'; 

    document.getElementById('btn').innerHTML =  
      '<input type=file id=selectFiles style="display:none;" ' +
      'onchange="readfiles(this.files)" multiple>' +
      '<input type=button value="Load Dist Files" ' +
      'onclick="document.getElementById(\'selectFiles\').click();" ' +
      'style="height:32px; width:161px"><br><br>';
  }
  else {
    var d3txt = (USE_DIST3) ? 'Using Dist3<br>' : '';
    document.getElementById('title').innerHTML =  
      'Batch Solve of ' + cubes.length + ' cubes<br>' +
      'Search Time Limit (per cube) = ' + stl + ' seconds<br>' +
      'Dist Gen Depth = ' + dist_gen_depth + '<br>' +
      'DistP2 Gen Depth = ' + distp2_gen_depth + '<br>' +
      stoptxt + d3txt + '<br>';
    document.getElementById('status').innerHTML = 
      '<button onclick="start()">Run</button>'; 
  }
}

function batch_run()
{
  if (verify_cubes() != 0)
    return;
  gtime0 = Date.now();
  document_write('<br>');
  document.getElementById('btn').innerHTML = '';
  document.getElementById('status').innerHTML =  'Initializing<br><br>';
  setTimeout(step1, 100);
}

function step1()
{
  var a = (USE_DIST3) ? '1-3' : '1-2';
  var s = document.getElementById('status').innerHTML;
  if (load_dist_files == 0) {
    init();
    document.getElementById('status').innerHTML =  s +
      'Generating Dist Arrays ' + a + ' to Depth ' + dist_gen_depth;
    setTimeout(step2, 100);
  }
  else {
    init();
    document.getElementById('status').innerHTML =  s + 
    'Solving Cube 1<br>';
    setTimeout(step4, 100);
  }
}

function step2()
{
  mkd();
  var s = document.getElementById('status').innerHTML;
  document.getElementById('status').innerHTML =  s +
    '<br>Generating DistP2 to Depth ' + distp2_gen_depth;
  setTimeout(step3, 100);
}

function step3()
{
  mkdp2();
  var s = document.getElementById('status').innerHTML;
  document.getElementById('status').innerHTML =  s + "<br><br>Solving Cube 1<br>";
  setTimeout(step4, 100);
}

var bix=0;

function step4()
{
  facelets = cubes[bix];
  show_cube_layout(facelets);
  stime0 = Date.now();
  solve_cube(facelets);
  var time1 = Date.now();
  var s = document.getElementById('status').innerHTML;
  if (bix < cubes.length-1) {
    bix++;
    document.getElementById('status').innerHTML = 
      s + 'Solution Length Found: ' + solution.length + 
      '<br>Search Time: ' + search_time +
      '<br><br>Solving Cube ' + (bix+1) + '<br>';
    window.scrollTo(0, document.documentElement.scrollHeight);
    setTimeout(step4, 100);
  }
  else
    setTimeout(step5, 100);
}

function step5()
{
  var s = document.getElementById('status').innerHTML;
  var time1 = Date.now();
  var time3 = (((time1-gtime0)/1000)-(.1*cubes.length+.1)).toFixed(2);
  var tstr3 = (time_format) ? convert_time(time3) : time3;

  var style = 'dark';
  document.getElementById('status').innerHTML = 
    s + 'Solution Length Found: ' + solution.length + 
    '<br>Search Time: '+ search_time +
    '<br><br>Total Time: '+ tstr3 + '<br><br>' +
    '<input type=button value="Solve Log" onclick="show_log(\'' + style + 
    '\')" style="height:32px; width:120px"><br><br>';
  document_write(tstr3 + ' Total Time<br><br>');
  window.scrollTo(0, document.documentElement.scrollHeight);
}

function verify_cubes()
{
  var s;
  var inv = 0;
  for (var i=0; i < cubes.length; i++) {
    facelets = cubes[i];
    if (facelets.length != 54) {
      inv++;
      s = document.getElementById('status').innerHTML;
      document.getElementById('status').innerHTML =
      s + '<br>Invalid Configuration: ' + facelets + 
      '<br>Length != 54<br>';
      continue;
    }
    facelets = facelets.toUpperCase();
    var facelets_ori = facelets;
    var ftmp = facelets.split('');
    for (var j=0; j < 54; j++)
      if ('WYORGB'.indexOf(ftmp[j]) == -1)
        ftmp[j] = 'L';
    var facelets2 = ftmp.join('');
    if (facelets2 != facelets) {
      inv++;
      s = document.getElementById('status').innerHTML;
      document.getElementById('status').innerHTML = 
      s + '<br>Invalid Configuration:<br>' + facelets + 
      '<br>One or more facelets is not a valid color (valid colors are WYORGB)<br>';
      continue;
    }
    if (typeof(msgtxt) != 'undefined')
      msgtxt.length = 0;
    stl = stl + '';  // convert to string
    if (verify_main(facelets) != 0) {
      inv++;
      var txt = msgtxt.join('');
      if (txt.substr(txt.length-4) == '<br>')
        txt = txt.substr(0, txt.length-4);
      s = document.getElementById('status').innerHTML;
      document.getElementById('status').innerHTML = 
        s + '<br>Invalid Configuration:<br>' + facelets +
        '<br>' + txt + '<br>';
    }
  }
  if (inv > 0) {
    s = document.getElementById('status').innerHTML;
    document.getElementById('status').innerHTML =
      s + '<br>' + inv + ' Invalid Configurations, run halted<br><br>';
    return(1);
  }
  return(0);
}

function readfiles_done() {
  document.getElementById('status').innerHTML = 
    '<button onclick="start()">Run</button>'; 
    document.getElementById('btn').innerHTML = '';
}

