// Author: Michael Feather

#include "rc.h"

#if USE_GET_ETSYM_M1
get_etsym_m1(c)
struct S_CUBE *c;
{
  int etsym;

  if (op16e[c->op].op1 == 0)
    etsym = et_sym[c->et][c->op];
  else if (op16e[c->op].op1 == OP_FR)
    etsym = et_sym[et_sym_FR[EP0][c->et]][c->op];
  else
    etsym = et_sym[et_sym_UF[EP1][c->et]][c->op];

  return(etsym);
}
#endif

#if USE_GET_ETSYM_M2
get_etsym_m2(c)
struct S_CUBE *c;
{
  int etsym, slice;

  if (op16e[c->op].op1 == 0)
    etsym = et_sym[c->et][c->op];
  else
    {
      slice = (op16e[c->op].op1==OP_FR) ? EP0 : EP1;
      etsym = et_sym[et_sym_FR[slice][c->et]][c->op];
    }

  return(etsym);
}
#endif

#if USE_GET_ETSYM_M3
get_etsym_m3(c)
struct S_CUBE *c;
{
  int etsym;
  struct s_et_ix *etix;

  if (op16e[c->op].op1 == 0)
      etsym = et_sym16[c->et][op16e[c->op].op2];

  else if (op16e[c->op].op1 == OP_FR)
    {
      etix = &et_fr_ix[EP0][c->et>>7];

      etsym = et_sym16[etix->base + et_fr[etix->ix][c->et&127]]
	[op16e[c->op].op2];
    }
  else
    {
      etix = &et_uf_ix[EP1][c->et>>6];

      etsym = et_sym16[etix->base + et_uf[etix->ix][c->et&63]] 
	 [op16e[c->op].op2];
    }

  return(etsym);
}
#endif

#if USE_GET_ETSYM_M4
get_etsym_m4(c)
struct S_CUBE *c;
{
  struct s_et_ix *etix;
  int etsym;

  if (op16e[c->op].op1 == 0)
    etsym = et_sym32[c->et][op16e[c->op].op2];

  else
    {
      etix = &et_fr_ix[(op16e[c->op].op1==OP_FR) ? EP0 : EP1][c->et>>7];
      
      etsym = et_sym32[etix->base + et_fr[etix->ix][c->et&127]] 
	[op16e[c->op].op2];
    }

  return(etsym);
}
#endif

#if USE_GET_ETSYM_M5
get_etsym_m5(c)
struct S_CUBE *c;
{
  int ix, etsym;

  if (op16e[c->op].op1 == 0)
      etsym = et_sym16[c->et][op16e[c->op].op2];

  else if (op16e[c->op].op1 == OP_FR)
    {
      ix = (EP0<<4) + (c->et>>7);

      etsym = et_sym16[et_fr_ixb[ix] + et_fr[et_fr_ixv[ix]][c->et&127]]
	[op16e[c->op].op2];
    }
  else
    {
      ix = (EP1<<5) + (c->et>>6);

      etsym = et_sym16[et_uf_ixb[ix] + et_uf[et_uf_ixv[ix]][c->et&63]]
	[op16e[c->op].op2];
    }

  return(etsym);
}
#endif
