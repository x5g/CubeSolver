/* Author: Michael Feather

      D7_0660B_10F   D7_0660Q_10F
    1            2              2
    2            9              9
    3           75             75
    4          924            924
    5        11662          11654
    6       147259         146997
    7      1820015        1810630
    8     21539587       21194046
    9    226874570      212630644
   10   1695647970     1250421451
 Array  5534908416     2767454208
*/

#include "rc.h"
#include "dist.h"

#define SYM_FIRST_MOVE  1   // 0=all first moves, 1=sym first moves
#define USE_CHK_DUP     1

#define SHOW_DEFINES    0
#define SHOW_METHODS    0

#define CHECK_RUNTIME 

char ep6c_stack[STACK_DEPTH][12];
int count, depth, quad_depth, seq[20];

main()
{
  char fname[100];
  init();
  snprintf(fname, DAT_FNAME_LEN, "dat/D7_%04.0f%c_%02d%c.dat", 
	  (float)sizeof(dist7)/MEG, get_dist_type(DIST7_TYPE), 
	  D7_GEN_DEPTH, metric);
  printf("Generating: %s\n", fname+4);
  populate_dist_array();
  printf("Writing: %s\n", fname+4);
  make_bin_file(fname, dist7, sizeof(dist7), CHAR); 
  exit(0);
}

populate_dist_array()
{
  int i;
  struct S_CUBE c;

  c.ep = c.et = 0;
  c.epi = &ep_info[0];
  c.epr[0] = c.epr[1] = c.epr[2] = 0; 

  #if (EP_SYM_METHOD == 2)
  c.epm.min = 0;
  c.epm.op = 0;
  #endif  

  dist7[0][0][0] = 1;

  for (depth=1; depth <= D7_GEN_DEPTH; depth++)
    {
      cfg_idx = count = 0;
      quad_depth = (depth <= D7_GEN_DEPTH-2) ? 1 : depth-(D7_GEN_DEPTH-3);

      #if SYM_FIRST_MOVE
      search(&c, 1, mvlist1);
      #else
      search(&c, 1, mvlist2);
      #endif

      printf("%2d %10d\n", depth, count);
      fflush(stdout);
    }

  if (DIST7_TYPE == 1)
    {
      printf("Updating\n");
      fflush(stdout);
      update_quad((unsigned char *)dist7, sizeof(dist7));
    }

  if (DIST7_TYPE == 2)
    {
      dist7[0][0][0] &= 0xF0;
      printf("Updating\n");
      fflush(stdout);
      update_hexd((unsigned char *)dist7, sizeof(dist7));
    }
}

search(c, n, mvlist)
     struct S_CUBE *c;
     int n, *mvlist;
{
  char eprsym[3];
  int i, ix, mv, rs, tmp, EPRsym;
  struct S_CUBE m;
  struct s_min_op *opi;

  for (i=0; (mv=mvlist[i]) != NIL; i++)
    {
      APPLY_MOVE_E6C;

      if (n == depth)
	{
	  rs = m.etsym>>(D7_RS);

	  if (DIST7_TYPE == 0)
	    {
	      tmp = 1<<(rs&7);
	      
	      if ((dist7[EPMIN][EPRsym][rs>>3] & tmp) == 0)
		{
	      
		  dist7[EPMIN][EPRsym][rs>>3] |= tmp;
		  count++;
		}
	    }

	  if (DIST7_TYPE == 1)
	    {
	      tmp = (dist7[EPMIN][EPRsym][rs>>2]>>((rs&3)<<1))&3;
	      
	      if (tmp == 0)
		{
		  dist7[EPMIN][EPRsym][rs>>2] |= quad_depth<<((rs&3)<<1);
		  count++;
		}
	    }

	  if (DIST7_TYPE == 2)
	    {
	      tmp = dist7[EPMIN][EPRsym][rs>>1];

	      if (((rs&1)?tmp>>4:tmp&0xF) == 0)
		{
		  dist7[EPMIN][EPRsym][rs>>1] |= ((rs&1)?n<<4:n);
		  count++;
		}
	    }
	}
      else
	{
	  #if USE_CHK_DUP
	  if (n <= 5)
	    if (chk_dup_6c(EPMIN, m.etsym, EPRsym, 0, 0, n))
	      continue;
          #endif

	  seq[n] = mv;

	  if (QTM)
	    search(&m, n+1, SEQ_GEN(mv, seq[n-1]));
	  else
	    search(&m, n+1, seq_gen[mv]);
	}
    }
}

init()
{
  if (USE_DIST7 == 0)
    {
      printf("Set USE_DIST7 to 1 in dist.h\n");
      exit(0);
    }

  if (SHOW_DEFINES || SHOW_METHODS)
    show_settings();

  init3();
  seq[0] = NIL;
  populate_min_ep();
  populate_epr_min_op();
}

show()
{
  int i;
  
  for (i=0; i < E_PRMr; i++)
    printf("%5d\n", epr_min_op[i]);
}

show_defines()
{
  printf("  USE_CHK_DUP      = %d\n", USE_CHK_DUP);
  printf("  SYM_FIRST_MOVE   = %d\n", SYM_FIRST_MOVE);
}

update_quad(dist, size)
     unsigned char *dist;
     int size;
{
  // assign 0->3, 3->2, 2->1, 1->0
  
  int n;
  unsigned char i, j, k, x;
  unsigned char rearrange[256];
  
  for (i=n=0; n < 256; i++, n++)
    {
      for (j=x=0; j < 4; j++) 
	{
	  k = ((i>>((j&3)<<1))&3);

	  if (k == 0) 
	    x |= 3<<((j&3)<<1);
	  else if (k == 2) 
	    x |= 1<<((j&3)<<1);
	  else if (k == 3) 
	    x |= 2<<((j&3)<<1);
	}  
      rearrange[i] = x;
    }
  
  for (n=0; n < size; n++)
    dist[n] = rearrange[dist[n]];
}

update_hexd(dist, size)
     unsigned char *dist;
     int size;
{
  int i;

  for (i=0; i < size; i++)
    {
      if ((dist[i]&0xF) == 0)
        dist[i] |= D7_GEN_DEPTH+1;

      if ((dist[i]>>4) == 0)
        dist[i] |= (D7_GEN_DEPTH+1)<<4;
    }

  dist[0] &= 0xF0;
}

show_settings()
{
  printf("Settings:\n");
  if (SHOW_DEFINES)
    show_defines();
  if (SHOW_METHODS)
    show_methods();
  printf("\n");
}


