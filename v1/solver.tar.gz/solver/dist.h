// Author: Michael Feather

#define USE_DIST1 1
#define USE_DIST2 1
#define USE_DIST3 0
#define USE_DIST4 0

#define DIST3_TYPE 0     // 0 = Bit-Array, 1=Quad, 2=Hexd
#define DIST4_TYPE 0

#define DIST1_SIZE 57    // Size in MB
#define DIST2_SIZE 53
#define DIST3_SIZE 418   // 418 for bit-array, 835 for quad 
#define DIST4_SIZE 913

#define D1_GEN_DEPTH 9
#define D2_GEN_DEPTH 9
#define D3_GEN_DEPTH 10
#define D4_GEN_DEPTH 10

#define USE_DIST5 1
#define USE_DIST6 1

#define USE_DIST7 0
#define DIST7_TYPE 0     // 0=Bit, 1=Quad, 2=Hexd
#define DIST7_SIZE 660   // 330, 660, 1320, ... (see sizes below for dist 7)
#define D7_GEN_DEPTH 10

/****************************     DIST 1     ********************************/

#if DIST1_SIZE == 57
#define D1_RS 0
#elif DIST1_SIZE == 29
#define D1_RS 1
#elif DIST1_SIZE == 14
#define D1_RS 2
#endif

#if USE_DIST1 == 1
#define D1_CT_DIM ((C_TWIST+1)>>D1_RS)/2
unsigned char dist1[MIN_EP][C_PRM][D1_CT_DIM];
#else
unsigned char dist1[1][1][1];
#endif

/****************************     DIST 2     ********************************/

#if DIST2_SIZE == 53
#define D2_RS 0
#elif DIST2_SIZE == 27
#define D2_RS 1
#elif DIST2_SIZE == 13
#define D2_RS 2
#endif

#if USE_DIST2 == 1
unsigned char dist2[MIN_EP][C_PRM][(E_TWIST>>D2_RS)/2];
#else
unsigned char dist2[1][1][1];
#endif

/****************************     DIST 3     ********************************/

//                                  SIZE/(2^N)
//                               Hexd  Quad  Bit
#if DIST3_SIZE == 1670   //        0    N/A  N/A
#define	D3_RS_OPT 0                
#elif DIST3_SIZE == 835  //        1     0   N/A
#define	D3_RS_OPT 1
#elif DIST3_SIZE == 418  //        2     1    0
#define	D3_RS_OPT 2
#elif DIST3_SIZE == 209  //        3     2    1
#define	D3_RS_OPT 3
#elif DIST3_SIZE == 104  //        4     3    2
#define	D3_RS_OPT 4
#elif DIST3_SIZE == 52   //        5     4    3
#endif

#if DIST3_TYPE == 0			// bit-array
#define D3_RS (D3_RS_OPT-2)
#define D3_RET (D3_GEN_DEPTH+1)
#define D3_TYPE 8
#elif DIST3_TYPE == 1 			// quad-array
#define D3_RS (D3_RS_OPT-1)
#define D3_RET (D3_GEN_DEPTH-2)
#define D3_TYPE 4
#else                                   // hexd-array
#define D3_RS D3_RS_OPT
#define D3_RET 0 
#define D3_TYPE 2
#endif

#if USE_DIST3 == 1
unsigned char dist3[MIN_EP][C_TWIST][(E_TWIST>>D3_RS)/D3_TYPE];
#else
unsigned char dist3[1][1][1];
#endif

/****************************     DIST 4     ********************************/

//                                  SIZE/(2^N)
//                               Hexd  Quad  Bit
#if DIST4_SIZE == 116911   //      0    N/A  N/A
#define D4_RS_OPT 0
#elif DIST4_SIZE == 58455  //      1     0   N/A
#define D4_RS_OPT 1
#elif DIST4_SIZE == 29228  //      2     1    0
#define D4_RS_OPT 2
#elif DIST4_SIZE == 14614  //      3     2    1
#define D4_RS_OPT 3
#elif DIST4_SIZE == 7307   //      4     3    2
#define D4_RS_OPT 4
#elif DIST4_SIZE == 3653   //      5     4    3 
#define D4_RS_OPT 5
#elif DIST4_SIZE == 1827   //      6     5    4
#define D4_RS_OPT 6
#elif DIST4_SIZE == 913    //      7     6    5
#define D4_RS_OPT 7
#elif DIST4_SIZE == 457    //      8     7    6
#define D4_RS_OPT 8
#elif DIST4_SIZE == 228    //      9     8    7
#define D4_RS_OPT 9
#elif DIST4_SIZE == 114    //     10     9    8
#define D4_RS_OPT 10
#endif

#if DIST4_TYPE == 0
#define D4_RS (D4_RS_OPT-2)
#define D4_RET (D4_GEN_DEPTH+1)
#define D4_TYPE 8
#elif DIST4_TYPE == 1
#define D4_RS (D4_RS_OPT)
#define D4_RET (D4_GEN_DEPTH-1)
#define D4_TYPE 4
#else
#define D4_RS D4_RS_OPT
#define D4_RET 0 
#define D4_TYPE 2
#endif

#if USE_DIST4 == 1
unsigned char dist4[C_PRM_TW][MIN_EP][(E_TWIST>>D4_RS)/D4_TYPE];
#else
unsigned char dist4[1][1][1];
#endif

/****************************     DIST 7     ********************************/

#if DIST7_SIZE == 10557
#define	D7_RS_OPT 0
#elif DIST7_SIZE == 5279
#define	D7_RS_OPT 1
#elif DIST7_SIZE == 2639
#define	D7_RS_OPT 2
#elif DIST7_SIZE == 1320
#define	D7_RS_OPT 3
#elif DIST7_SIZE == 660
#define	D7_RS_OPT 4
#elif DIST7_SIZE == 330
#define	D7_RS_OPT 5
#elif DIST7_SIZE == 165
#define	D7_RS_OPT 6
#elif DIST7_SIZE == 82
#define	D7_RS_OPT 7
#elif DIST7_SIZE == 41
#define	D7_RS_OPT 8
#endif

#if DIST7_TYPE == 0			// bit-array
#define D7_RS (D7_RS_OPT-2)
#define D7_RET (D7_GEN_DEPTH+1)
#define D7_TYPE 8
#elif DIST7_TYPE == 1 			// quad-array
#define D7_RS (D7_RS_OPT-1)
#define D7_RET (D7_GEN_DEPTH-2)
#define D7_TYPE 4
#else                                   // hexd-array
#define D7_RS D7_RS_OPT
#define D7_RET 0 
#define D7_TYPE 2
#endif

#if USE_DIST7 == 1
unsigned char dist7[MIN_EP][E_PRMr][(E_TWIST>>D7_RS)/D7_TYPE];
#else
unsigned char dist7[1][1][1];
#endif

/**************************     DISTS 5,6,P2     *****************************/

#if USE_DIST5 == 1
unsigned char dist5[C_TWIST][MIN_CP6C/2];             // 1.0M
#endif

#if USE_DIST6 == 1
unsigned char dist6[MIN_EP][E_PRMr/2];                // 5.2M
#endif

unsigned char distp2[C_PRMr][E_PRMr/2];               // 3.8M

/*****************************************************************************/

char *dist_arr[5];
int dist_sizeof[5];

char use_dist[5]={0,USE_DIST1,USE_DIST2,USE_DIST3,USE_DIST4};
char dist_type[5]={0,'H','H',DIST3_TYPE,DIST4_TYPE};
char dist_depth[5]={0,D1_GEN_DEPTH,D2_GEN_DEPTH,D3_GEN_DEPTH,D4_GEN_DEPTH};
int  dist_size[5]={0,DIST1_SIZE,DIST2_SIZE,DIST3_SIZE,DIST4_SIZE};
