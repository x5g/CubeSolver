// Author: Michael Feather 
// This program makes the symmetry tables used by the solver.

#include "rc.h"
#include "sym.h"
#include <dirent.h>

char eps[12], ets[12], cps[8], cts[8];
char cubestr[FACELETS];
char map[CUBE_SYM][FACELETS];
char ept_min_op[N_EPT_MIN_OP][E_TWIST];                 // 2.6 MB

unsigned short ep_sym[E_PRM][CUBE_SYM];                 // 3.2 MB
unsigned short cp6c_sym[C_PERM][CUBE_SYM];              // 4.1 MB
short et_sym_FR[SLICE_PRM][E_TWIST];                    // 1.9 MB
short et_sym_UF[SLICE_PRM][E_TWIST];                    // 1.9 MB
struct s_cpt cpt_sym[MIN_CPT][CUBE_SYM];                // 636 KB
struct s_min_op ept_min_op2a[N_EPT_OPS_IX2][E_TWIST];
int ept_op_idx[E_PRM];
int ept_op_row_compare();
int convert_edg_3c(), convert_cnr_3c(), convert_cnr_6c();

#if USE_CT_SYM
int tmp_sym_map[C_PRM_TW][CUBE_SYM];                    // 28.0 MB
#else
int tmp_sym_map[C_PERM][CUBE_SYM];                      // 7.4 MB
#endif

short ept_min_et[N_EPT_OPS_IX2][E_TWIST];

unsigned short cp6c_mov[C_PERM][MOVES];
unsigned short ct_sym_uf[C_PRM][C_TWIST];
unsigned short ct_sym_ur[C_PRM][C_TWIST];
unsigned short ct_sym2[C_TWIST][CUBE_SYM];
short et_sym[E_TWIST][CUBE_SYM];


main()
{
  print("Initializing\n");
  init();

  print("Generating: cp6c_min.dat\n");
  print("Generating: cp6c_min_op.dat\n");
  populate_cp6c_sym();
  make_text_file("dat/cp6c_min.dat", cp6c_min, C_PERM, INT);
  make_text_file("dat/cp6c_min_op.dat", cp6c_min_op, C_PERM, CHAR);

  // #if USE_CP6C_SYM
  print("Generating: cp6c_sym.dat\n");
  make_bin_file("dat/cp6c_sym.dat", cp6c_sym, C_PERM*CUBE_SYM, SHORT);
  // #endif

  printf("Generating: inv_op.dat\n");
  printf("Generating: op_op.dat\n");
  printf("Generating: op_cmv.dat\n", (QTM)?'q':'f');
  populate_op_tables();
  make_text_file("dat/inv_op.dat", inv_op, CUBE_SYM, CHAR);
  make_text_file("dat/op_op.dat", op_op, CUBE_SYM*CUBE_SYM, CHAR);

  if (QTM)
    make_text_file("dat/op_qmv.dat", op_mv, CUBE_SYM*MOVES, CHAR);
  else
    make_text_file("dat/op_fmv.dat", op_mv, CUBE_SYM*MOVES, CHAR);

  #if USE_EPR_SYM2
  print("Generating: epr_sym2.dat\n");
  print("Generating: epr_idx.dat\n");  
  populate_epr_sym2();
  make_bin_file("dat/epr_sym2.dat", epr_sym2, N_EPR_SYM2*24, CHAR);
  make_bin_file("dat/epr_idx.dat", epr_idx, 3*CUBE_SYM*SLICE_PRM, CHAR);
  #else
  print("Generating: epr_sym.dat\n");
  populate_epr_sym();
  make_bin_file("dat/epr_sym.dat", epr_sym, 3*CUBE_SYM*SLICE_PRM*24, CHAR);
  #endif

  populate_et_sym_arr(et_sym_FR, OP_FR, 0);
  populate_et_sym_arr(et_sym_UF, OP_UF, 1);

  #if USE_ET_SYM_FR
  print("Generating: et_sym_fr.dat\n");
  make_bin_file("dat/et_sym_fr.dat", et_sym_FR, SLICE_PRM*E_TWIST, SHORT);
  #endif

  #if USE_ET_SYM_UF
  print("Generating: et_sym_uf.dat\n");
  make_bin_file("dat/et_sym_uf.dat", et_sym_UF, SLICE_PRM*E_TWIST, SHORT);
  #endif

  #if USE_ET_FR
  print("Generating: et_fr.dat\n");
  populate_et_fr();
  make_bin_file("dat/et_fr.dat", et_fr, N_ET_FR*128, CHAR);
  #endif

  #if (ET_SYM_METHOD == 3 || ET_SYM_METHOD == 4)
  print("Generating: et_fr_ix.dat\n");
  make_bin_file("dat/et_fr_ix.dat", et_fr_ix, SLICE_PRM*16, ETIX_TYPE);
  #endif

  #if (ET_SYM_METHOD == 5)
  print("Generating: et_fr_ixb.dat\n");
  print("Generating: et_fr_ixb.dat\n");
  make_bin_file("dat/et_fr_ixb.dat", et_fr_ixb, SLICE_PRM*16, SHORT);
  make_bin_file("dat/et_fr_ixv.dat", et_fr_ixv, SLICE_PRM*16, CHAR);
  #endif

  #if USE_ET_UF
  print("Generating: et_uf.dat\n");
  populate_et_uf();
  make_bin_file("dat/et_uf.dat", et_uf, N_ET_UF*64, SHORT);
  #endif 

  #if (ET_SYM_METHOD == 3)
  print("Generating: et_uf_ix.dat\n");
  make_bin_file("dat/et_uf_ix.dat", et_uf_ix, SLICE_PRM*32, ETIX_TYPE);
  #endif

  #if (ET_SYM_METHOD == 5)
  print("Generating: et_uf_ixb.dat\n");
  print("Generating: et_uf_ixv.dat\n");
  make_bin_file("dat/et_uf_ixb.dat", et_uf_ixb, SLICE_PRM*32, SHORT);
  make_bin_file("dat/et_uf_ixv.dat", et_uf_ixv, SLICE_PRM*32, CHAR);
  #endif

  populate_et_sym();
  update_et_sym();

  #if USE_ET_SYM16
    populate_et_sym16();
    make_bin_file("dat/et_sym16.dat", et_sym16, E_TWIST*16, SHORT);
  #endif

  #if USE_ET_SYM32
    populate_et_sym32();
    make_bin_file("dat/et_sym32.dat", et_sym32, E_TWIST*32, SHORT);
  #endif

  #if USE_ET_SYM
  print("Generating: et_sym.dat\n");
  make_bin_file("dat/et_sym.dat", et_sym, CUBE_SYM*E_TWIST, SHORT);
  #endif

  print("Generating: ep_min.dat\n");
  print("Generating: ep_min_op.dat\n");
  populate_ep_sym(); 
  make_text_file("dat/ep_min.dat", ep_min, E_PRM, INT);
  make_text_file("dat/ep_min_op.dat", ep_min_op, E_PRM, CHAR);

  // #if USE_EP_SYM
  print("Generating: ep_sym.dat\n");
  make_bin_file("dat/ep_sym.dat", ep_sym, E_PRM*CUBE_SYM, SHORT);
  // #endif

  #if USE_EP_SYM2
  print("Generating: ep_sym2.dat\n");
  populate_ep_sym2();
  make_bin_file("dat/ep_sym2.dat", ep_sym2, MIN_EP*CUBE_SYM, SHORT);
  #endif

  print("Generating: ept_min_ops.dat\n");
  populate_ept_min_op();
  make_ept_min_ops();

  #if USE_EPT_MIN_OP
  print("Generating: ept_op.dat\n");
  print("Generating: ept_op_idx.dat\n");
  make_text_file("dat/ept_op_idx.dat", ept_op_idx, E_PRM, INT);
  make_bin_file("dat/ept_min_op.dat", ept_min_op, N_EPT_MIN_OP*E_TWIST, CHAR);
  #endif
  
  #if USE_EPT_MIN_OP2
  print("Generating: ept_min_op2.dat\n");
  print("Generating: ept_op_ix2.dat\n");
  populate_ept_min_op2a();
  update_ept_min_op2a();
  populate_ept_min_op2();
  make_bin_file("dat/ept_min_op2.dat", ept_min_op2, 57*E_TWIST, CHAR);
  make_bin_file("dat/ept_op_ix2.dat", ept_op_ix2, MIN_EP, CHAR);
  #endif

  print("Generating: cpt_min.dat\n");
  print("Generating: cpt_min_op.dat\n");
  print("Generating: cpt_sym.dat\n");
  populate_cpt_sym();
  make_text_file("dat/cpt_min.dat", cpt_min, C_PRM_TW, SHORT);
  make_text_file("dat/cpt_min_op.dat", cpt_min_op, C_PRM_TW, CHAR);
  make_bin_file("dat/cpt_sym.dat", cpt_sym, MIN_CPT*CUBE_SYM, INT);

  #if USE_CP_SYM
  print("Generating: cp_sym.dat\n");
  populate_cp_sym();
  make_bin_file("dat/cp_sym.dat", cp_sym, C_PRM*CUBE_SYM, CHAR);
  #endif

  #if USE_CT_SYM
  print("Generating: ct_sym.dat\n");
  populate_ct_sym();
  make_bin_file("dat/ct_sym.dat", ct_sym, C_PRM*C_TWIST*CUBE_SYM, SHORT);
  #endif

  #if USE_CP6C_SYM2
  print("Generating: cp6c_sym2.dat\n");  
  populate_cp6c_sym2();
  make_bin_file("dat/cp6c_sym2.dat", cp6c_sym2, MIN_CP6C*CUBE_SYM, SHORT);
  #endif

  #if USE_CT_SYM2
  populate_ct_sym2();
  #endif

  #if USE_CT_SYM_UF || USE_CT_UF
  populate_ct_sym_arr(ct_sym_uf, 2);
  populate_ct_sym_arr(ct_sym_ur, 20);
  #endif

  #if USE_CT_SYM_UF
  print("Generating: ct_sym_uf.dat\n");
  make_bin_file("dat/ct_sym_uf.dat", ct_sym_uf, C_PRM*C_TWIST, SHORT);
  #endif

  #if USE_CT_SYM_UR
  print("Generating: ct_sym_ur.dat\n");
  make_bin_file("dat/ct_sym_ur.dat", ct_sym_ur, C_PRM*C_TWIST, SHORT);
  #endif

  #if USE_CT_UF
  print("Generating: ct_uf.dat\n");
  print("Generating: ct_uf_ix.dat\n");
  populate_ct_uf();
  make_bin_file("dat/ct_uf.dat", ct_uf, N_CT_UF*81, CHAR);
  make_bin_file("dat/ct_uf_ix.dat", ct_uf_ix, C_PRM*27, INT);
  #endif

  #if USE_CT_UR
  print("Generating: ct_ur.dat\n");
  print("Generating: ct_ur_ix.dat\n");
  populate_ct_ur();
  make_bin_file("dat/ct_ur.dat", ct_ur, N_CT_UR*81, CHAR);
  make_bin_file("dat/ct_ur_ix.dat", ct_ur_ix, C_PRM*27, INT);
  #endif

  #if USE_CT_SYM3
  print("Generating: ct_sym3.dat\n");
  populate_ct_sym3();
  make_bin_file("dat/ct_sym3.dat", ct_sym3, C_TWIST*16, SHORT);
  #endif

  #if USE_CPT_SYM2
  print("Generating: cpt_sym2.dat\n");
  populate_cpt_sym2();
  make_bin_file("dat/cpt_sym2.dat", cpt_sym2, MIN_CPT*CUBE_SYM, SHORT);
  #endif
  exit(0);
}

populate_cp6c_sym()
{
  int i, j;
  char tempstr[FACELETS];

  assign_centers_6c();

  for (i=0; i < C_PERM; i++)
    {
      int_to_perm(i, cps, 8);
      set_colors_6c(0,1,2,3,4,5,6);
      make_cubestr_cnr(cnr);
      tmp_sym_map[i][0] = i;

      for (j=1; j < CUBE_SYM; j++)
	{
	  sym_op(tempstr, cubestr, map[j]);
	  tmp_sym_map[i][j] = convert_cnr_6c(tempstr, cps, cts);
	}
    }

  for (i=0; i < C_PERM; i++)
    for (j=0; j < CUBE_SYM; j++)
      cp6c_sym[i][j] = tmp_sym_map[i][j];

  populate_arr_min(cp6c_min, cp6c_min_op, C_PERM);

  populated("cp6c_sym");
  populated("cp6c_min");
  populated("cp6c_min_op");
}

populate_ep_sym()
{
  int i, j;

  assign_centers_3c();

  for (i=0; i < E_PRM; i++)
    {
      int_to_strp(ep_b3[i], eps, 11, 3);
      make_cubestr_edg(edg2);
      do_sym_ops(i, convert_edg_3c);
    }

  for (i=0; i < E_PRM; i++)
    for (j=0; j < CUBE_SYM; j++)
      ep_sym[i][j] = tmp_sym_map[i][j];

  populate_arr_min(ep_min, ep_min_op, E_PRM);

  populated("ep_sym");
  populated("ep_min");
  populated("ep_min_op");

  populate_min_ep();
}

#if USE_EP_SYM2
populate_ep_sym2()
{
  int i, ep, op;

  dependency("ep_sym", "populate_ep_sym2");

  for (i=0; i < MIN_EP; i++)
    {
      ep = min_ep[i];

      for (op=0; op < CUBE_SYM; op++)
	ep_sym2[i][op] = ep_sym[ep][op];
    }
}
#endif

#if USE_CP6C_SYM2
populate_cp6c_sym2()
{
  int i, n, op;

  dependency("cp6c_sym", "populate_cp6c_sym2");

  // check dependency min_cp6c
  populate_min_cp6c();

  for (i=0; i < MIN_CP6C; i++)
    {
      n = min_cp6c[i];

      for (op=0; op < CUBE_SYM; op++)
	cp6c_sym2[i][op] = cp6c_sym[n][op];
    }

  populated("cp6c_sym2");
}
#endif

do_sym_ops(n, convfp)
     int n;
     int (*convfp)();
{
  int i;
  char tempstr[FACELETS];

  tmp_sym_map[n][0] = n;

  for (i=1; i < CUBE_SYM; i++)
    {
      sym_op(tempstr, cubestr, map[i]);
      tmp_sym_map[n][i] = (*convfp)(tempstr);
    }
}

populate_arr_min(arr_min, arr_min_op, rows)
     int *arr_min, rows;
     char *arr_min_op;
{	
  int i, j, k, n, min, op;
  int *row, tmp[C_PRM_TW];

  for (i=0; i < rows; i++)
    tmp[i] = NIL;

  row = tmp_sym_map[0];

  for (i=k=0; i < rows; i++)
    {
      min = row[0];
      for (j=op=0; j < CUBE_SYM; j++)
	{
	  n = row[j];
	  if (row[j] < min) 
	    {
	      min = row[j]; 
	      op = j; 
	    }
	}

      if (tmp[min] == NIL)
	tmp[min] = k++;

      arr_min[i] = tmp[min];
      arr_min_op[i] = op;
      row += CUBE_SYM;
    }
}

make_cubestr_edg(edg)
     char edg[12][2];
{
  int i, j;

  for  (i=0; i < 12; i++)
    for (j=0; j < 2; j++)
      cubestr[edg_idx[i][j]] = edg[eps[i]] [(ets[i]+j)&1];
}

make_cubestr_cnr(cnr)
     char cnr[8][3];
{
  int i, j;

  for  (i=0; i < 8; i++)
    for (j=0; j < 3; j++)
	cubestr[cnr_idx[i][j]] = cnr[cps[i]] [(untwc[cts[i]]+j)%3];
}

init()
{
  make_dat_dir();
  init2();
  set_colors_3c(0, 1, 2);
  init_map(map, sym_op_FR, sym_op_UR, reflect);
}

make_dat_dir()
{
  DIR *dp;

  dp = opendir("dat");

  if (dp != NULL)
    closedir(dp);
  else
    if (mkdir("dat", 0755) != 0)
      {
	printf("ERROR: could not create subdirectory: dat\n");
	perror("");
	exit(1);
      }
}

set_colors_3c(r, f, u)
     char r, f, u;
{
  cnr2[0][0] = u;
  cnr2[0][1] = f;
  cnr2[0][2] = r;
  cnr2[1][0] = u;
  cnr2[1][1] = r;
  cnr2[1][2] = f;

  edg2[0][0] = f;   
  edg2[0][1] = r;   
  edg2[1][0] = u;
  edg2[1][1] = f;
  edg2[2][0] = u;
  edg2[2][1] = r;
}

convert_cnr_3c(s)
     char *s;
{	
  int  i, j, x, y, z;
  char U, F;

  U = s[4];     
  F = s[25];

  for (i=0; i < 8; i++)
    {
      x = s[cnr_idx[i][0]];
      y = s[cnr_idx[i][1]];
      z = s[cnr_idx[i][2]];

      if (x == U) 
	{
	  cts[i] = 0;	   // no twist
	  cps[i] = (y == F) ? 0 : 1;
	}
      else if (y == U) 
	{
	  cts[i] = 1;	   // 1/3 clockwise twist
	  cps[i] = (z == F) ? 0 : 1;
	}
      else 
	{
	  cts[i] = 2;	   // 1/3 counter-clockwise twist
	  cps[i] = (x == F) ? 0 : 1;
	}
    }

  i = b2_cp[str_to_int(cps, 7, 2)];
  j = str_to_int(cts, 7, 3);

  return(i*C_TWIST + j);
}

convert_edg_3c(s)
     char *s;
{
  int  i, x, y;
  char R, U, F;

  R = s[28];    
  U = s[4];     
  F = s[25];

  for (i=0; i < 12; i++)
    {
      x = s[edg_idx[i][0]];
      y = s[edg_idx[i][1]];
  
      // eps[i]:  0=(FR,RF)  1=(UF,FU)  2=(UR,RU)

      if ((x == U) || ((x == F) && (y == R)))         // UF UR FR
	{
	  ets[i] = 0;
	  eps[i] = (x == F) ? 0 : (y == R) ? 2 : 1;
	}
      else                                            // FU RU RF
	{
	  ets[i] = 1;
	  eps[i] = (x == F) ? 1 : (y == U) ? 2 : 0;
	}
    }
  return(b3_ep[str_to_int(eps,11,3)]);
}

assign_centers_3c()
{
  cubestr[28] = 0;  
  cubestr[25] = 1;  
  cubestr[4]  = 2;
  cubestr[22] = 0;  
  cubestr[31] = 1;  
  cubestr[49] = 2; 
}

assign_centers_6c()
{
  cubestr[28] = 0;  
  cubestr[25] = 1;  
  cubestr[4]  = 2;
  cubestr[22] = 3;  
  cubestr[31] = 4;  
  cubestr[49] = 5; 
}

print(s)
     char *s;
{	
  printf("%s", s);
  fflush(stdout);
}

get_ept(s)
     char *s;
{
  return(convert_edg_3c(s)*E_TWIST + str_to_int(ets,11,2));
}

make_ept_min_ops()
{
  int i, j, n;

  open_file("dat/ept_min_ops.dat", "w");  // assigns fp

  for (i=0; i < N_EPT_MIN_OPS; i++)
    {
      fprintf(fp, "%5d ", ept_min_ops[i][0]);
      fprintf(fp, "%4d ", ept_min_ops[i][1]);
      n = ept_min_ops[i][2];
      fprintf(fp, "%2d ", n);

      if (n < 47)
	for (j=3; j < n+3; j++)
	  fprintf(fp, "%2d ", ept_min_ops[i][j]);

      fprintf(fp, "\n");
    }

 fclose(fp);
}

#if ! USE_CP6C_MOV                   // mkt needs this to make op_mv
unsigned short cp6c_mov[C_PERM][MOVES];

populate_cp6c_mov()
{
  int i, j, k;
  char s[8], tmp[8];

  for (i=0; i < C_PERM; i++)
    {
      int_to_perm(i, s, 8);

      for (j=0; j < 8; j++) 
	tmp[j] = s[j]/4;

      cp6c_cp3c[i] = b2_cp[str_to_int(tmp,7,2)];

      for (j=0; j < MOVES; j++)
	{
	  for (k=0; k < 8; k++) 
	    tmp[k] = s[cmv[j][k]]; 
	  cp6c_mov[i][j] = perm_to_int(tmp, 8);
	}
    }
}
#endif

populate_op_tables()
{
  unsigned short *mp;
  int i, j, k;

  dependency("cp6c_sym", "populate_op_tables");
  dependency("cp6c_min", "populate_op_tables");

  populate_cp6c_mov();

  mp = cp6c_sym[CP6C_OP_ROW];

  for (i=0; i < CUBE_SYM; i++)  	
    for (j=0; j < CUBE_SYM; j++)
      if (cp6c_sym[mp[i]][j] == mp[0])
	inv_op[i] = j;

  for (i=0; i < CUBE_SYM; i++)  
    for (j=0; j < CUBE_SYM; j++)
      for (k=0; k < CUBE_SYM; k++)
	if (mp[i] == cp6c_sym[mp[j]][k])
	  op_op[j][k] = i;

  for (i=0; i < MOVES; i++)
    for (j=0; j < CUBE_SYM; j++)
      for (k=0; k < MOVES; k++)
	if (cp6c_min[cp6c_mov[mp[0]][i]] ==
	    cp6c_min[cp6c_mov[mp[j]][k]])
	  op_mv[j][k] = i;

  populated("inv_op");
  populated("op_op");
}

populate_ept_op_idx()
{ 
  int i, j, k, m;

  dependency("ep_sym", "populate_ept_op_idx");
  dependency("ep_min", "populate_ept_op_idx");
  dependency("ep_min_op", "populate_ept_op_idx");

  for (i=1; i < E_PRM; i++)
      ept_op_idx[i] = NIL;

  for (i=k=1; i < E_PRM; i++)
    { 
      m = min_ep[ep_min[i]];

      for (j=0; j < CUBE_SYM; j++)
	if ((ep_sym[i][j] == m) && (j != ep_min_op[i]))
	  {
	    ept_op_idx[i] = k++;
	    break;
	  }
    }
}

populate_ept_min_op()
{
  int i, j, k, n, ep, et, ix, min, oplist[50];
  short tmp_idx[EP_MULTI_MIN_OP];
  static char ept_op_tmp[EP_MULTI_MIN_OP][E_TWIST];        // 4.0 MB
  static char ept_op_sort[EP_MULTI_MIN_OP][E_TWIST];       // 4.0 MB

  check_et_sym_dependencies("populate_ept_min_op");

  dependency("inv_op", "populate_ept_min_op"); 

  populate_ept_op_idx();

  for (i=0; i < EP_MULTI_MIN_OP; i++)
    for (j=0; j < E_TWIST; j++)
      ept_op_tmp[i][j] = NIL;

  for (i=ix=0; i < E_PRM; i++)
    {
      if (ep_min_op[i] != 0 || ept_op_idx[i] == NIL)
	continue;

      for (j=0; j < E_TWIST; j++)
	{
	  if (ept_op_tmp[ept_op_idx[i]][j] != NIL)
	    continue;
	  
	  ept_op_tmp[ept_op_idx[i]][j] = 0;
	  min = i*E_TWIST + j;
	  
	  for (n=0, k=1; k < CUBE_SYM; k++)
	    {
	      ep = ep_sym[i][k];
	      et = get_etsym(i, j, k);
	      ept_op_tmp[ept_op_idx[ep]][et] = inv_op[k];

	      if (ep*E_TWIST + et == min)
		oplist[n++] = k;
	    }  

	  if (n)
	    {
	      ept_min_ops[ix][0] = i;
	      ept_min_ops[ix][1] = j;
	      ept_min_ops[ix][2] = n;
	      
	      if (n < 47)
		for (k=0; k < n; k++)
		  ept_min_ops[ix][k+3] = oplist[k];
	      ix++;
	    }
	}
    }

  populated("ept_min_ops");

  // the following eliminates duplicate rows which reduces the ept_min_op 
  // array size from 2058 to 1290 rows.

  memcpy(ept_op_sort, ept_op_tmp, E_TWIST*EP_MULTI_MIN_OP);
  qsort(ept_op_sort, EP_MULTI_MIN_OP, E_TWIST, ept_op_row_compare);

  for (i=ix=1; i < EP_MULTI_MIN_OP; i++)
    if (ept_op_row_compare(ept_op_sort[i], ept_op_sort[ix-1]) != 0)
      memcpy(ept_op_sort[ix++], ept_op_sort[i], E_TWIST);

  for (i=0; i < EP_MULTI_MIN_OP; i++)
    {
      ix = (int)bsearch(ept_op_tmp[i], ept_op_sort, N_EPT_MIN_OP, E_TWIST, 
		    ept_op_row_compare);

      tmp_idx[i] = (ix-(int)ept_op_sort)/E_TWIST;
    }

  for (i=0; i < E_PRM; i++)
    if (ept_op_idx[i] != NIL)
      ept_op_idx[i] = tmp_idx[ept_op_idx[i]];

  memcpy(ept_min_op, ept_op_sort, N_EPT_MIN_OP*E_TWIST);
  populated("ept_min_op");
}

#if USE_EPT_MIN_OP2
populate_ept_min_op2a()
{
  // this reduces the size of ept_min_op to 103 rows by only storing rows
  // for the edge position symmetry minimums.  the array stores both the
  // op and the etsym.  the op must be applied to ep_min_op (epi->op) to 
  // get the actual op.

  int  ep, et, ix, op, op2, op3, op4, epsym, etsym, etsym2;

  dependency("ept_min_op", "populate_ept_min_op2a");

  populate_ept_ops_indexes();

  for (ep=0; ep < E_PRM; ep++)
    {
      if (ept_op_idx[ep] == NIL)
	continue;
      
      epsym = min_ep[ep_min[ep]];
      op = ep_min_op[ep];
      
      for (et=0; et < E_TWIST; et++)
	{
	  op2 = ept_min_op[ept_op_idx[ep]][et];
	  etsym = get_etsym(ep, et, op);
	  op3 = ept_min_op[ept_op_idx[epsym]][etsym];
	  op4 = op_op[op][op3];
	  etsym2 = get_etsym(ep, et, op4);
	  ix = ept_ops_ix1[ep_min[ep]];
	  ept_min_op2a[ix][etsym].op = op3;
	  ept_min_et[ix][etsym] = etsym2;
	}
    }
  populated("ept_min_op2a", "populate_ept_min_op2a");
  populated("ept_min_et", "populate_ept_min_op2a");
}
#endif

ept_op_row_compare(a, b)
     char *a, *b;
{
  return(memcmp(a, b, E_TWIST));
}

populate_cpt_sym()
{
  int i, j, k, x, cpt, sym[CUBE_SYM];
  char sav[8];
  int tmp_cpt_min[C_PRM_TW];

  assign_centers_3c();

  for (i=0; i < C_PRM_TW; i++)
    {
      tmp_cpt_min[i] = NIL;
      cpt_min_op[i] = 99;
    }

  for (i=x=0; i < C_PRM; i++)
    {
      int_to_strp(cp_b2[i], sav, 7, 2);

      for (j=0; j < C_TWIST; j++)
	{
	  int_to_strp(j, cts, 7, 3);

	  for (k=0; k < 8; k++) 
	    cps[k] = sav[k];

	  make_cubestr_cnr(cnr2);
	  cpt = i*C_TWIST + j;

	  if (tmp_cpt_min[cpt] == NIL)
	  {
	    do_min_sym_ops(cpt, x, tmp_cpt_min, cpt_min_op, sym);

	    for (k=0; k < CUBE_SYM; k++)
	      {
		cpt_sym[x][k].cp = sym[k]/C_TWIST;
		cpt_sym[x][k].ct = sym[k]%C_TWIST;
	      }
	    x++;
	  }
	}
    }

  for (i=0; i < C_PRM_TW; i++)
    cpt_min[i] = tmp_cpt_min[i];
}

do_min_sym_ops(n, min, arr_min, arr_min_op, sym)
     int n, min, *arr_min, *sym;
     char *arr_min_op;
{
  int i, v;
  char tempstr[FACELETS];

  sym[0] = n;
  arr_min[n] = min;
  arr_min_op[n] = 0;

  for (i=1; i < CUBE_SYM; i++)
    {
      sym_op(tempstr, cubestr, map[i]);
      v = convert_cnr_3c(tempstr);
      sym[i] = v;
      arr_min[v] = min;

      if (inv_op[i] < arr_min_op[v])
	arr_min_op[v] = inv_op[i];
    }
}

populate_et_sym()
{
  int i, j;
  char tempstr[FACELETS];

  dependency("op_op", "populate_et_sym");

  init_op16e();
  assign_centers_3c();
  int_to_strp(ep_b3[0], eps, 11, 3);

  for(i=0; i < E_TWIST;  i++)
    for (j=0; j < CUBE_SYM; j++)
      if (op16e[j].op1 == 0)
	  {
	    int_to_strp(i, ets, 11, 2);
	    make_cubestr_edg(edg2);
	    sym_op(tempstr, cubestr, map[j]);
	    convert_edg_3c(tempstr);
	    et_sym[i][j] = str_to_int(ets,11,2);
	  }

  populated("et_sym");
}

populate_et_sym_arr(arr, op, slice)
     unsigned short arr[][E_TWIST];
     int op, slice;
{
  int i, j;
  char tempstr[FACELETS], sav[12];

  assign_centers_3c();

  for (i=0; i < SLICE_PRM; i++)
    {
      int_to_strp(ep_b3[slice_ep[i][slice]], eps, 11, 3);
      memcpy(sav, eps, 12);

      for (j=0; j < E_TWIST; j++)
	{
	  memcpy(eps, sav, 12);
	  int_to_strp(j, ets, 11, 2);
	  make_cubestr_edg(edg2);
	  sym_op(tempstr, cubestr, map[op]);
	  convert_edg_3c(tempstr);
	  arr[i][j] = str_to_int(ets,11,2);
	}
    }

  if (op == OP_FR)
    populated("et_sym_fr");

  if (op == OP_UF)
    populated("et_sym_uf");
}

update_et_sym()   // used by ET_SYM_METHODS 2-5
{
  /* 
     This updates et_sym[] so that et_sym_UF[] is no longer needed, 
     etsym can be obtained like this:

     if (op16e[op].op1 == 0)
       etsym = et_sym[et][op];
     else			      
        etsym = (op16e[op].op1 == OP_FR) ?
          et_sym[et_sym_FR[epi->s0][et]][op]:
          et_sym[et_sym_FR[epi->s1][et]][op];

     as opposed to this:

     if (op16e[op].op1 == 0)
       etsym = et_sym[et][op];
     else
       etsym = (op16e[op].op1 == OP_FR) ?
         et_sym[et_sym_FR[epi->s0][et]][op]:
         et_sym[et_sym_UF[epi->s1][et]][op];
  */

  int i, j, op, et_fr, et_uf;
  char op_lr[16] = { 1, 2, 3, 4, 9,10,11,12,25,26,27,28,33,34,35,36};
  char op_fb[16] = {13,14,15,16,17,18,19,20,37,38,39,40,41,42,43,44};

  for (i=0; i < 16; i++)
    {
      op = op_lr[i];

      for (j=0; j < E_TWIST; j++)
	et_sym[j][op] = et_sym[j][op16e[op].op2];
    }

  for (i=0; i < 16; i++)
    {
      op = op_fb[i];

      for (j=0; j < E_TWIST; j++)
	{
	  et_fr = et_sym_FR[0][j];
	  et_uf = et_sym_UF[0][j];
	  et_sym[et_fr][op] = et_sym[et_uf][op16e[op].op2];
	}
    }
}

check_et_sym_dependencies(s)
     char *s;
{
  dependency("et_sym", s);	
  dependency("et_sym_fr", s);
  dependency("et_sym_uf", s);
}

#if ! USE_EPR_SYM2
populate_epr_sym()
{
  char init_str[12]={0,1,2,3,0,1,2,3,0,1,2,3};
  char epr[3], eps_3c[12],  eps_3r[12], tempstr[FACELETS];
  int i, j, k, op, slice, slice_sym;

  assign_centers_6c();

  for (slice=0; slice < 3; slice++)
    for (op=0; op < CUBE_SYM; op++)
      {
	slice_sym = slice_map[op][slice];
	
	for (i=0; i < SLICE_PRM; i++)
	  {
	    int_to_strp(ep_b3[slice_ep[i][slice]], eps_3c, 11, 3);
	    memcpy(eps_3r, init_str, 12);
	    
	    for (j=0; j < 24; j++)
	      {
		int_to_perm(j, &eps_3r[slice*4], 4);
		mk_eps_6c(eps, eps_3c, eps_3r);
		set_colors_6c(0,1,2,3,4,5);
		make_cubestr_edg(edg);
		sym_op(tempstr, cubestr, map[op]);
		convert_edg_6c(tempstr, eps, ets);
		ep6c_epr(eps, epr);
		epr_sym[op][i][j][slice] = epr[slice_sym];
	      }
	  }
      }
}
#endif

#if USE_EPR_SYM2
populate_epr_sym2()
{
  char init_str[12]={0,1,2,3,0,1,2,3,0,1,2,3};
  char s[24], epr[3], eps_3c[12], eps_3r[12], tempstr[FACELETS];
  short tmp_idx[E_PRMr];
  int i, j, ix, op, key, slice, slice_sym;

  assign_centers_6c();

  for (i=0; i < E_PRMr; i++)
    tmp_idx[i] = NIL;

  for (ix=slice=0; slice < 3; slice++)
    for (op=0; op < CUBE_SYM; op++)
      {
	slice_sym = slice_map[op][slice];

	for (i=0; i < SLICE_PRM; i++)
	  {
	    int_to_strp(ep_b3[slice_ep[i][slice]], eps_3c, 11, 3);
	    memcpy(eps_3r, init_str, 12);
	    
	    for (j=0; j < 24; j++)
	      {
		int_to_perm(j, &eps_3r[slice*4], 4);
		mk_eps_6c(eps, eps_3c, eps_3r);
		set_colors_6c(0,1,2,3,4,5);
		make_cubestr_edg(edg);
		sym_op(tempstr, cubestr, map[op]);
		convert_edg_6c(tempstr, eps, ets); 
		ep6c_epr(eps, epr);
		s[j] = epr[slice_sym];

		if (j == 2)
		  {
		    key = (s[0]*24 + s[1])*24 + s[2];

		    if (tmp_idx[key] == NIL)
		      {
			tmp_idx[key] = ix++;
			epr_idx[op][i][slice] = tmp_idx[key];
		      }
		    else 
		      { 
			epr_idx[op][i][slice] = tmp_idx[key];
			break;
		      } 
		  }
	      }

	    if (j > 2)
	      memcpy(epr_sym2[tmp_idx[key]], s, 24);
	  }
      }
}
#endif

#if USE_ET_FR
populate_et_fr()
{
  int b, i, j, k, n, ix, v1, v2;
  int key[N_ET_FR][2];

  for (i=ix=0; i < SLICE_PRM; i++)
    {
      for (j=0; j < E_TWIST; j+=128)
	{
	  b = et_sym_FR[i][j];
	  v1 = et_sym_FR[i][j+126] - b;
	  v2 = et_sym_FR[i][j+127] - b;
	  
	  for (n=0; n < ix; n++)
	    if (key[n][0] == v1 && key[n][1] == v2)
	      break;

	  if (n >= N_ET_FR)
	    {
	      printf("Program error in populate_et_ixs, ix >= N_ET_FR\n");
	      exit (1);
	    }

	  #if (ET_SYM_METHOD == 3 || ET_SYM_METHOD == 4)
	  et_fr_ix[i][j>>7].base = b;
	  et_fr_ix[i][j>>7].ix = n;
	  #endif

	  #if (ET_SYM_METHOD == 5)
	  et_fr_ixb[(i<<4)+(j>>7)] = b;
	  et_fr_ixv[(i<<4)+(j>>7)] = n;
	  #endif

	  if (n == ix)
	    {
	      key[ix][0] = v1;
	      key[ix][1] = v2;

	      for (k=0; k < 128; k++)
		et_fr[ix][k] = et_sym_FR[i][j+k] - b;

	      ix++;
	    }
	}
    }

  if (ix != N_ET_FR)
    {
      printf("Program error in populate_et_ixs, ix != N_ET_FR\n");
      exit(1);
    }
}
#endif

#if USE_ET_UF
populate_et_uf()
{
  int b, i, j, k, n, ix, v1, v2;
  int key[N_ET_UF][2];

  for (i=ix=0; i < SLICE_PRM; i++)
    {
      for (j=0; j < E_TWIST; j+=64)
	{
	  b = et_sym_UF[i][j];
	  v1 = et_sym_UF[i][j+62] - b;
	  v2 = et_sym_UF[i][j+63] - b;
	  
	  for (n=0; n < ix; n++)
	    if (key[n][0] == v1 && key[n][1] == v2)
	      break;

	  if (n >= N_ET_UF)
	    {
	      printf("Program error in populate_et_uf, ix >= N_ET_UF\n");
	      exit(1);
	      return;
	    }

	  #if (ET_SYM_METHOD == 3)
	  et_uf_ix[i][j>>6].base = b;
	  et_uf_ix[i][j>>6].ix = n;
	  #endif

	  #if (ET_SYM_METHOD == 5)
	  et_uf_ixb[(i<<5)+(j>>6)] = b;
	  et_uf_ixv[(i<<5)+(j>>6)] = n;
	  #endif

	  if (n == ix)
	    {
	      key[ix][0] = v1;
	      key[ix][1] = v2;

	      for (k=0; k < 64; k++)
		{
		  et_uf[ix][k] = et_sym_UF[i][j+k] - b;
		}

	      ix++;
	    }
	}
    }

  if (ix != N_ET_UF)
    {
      printf("Program error in populate_et_uf, ix != N_ET_UF\n");
      exit(1);
    }
}
#endif

#if USE_CT_UF
populate_ct_uf()
{
  int b, i, j, k, n, ix, v1, v2;
  int key[N_CT_UF][2];

  // dependency ct_sym_uf

  for (i=ix=0; i < C_PRM; i++)
    {
      for (j=0; j < C_TWIST; j+=81)
	{
	  b = ct_sym_uf[i][j];
	  v1 = ct_sym_uf[i][j+79] - b;
	  v2 = ct_sym_uf[i][j+80] - b;
	  
	  for (n=0; n < ix; n++)
	    if (key[n][0] == v1 && key[n][1] == v2)
	      break;

	  if (n >= N_CT_UF)
	    {
	      printf("Program error in populate_ct_uf, ix >= N_CT_UF\n");
	      exit (1);
	    }

	  ct_uf_ix[i][j/81].base = b;
	  ct_uf_ix[i][j/81].ix = n;

	  if (n == ix)
	    {
	      key[ix][0] = v1;
	      key[ix][1] = v2;

	      for (k=0; k < 81; k++)
		ct_uf[ix][k] = ct_sym_uf[i][j+k] - b;

	      ix++;
	    }
	}
    }

  if (ix != N_CT_UF)
    {
      printf("Program error in populate_ct_uf, ix != N_CT_UF\n");
      exit(1);
    }

  populated("ct_uf");
}
#endif

#if USE_CT_UR
populate_ct_ur()
{
  int b, i, j, k, n, ix, v1, v2;
  int key[N_CT_UR][2];

  for (i=ix=0; i < C_PRM; i++)
    {
      for (j=0; j < C_TWIST; j+=81)
	{
	  b = ct_sym_ur[i][j];
	  v1 = ct_sym_ur[i][j+79] - b;
	  v2 = ct_sym_ur[i][j+80] - b;
	  
	  for (n=0; n < ix; n++)
	    if (key[n][0] == v1 && key[n][1] == v2)
	      break;

	  if (n >= N_CT_UR)
	    {
	      printf("Program error in populate_ct_ur, ix >= N_CT_UR\n");
	      exit (1);
	    }

	  ct_ur_ix[i][j/81].base = b;
	  ct_ur_ix[i][j/81].ix = n;

	  if (n == ix)
	    {
	      key[ix][0] = v1;
	      key[ix][1] = v2;

	      for (k=0; k < 81; k++)
		ct_ur[ix][k] = ct_sym_ur[i][j+k] - b;

	      ix++;
	    }
	}
    }

  if (ix != N_CT_UR)
    {
      printf("Program error in populate_ct_ur, ix != N_CT_UR\n");
      exit(1);
    }
}
#endif

/****************************************************************************/

#if USE_CP_SYM
populate_cp_sym()
{
  int i, j;

  assign_centers_3c();

  for (i=0; i < C_PRM; i++)
    {
      int_to_strp(cp_b2[i], cps, 7, 2);
      make_cubestr_cnr(cnr2);
      do_sym_ops(i, convert_cnr_3c);
    }

  for (i=0; i < C_PRM; i++)
    for (j=0; j < CUBE_SYM; j++)
      cp_sym[i][j] = tmp_sym_map[i][j]/C_TWIST;

  for (i=0; i < C_PRM; i++)
    cp_sym[i][0] = i;
}
#endif

#if USE_CPT_SYM2
populate_cpt_sym2()
{
  int i, j;

  for (i=0; i < MIN_CPT; i++)
    for (j=0; j < CUBE_SYM; j++)
      cpt_sym2[i][j] = cpt_sym[i][j].ct;
}
#endif

#if USE_CT_SYM
populate_ct_sym()
{
  int i, j, k;
  char sav[8];
  
  if (sizeof(tmp_sym_map) != C_PRM_TW*CUBE_SYM*INT)
    {
      printf("ERROR:  array tmp_sym_map too small, declare as:\n");
      printf("        int tmp_sym_map[C_PRM_TW][CUBE_SYM];\n");
      exit(1);
    }

  assign_centers_3c();

  for (i=0; i < C_PRM; i++)
    {
      int_to_strp(cp_b2[i], sav, 7, 2);
      
      for (j=0; j < C_TWIST; j++)
	{
	  int_to_strp(j, cts, 7, 3);

	  for (k=0; k < 8; k++) 
	    cps[k] = sav[k];
	  make_cubestr_cnr(cnr2);
	  do_sym_ops(i*C_TWIST+j, convert_cnr_3c);
	}
    }
  
  for (i=0; i < C_PRM; i++)
    for (j=0; j < C_TWIST; j++)
      for (k=0; k < CUBE_SYM; k++)
	ct_sym[i][j][k] = tmp_sym_map[i*C_TWIST+j][k]%C_TWIST;

  populated("ct_sym");
}
#endif

#if USE_CT_SYM2
populate_ct_sym2()
{
  int i, j;
  char tempstr[FACELETS];

  dependency("op_op", "populate_ct_sym2");

  init_op16c();
  assign_centers_3c();
  int_to_strp(cp_b2[0], cps, 7, 2);

  for(i=0; i < C_TWIST;  i++)
    for (j=0; j < CUBE_SYM; j++)
      if (op16c[j].op1 == 0)
	{
	  int_to_strp(i, cts,7, 3);
	  make_cubestr_cnr(cnr2);
	  sym_op(tempstr, cubestr, map[j]);
	  convert_cnr_3c(tempstr);
	  ct_sym2[i][j] = str_to_int(cts,7,3);
	}

  populated("ct_sym2");
}
#endif

#if USE_CT_SYM_ARR
populate_ct_sym_arr(arr, op)
     unsigned short arr[][C_TWIST];
     int op;
{
  int i, j;
  char tempstr[FACELETS], sav[12];

  assign_centers_3c();

  for (i=0; i < C_PRM; i++)
    {
      int_to_strp(cp_b2[i], cps, 7, 2);
      memcpy(sav, cps, 8);

      for (j=0; j < C_TWIST; j++)
	{
	  memcpy(cps, sav, 8);
	  int_to_strp(j, cts, 7, 3);
	  make_cubestr_cnr(cnr2);
	  sym_op(tempstr, cubestr, map[op]);
	  convert_cnr_3c(tempstr);
	  arr[i][j] = str_to_int(cts,7,3);
	}
    }
}
#endif

#if USE_CT_SYM3
populate_ct_sym3()
{
  int i, j;
  char op_ud[16] = {0,1,3,5,7,9,11,22,24,25,27,29,31,33,35,46};

  dependency("ct_sym2", "populate_ct_sym3");

  for (i=0; i < C_TWIST; i++)
    for (j=0; j < 16; j++)
      ct_sym3[i][j] = ct_sym2[i][op_ud[j]];
}
#endif

#if USE_ET_SYM16
populate_et_sym16()
{
  int i, j;
  char op_ud[16] = {0,5,6,7,8,21,22,23,24,29,30,31,32,45,46,47};

  for (i=0; i < E_TWIST; i++)
    for (j=0; j < 16; j++)
      et_sym16[i][j] = et_sym[i][op_ud[j]];
}
#endif

#if USE_ET_SYM32
populate_et_sym32()
{
  int i, j;
  char op_ud[16] = { 0, 5, 6, 7, 8,21,22,23,24,29,30,31,32,45,46,47};
  char op_fb[16] = {13,14,15,16,17,18,19,20,37,38,39,40,41,42,43,44};

  for (i=0; i < E_TWIST; i++)
    for (j=0; j < 16; j++)
      et_sym32[i][j] = et_sym[i][op_ud[j]];

  for (i=0; i < E_TWIST; i++)
    for (j=0; j < 16; j++)
      et_sym32[i][j+16] = et_sym[i][op_fb[j]];
}
#endif

get_etsym(ep, et, op)
     int ep, et, op;
{
  int ix, sym, epslice;
  struct s_et_ix *etix;

  if (op16e[op].op1 == 0)
    sym = et_sym[et][op];
  else
    {
      epslice = (op16e[op].op1 == OP_FR) ? ep_slice[ep][0] : ep_slice[ep][1];

      #if (ET_SYM_METHOD == 1 || ET_SYM_METHOD == 2)
      sym = et_sym[et_sym_FR[epslice][et]][op];
      #endif

      #if (ET_SYM_METHOD == 3 || ET_SYM_METHOD == 4)
      etix = &et_fr_ix[epslice][et>>7];
      sym = et_sym[etix->base + et_fr[etix->ix][et&127]][op];
      #endif

      #if (ET_SYM_METHOD == 5)
      ix = (epslice<<4) + (et>>7);
      sym = et_sym[et_fr_ixb[ix] + et_fr[et_fr_ixv[ix]][et&127]][op];
      #endif
    }

  return(sym);
}

#if USE_EPT_MIN_OP2
update_ept_min_op2a()
{
  // this updates the flag in ept_min_op2a which is used to determine 
  // if get_min_op_3c() is to be called (without having to access the
  // 400k ept_ops_ix2)

  int i, j;

  populate_ept_ops_indexes();

  for (i=0; i < N_EPT_OPS_IX2; i++)
    for (j=0; j < E_TWIST; j++)
      ept_min_op2a[i][j].f = (ept_ops_ix2[i][ept_min_et[i][j]]==NIL)?0:1;
}
#endif

ept_min_op_compare(a, b)
struct s_min_op *a, *b;
{
  int i;

  for (i=0; i < E_TWIST; i++)
    if (a[i].op > b[i].op)
      return(1);
    else if (a[i].op < b[i].op)
      return(-1);

  return(0);
}

populate_ept_min_op2()
{
  int i, j, ix;
  static struct s_min_op tmp[N_EPT_OPS_IX2][E_TWIST];
  char tmp_ix[N_EPT_OPS_IX2];
  
  dependency("ept_min_op2a", "populate_ept_min_op2");
  dependency("ept_ops_ix1", "populate_ept_min_op2");

  memcpy(tmp, ept_min_op2a, N_EPT_OPS_IX2*E_TWIST);

  qsort(tmp, N_EPT_OPS_IX2, E_TWIST, ept_min_op_compare);

  for (i=ix=1; i < N_EPT_OPS_IX2; i++)
    if (ept_min_op_compare(tmp[i], tmp[ix-1]) != 0)
      memcpy(tmp[ix++], tmp[i], E_TWIST);

  for (i=0; i < N_EPT_OPS_IX2; i++)
    {
      ix = (int)bsearch(ept_min_op2a[i], tmp, 57, E_TWIST, 
		    ept_min_op_compare);

      tmp_ix[i] = (ix-(int)tmp)/E_TWIST;
    }

  memcpy(ept_min_op2, tmp, 57*E_TWIST);

  for (i=0; i < MIN_EP; i++)
    if (ept_ops_ix1[i] == NIL)
      ept_op_ix2[i] = NIL;
    else
      ept_op_ix2[i] = tmp_ix[ept_ops_ix1[i]];

  populated("ept_min_op2");
  populated("ept_op_ix2");
}
