// Author: Michael Feather

#include "rc.h"

#if USE_GET_MIN_OP_3C_M1
get_min_op_3c_m1(c)
struct S_CUBE *c;
{	
  int i, n, dif, min, min_op, sym, cpsav, ctsav, cpsym, ctsym;
  struct s_cpt csym;
  unsigned short *oplist;

  n = ept_min_ops[c->ops_idx][2];

  if (n == 47)
    {
      c->op = cpt_min_op[c->cp*C_TWIST+c->ct];
      return;
    }

  if (SHOW_MIN_OP_COUNT)
    min_op_count2 += n+1;

  oplist = &ept_min_ops[c->ops_idx][3];

  cpsav = cp_sym[c->cp][c->op];
  ctsav = ct_sym[c->cp][c->ct][c->op];
  min = (cpsav<<16) + ctsav;

  for (i=dif=0; i < n; i++)
    {
      cpsym = cp_sym[cpsav][oplist[i]];
      ctsym = ct_sym[cpsav][ctsav][oplist[i]];
      sym = (cpsym<<16) + ctsym;

      if (sym < min)
	{
	  min = sym;
	  min_op = oplist[i];
	  dif = 1;
	}
    }

  if (dif)
    c->op = op_op[c->op][min_op];
}
#endif

#if USE_GET_MIN_OP_3C_M2
get_min_op_3c_m2(c)
struct S_CUBE *c;
{	
  int i, n, dif, min, min_op, sym;
  unsigned short *oplist;
  struct s_min cpt;
  struct s_cpt csym;

  cpt = c->cpt;

  n = ept_min_ops[c->ops_idx][2];

  if (n == 47)
    {
      c->op = inv_op[cpt.op];
      return;
    }

  if (SHOW_MIN_OP_COUNT)
    min_op_count2 += n+1;

  oplist = &ept_min_ops[c->ops_idx][3];

  cpt.op = op_op[cpt.op][c->op];
  csym = cpt_sym[cpt.min][cpt.op];
  min = (csym.cp<<16) + csym.ct;

  for (i=dif=0; i < n; i++)
    {
      csym = cpt_sym[cpt.min][op_op[cpt.op][oplist[i]]];
      sym = (csym.cp<<16) + csym.ct;

      if (sym < min)
	{
	  min = sym;
	  min_op = oplist[i];
	  dif = 1;
	}
    }

  if (dif)
    c->op = op_op[c->op][min_op];
}
#endif

#if USE_GET_MIN_OP_3C_M3
get_min_op_3c_m3(c)
struct S_CUBE *c;
{	
  int i, n, dif, min, min_op, sym, cpsym, ctsym, cpsav;
  unsigned short *oplist;
  struct s_min cpt;

  cpt = c->cpt;

  n = ept_min_ops[c->ops_idx][2];

  if (n == 47)
    {
      c->op = inv_op[cpt.op];
      return;
    }

  if (SHOW_MIN_OP_COUNT)
    min_op_count2 += n+1;

  oplist = &ept_min_ops[c->ops_idx][3];

  cpsav = cp_sym[c->cp][c->op];
  cpt.op = op_op[cpt.op][c->op];
  ctsym = cpt_sym2[cpt.min][cpt.op];
  min = (cpsav<<16) + ctsym;

  for (i=dif=0; i < n; i++)
    {
      cpsym = cp_sym[cpsav][oplist[i]];
      ctsym = cpt_sym2[cpt.min][op_op[cpt.op][oplist[i]]];
      sym = (cpsym<<16) + ctsym;

      if (sym < min)
	{
	  min = sym;
	  min_op = oplist[i];
	  dif = 1;
	}
    }

  if (dif)
    c->op = op_op[c->op][min_op];
}
#endif

#if USE_GET_CTSYM_M4
get_ctsym_m4(cp, ct, op)
     int cp, ct, op;
{
  int sym;

  if (op16c[op].op1 == 0) 
    sym = ct_sym3[ct][op16c[op].op2];

  else if (op16c[op].op1 == OP_UFc) 
    sym = ct_sym3[ct_sym_uf[cp][ct]] [op16c[op].op2];

  else 
    sym = ct_sym3[ct_sym_ur[cp][ct]] [op16c[op].op2];

  return(sym);
}
#endif 

#if USE_GET_MIN_OP_3C_M4
get_min_op_3c_m4(c)
struct S_CUBE *c;
{	
  int i, n, dif, min, min_op, sym, cpsav, ctsav, cpsym, ctsym;
  struct s_cpt csym;
  unsigned short *oplist;

  n = ept_min_ops[c->ops_idx][2];

  if (n == 47)
    {
      c->op = cpt_min_op[c->cp*C_TWIST+c->ct];
      return;
    }

  if (SHOW_MIN_OP_COUNT)
    min_op_count2 += n+1;

  oplist = &ept_min_ops[c->ops_idx][3];

  cpsav = cp_sym[c->cp][c->op];
  ctsav = GET_CTSYM(c->cp, c->ct, c->op);
  min = (cpsav<<16) + ctsav;

  for (i=dif=0; i < n; i++)
    {
      cpsym = cp_sym[cpsav][oplist[i]];
      ctsym = GET_CTSYM(cpsav, ctsav, oplist[i]);
      sym = (cpsym<<16) + ctsym;

      if (sym < min)
	{
	  min = sym;
	  min_op = oplist[i];
	  dif = 1;
	}
    }

  if (dif)
    c->op = op_op[c->op][min_op];
}
#endif

#if USE_GET_CTSYM_M5
get_ctsym_m5(cp, ct, op)
int cp, ct, op;
{
  int sym;
  struct s_ct_ix *ctix;

  if (op16c[op].op1 == 0) 
      sym = ct_sym3[ct][op16c[op].op2];

  else if (op16c[op].op1 == OP_UFc) 
    {
      ctix = &ct_uf_ix[cp][div_81[ct]];
      sym = ct_sym3[ctix->base + ct_uf[ctix->ix]
		    [mod_81[ct]]][op16c[op].op2];
    }
  else 
    {
      ctix = &ct_ur_ix[cp][div_81[ct]];
      sym = ct_sym3[ctix->base + ct_ur[ctix->ix]
		    [mod_81[ct]]][op16c[op].op2];
    }
  return(sym);
}
#endif 
