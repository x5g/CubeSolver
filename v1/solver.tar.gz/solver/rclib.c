// Author: Michael Feather 

int child_procs;

#include "rc.h"
#include <sys/stat.h>

char    cw[3], ccw[3], flip[2];
int	cftw(), crtw(), eftw(), cltw(), cbtw(), ebtw();

#define HOME_CUBE        1
#define INV_CUBE_CORNER  2
#define INV_CUBE_EDGE    3
#define INV_CUBE_PARITY  4

unsigned int nodes[2];

init1()
{
  int i, j, k;

  char init_qtm_ftm[12]={0,2,3,5,6,8,9,11,12,14,15,17};
  char init_ftm_qtm[18]={0,NIL,1,2,NIL,3,4,NIL,5,6,NIL,7,8,NIL,9,10,NIL,11};

  metric = (QTM) ? 'Q' : 'F' ;

  memcpy(qtm_ftm, init_qtm_ftm, 12);
  memcpy(ftm_qtm, init_ftm_qtm, 18);

  if (!QTM)
    for (i=0; i < 18; i++)
      ccw_mv[i] = (i%3)>1;

  flip[0] = 1;

  if (QTM) 
     init_p2_dist();

  copy(cw,   "120", 3);
  copy(ccw,  "201", 3);
  copy(untwc,"021", 3);

  ctw[0]  = ctw[2]  = crtw;
  ctw[3]  = ctw[5]  = cltw;
  ctw[12] = ctw[14] = cftw;
  ctw[15] = ctw[17] = cbtw;
  etw[12] = etw[14] = eftw; 
  etw[15] = etw[17] = ebtw;

  if (QTM)
    for (i=0; i < MOVES; i++) 
      {
	ctw[i] = ctw[qtm_ftm[i]];
	etw[i] = etw[qtm_ftm[i]];
      }

  // assign cubie locations for cw moves, see set_colors_6c() for layout

  copy(cmv[0],  "07254163", 8);   // right
  copy(cmv[3],  "61430527", 8);   // left
  copy(cmv[6],  "51264307", 8);   // up
  copy(cmv[9],  "04732561", 8);   // down
  copy(cmv[12], "45231067", 8);   // front
  copy(cmv[15], "01674532", 8);   // back

  copy(emv[0],  "0A934567812B", 12);
  copy(emv[3],  "812B456739A0", 12);
  copy(emv[6],  "0123956847AB", 12);
  copy(emv[9],  "01234BA78956", 12);
  copy(emv[12], "5423016789AB", 12);
  copy(emv[15], "0167453289AB", 12);

  // apply primary moves to fill in remaining moves
  
  for (i=0; i < 2; i++)	   // populate cmv[1,2,4,5,7,8...]
    for (j=0; j < 18; j+=3)
      for (k=0; k < 8; k++)
	cmv[i+j+1][k] = cmv[i+j][cmv[j][k]];
  
  for (i=0; i < 2; i++)	   
    for (j=0; j < 18; j+=3)
      for (k=0; k < 12; k++)
	emv[i+j+1][k] = emv[i+j][emv[j][k]];

  // relocate moves for qtm

  if (QTM)
    {
      for (i=0; i < MOVES; i++) 
	for (j=0; j < 8; j++)
	  cmv[i][j] = cmv[qtm_ftm[i]][j];
      
      for (i=0; i < MOVES; i++) 
	for (j=0; j < 12; j++)
	  emv[i][j] = emv[qtm_ftm[i]][j];
    }
}

init2()
{
  int i, j, k;
  char s[20], tmp[20];

  init1();
  set_indexes();
  init_conv();
  init_seq();
    
  // populate tables for converting between perm & int for 3-color perms

  for (i=j=0; i < B2_MAX; i++)
    if (int_to_str_lim(i, s, 7, 2, 4))
      {
	b2_cp[i] = j;
	cp_b2[j++] = i;
      }
  for (i=j=0; i < B3_MAX; i++)
    if (int_to_str_lim(i, s, 11, 3, 4))
      {
	b3_ep[i] = j;
	ep_b3[j++] = i;
      }
  
  for (i=0; i < C_PRM; i++)   
    {
      int_to_strp(cp_b2[i], s, 7, 2);

      for (j=0; j < MOVES; j++)
	{	
	  for (k=0; k < 8; k++) 
	    tmp[k] = s[cmv[j][k]]; 
	  cp_mov[i][j] = b2_cp[str_to_int(tmp,7,2)];
	}		
    }
  populated("cp_mov");

  for (i=0; i < C_PERM; i++)
    {
      int_to_perm(i, s, 8);

      for (j=0; j < 8; j++) 
	tmp[j] = s[j]/4;

      cp6c_cp3c[i] = b2_cp[str_to_int(tmp,7,2)];
    }

  for (i=0; i < C_TWIST; i++)
    {
      int_to_strp(i,s,7,3);

      for (j=0; j < MOVES; j++)
	{
	  for (k=0; k < 7; k++) 
	    tmp[k] = s[cmv[j][k]]; 

	  if (ctw[j]) 
	    ctw[j](tmp); 

	  ct_mov[i][j] = str_to_int(tmp,7,3); 
	}
    }
  populated("ct_mov");

  #if USE_EP_MOV
  for (i=0; i < E_PRM; i++)
    {
      int_to_strp(ep_b3[i], s, 11, 3);

      for (j=0; j < MOVES; j++)
	{
	  for (k=0; k < 12; k++) 
	    tmp[k] = s[emv[j][k]]; 

	  ep_mov[i][j] = b3_ep[str_to_int(tmp,11,3)];
	}		
    }
  populated("ep_mov");
  #endif

  for (i=0; i < E_TWIST; i++)
    {
      int_to_strp(i,s,11,2);

      for (j=0; j < MOVES; j++)
	{
	  for (k=0; k < 11; k++) 
	    tmp[k] = s[emv[j][k]]; 

	  if (etw[j]) 
	    etw[j](tmp); 

	  et_mov[i][j] = str_to_int(tmp,11,2); 
	}		
    }
  populated("et_mov");

  init_slice_map();
  populate_b2_slice();
  populate_ep_slice();
  populate_slice_ep();
  populate_cp6c_cpr();

  #if USE_EPR_MOV2
  populate_epr_mov2();
  #else
  populate_epr_mov();
  #endif

  #if USE_DIV_81
  for (i=0; i < C_TWIST; i++)
    {
      div_81[i] = i/81;
      mod_81[i] = i%81;
    }
  #endif
}

init3()
{
  init2(); 

  load_text_file("dat/inv_op.dat", inv_op, CUBE_SYM, CHAR);
  load_text_file("dat/op_op.dat", op_op, CUBE_SYM*CUBE_SYM, CHAR);
  load_text_file("dat/ep_min_op.dat", ep_min_op, E_PRM, CHAR);
  load_text_file("dat/ep_min.dat", ep_min, E_PRM, INT);
  load_text_file("dat/cpt_min.dat", cpt_min, C_PRM_TW, SHORT);
  load_text_file("dat/cpt_min_op.dat", cpt_min_op, C_PRM_TW, CHAR);
  load_text_file("dat/cp6c_min_op.dat", cp6c_min_op, C_PERM, CHAR);
  load_text_file("dat/cp6c_min.dat", cp6c_min, C_PERM, INT);

  #if USE_ET_SYM
  load_bin_file("dat/et_sym.dat", et_sym, CUBE_SYM*E_TWIST, SHORT);
  #endif

  #if USE_ET_SYM_FR
  load_bin_file("dat/et_sym_fr.dat", et_sym_FR, SLICE_PRM*E_TWIST, SHORT);
  #endif

  #if USE_ET_SYM_UF
  load_bin_file("dat/et_sym_uf.dat", et_sym_UF, SLICE_PRM*E_TWIST, SHORT);
  #endif

  #if USE_ET_FR
  load_bin_file("dat/et_fr.dat", et_fr, N_ET_FR*128, CHAR);
  #endif

  #if (ET_SYM_METHOD == 3 || ET_SYM_METHOD == 4)
  load_bin_file("dat/et_fr_ix.dat", et_fr_ix, SLICE_PRM*16, ETIX_TYPE);
  #endif

  #if (ET_SYM_METHOD == 5)
  load_bin_file("dat/et_fr_ixb.dat", et_fr_ixb, SLICE_PRM*16, SHORT);
  load_bin_file("dat/et_fr_ixv.dat", et_fr_ixv, SLICE_PRM*16, CHAR);
  #endif

  #if USE_ET_UF
  load_bin_file("dat/et_uf.dat", et_uf, N_ET_UF*64, SHORT);
  #endif

  #if (ET_SYM_METHOD == 3)
  load_bin_file("dat/et_uf_ix.dat", et_uf_ix, SLICE_PRM*32, ETIX_TYPE);
  #endif

  #if (ET_SYM_METHOD == 5)
  load_bin_file("dat/et_uf_ixb.dat", et_uf_ixb, SLICE_PRM*32, SHORT);
  load_bin_file("dat/et_uf_ixv.dat", et_uf_ixv, SLICE_PRM*32, CHAR);
  #endif

  #if (USE_ET_SYM16)
    load_bin_file("dat/et_sym16.dat", et_sym16, E_TWIST*16, SHORT);
  #endif

  #if (USE_ET_SYM32)
    load_bin_file("dat/et_sym32.dat", et_sym32, E_TWIST*32, SHORT);
  #endif

  #if USE_CPT_SYM
  load_bin_file("dat/cpt_sym.dat", cpt_sym, MIN_CPT*CUBE_SYM, INT);
  #endif

  populate_min_ep();   // requires ep_min_op

  if (QTM)
    load_text_file("dat/op_qmv.dat", op_mv, CUBE_SYM*MOVES, CHAR);
  else
    load_text_file("dat/op_fmv.dat", op_mv, CUBE_SYM*MOVES, CHAR);

  populated("op_mv");

  #if USE_CPT_MOV
  populate_cpt_mov();
  #endif

  init_op16e();      

  if (ET_SYM_METHOD == 1)
    update_et_sym_m1();
  else
    update_op16e();

  #if USE_EPT_MIN_OP
  load_text_file("dat/ept_op_idx.dat", ept_op_idx, E_PRM, INT);
  load_bin_file("dat/ept_min_op.dat", ept_min_op, N_EPT_MIN_OP*E_TWIST, CHAR);
  #endif

  #if USE_EPT_MIN_OP2
  load_bin_file("dat/ept_min_op2.dat", ept_min_op2, 57*E_TWIST, CHAR);
  load_bin_file("dat/ept_op_ix2.dat", ept_op_ix2, MIN_EP, CHAR);
  #endif

  load_ept_min_ops();  
  populate_ept_ops_indexes();
  populate_ep_info();

  #if USE_EPR_SYM2
  load_bin_file("dat/epr_sym2.dat", epr_sym2, N_EPR_SYM2*24, CHAR);
  load_bin_file("dat/epr_idx.dat", epr_idx, 3*CUBE_SYM*SLICE_PRM, CHAR);
  populated("epr_sym2");
  #else
  load_bin_file("dat/epr_sym.dat", epr_sym, 3*CUBE_SYM*SLICE_PRM*24, CHAR);
  #endif

  #if USE_CP_SYM
  load_bin_file("dat/cp_sym.dat", cp_sym, C_PRM*CUBE_SYM, CHAR);
  #endif

  #if USE_CT_SYM
  load_bin_file("dat/ct_sym.dat", ct_sym, C_PRM*C_TWIST*CUBE_SYM, SHORT);
  #endif

  #if USE_EP_SYM
  load_bin_file("dat/ep_sym.dat", ep_sym, E_PRM*CUBE_SYM, SHORT);
  #endif
  
  #if USE_EP_MOV2
  populate_ep_mov2();
  load_bin_file("dat/ep_sym2.dat", ep_sym2, MIN_EP*CUBE_SYM, SHORT);
  #endif

  #if USE_CP6C_MOV2
  populate_cp6c_mov2();
  #endif

  #if USE_CP6C_SYM2
  load_bin_file("dat/cp6c_sym2.dat", cp6c_sym2, MIN_CP6C*CUBE_SYM, SHORT);
  #endif

  #if USE_OP16C
  init_op16c();
  #endif

  #if USE_CT_SYM_UF
  load_bin_file("dat/ct_sym_uf.dat", ct_sym_uf, C_PRM*C_TWIST, SHORT);
  load_bin_file("dat/ct_sym_ur.dat", ct_sym_ur, C_PRM*C_TWIST, SHORT);
  #endif

  #if USE_CT_UF
  load_bin_file("dat/ct_uf.dat", ct_uf, N_CT_IX3*81, CHAR);
  load_bin_file("dat/ct_uf_ix.dat", ct_uf_ix, C_PRM*27, INT);
  #endif

  #if USE_CT_UR
  load_bin_file("dat/ct_ur.dat", ct_ur, N_CT_IX3*81, CHAR);
  load_bin_file("dat/ct_ur_ix.dat", ct_ur_ix, C_PRM*27, INT);
  #endif

  #if USE_CT_SYM3
  load_bin_file("dat/ct_sym3.dat", ct_sym3, C_TWIST*16, SHORT);
  #endif

  #if USE_CPT_SYM
  load_bin_file("dat/cpt_sym.dat", cpt_sym, MIN_CPT*CUBE_SYM, INT);
  #endif

  #if USE_CPT_SYM2
  load_bin_file("dat/cpt_sym2.dat", cpt_sym2, MIN_CPT*CUBE_SYM, SHORT);
  #endif

  #if USE_CP6C_MOV
  populate_cp6c_mov();
  #endif

  #if USE_CP6C_INFO
    populate_cp6c_info();
  #endif
}

#if USE_CP6C_MOV
populate_cp6c_mov()
{
  int i, j, k;

  char s[8], tmp[8];

  for (i=0; i < C_PERM; i++)
    {
      int_to_perm(i, s, 8);

      for (j=0; j < 8; j++) 
	tmp[j] = s[j]/4;

      cp6c_cp3c[i] = b2_cp[str_to_int(tmp,7,2)];

      for (j=0; j < MOVES; j++)
	{
	  for (k=0; k < 8; k++) 
	    tmp[k] = s[cmv[j][k]]; 

	  cp6c_mov[i][j] = perm_to_int(tmp, 8);
	}
    }
  populated("cp6c_mov");
}
#endif

#if USE_EP_MOV2
populate_ep_mov2()
{
  int i, j, k, ep, epm;
  char s[12], tmp[12];

  populate_min_ep();

  for (i=0; i < MIN_EP; i++)
    {
      ep = min_ep[i];
      int_to_strp(ep_b3[ep], s, 11, 3);

      for (j=0; j < MOVES; j++)
	{
	  for (k=0; k < 12; k++) 
	    tmp[k] = s[emv[j][k]]; 

	  epm = b3_ep[str_to_int(tmp,11,3)];
	  ep_mov2[i][j].min = ep_min[epm];
	  ep_mov2[i][j].op = inv_op[ep_min_op[epm]];
	}		
    }
  populated("ep_mov2");
}
#endif

#if USE_CP6C_MOV2
populate_cp6c_mov2()
{
  int i, j, k, cp6c, cp6cm;
  char s[8], tmp[8];

  populate_min_cp6c();

  dependency("min_cp6c", "populate_cp6c_mov2");
  dependency("cp6c_min", "populate_cp6c_mov2");
  dependency("cp6c_min_op", "populate_cp6c_mov2");
  dependency("inv_op", "populate_cp6c_mov2");

  for (i=0; i < MIN_CP6C; i++)
    {
      int_to_perm(min_cp6c[i], s, 8);
      
      for (j=0; j < MOVES; j++)
	{
	  for (k=0; k < 8; k++) 
	    tmp[k] = s[cmv[j][k]]; 

	  cp6cm = perm_to_int(tmp, 8);
	  cp6c_mov2[i][j].min = cp6c_min[cp6cm];
	  cp6c_mov2[i][j].op = inv_op[cp6c_min_op[cp6cm]];
	}		
    }
  populated("cp6c_mov2");
}

populate_min_cp6c()
{
  int i, n;

  dependency("cp6c_min_op", "populate_min_cp6c");

  for (i=n=0;  n < C_PERM; n++)
    if (cp6c_min_op[n] == 0)
      min_cp6c[i++] = n;

  populated("min_cp6c");
}
#endif

populate_ep_info()
{
  int i;

  dependency("ep_slice", "populate_ep_info");

  if (EP_SYM_METHOD == 1)
    {
      dependency("ep_min", "populate_ep_info");
      dependency("ep_min_op", "populate_ep_info");
    }

  if (EPT_OP_METHOD == 1)
    dependency("ept_op_idx", "populate_ep_info");

  if (EPT_OP_METHOD == 2)
    dependency("ept_op_ix2", "populate_ep_info");

  for (i=0; i < E_PRM; i++)
    {
      #if (EP_SYM_METHOD == 1)
      #if (EPT_OP_METHOD == 1)
      ep_info[i].op_ix = ept_op_idx[i];
      #elif (EPT_OP_METHOD == 2)
      ep_info[i].op_ix = ept_op_ix2[ep_min[i]];
      #endif
      ep_info[i].op = ep_min_op[i];
      ep_info[i].min  = ep_min[i];
      #endif

      ep_info[i].s0 = ep_slice[i][0];
      ep_info[i].s1 = ep_slice[i][1];
      ep_info[i].s2 = ep_slice[i][2];
    }

  populated("ep_info");
}

#if USE_CPT_MOV
populate_cpt_mov()
{
  int cp, ct, i, j, cpm, ctm, cptm, idx;
  char cps[8], cts[8], tmp[8];

  for (cp=0; cp < C_PRM; cp++)
    {
      int_to_strp(cp_b2[cp], cps, 7, 2);

      for (ct=0; ct < C_TWIST; ct++)
	{
	  idx = cp*C_TWIST + ct;

	  if (cpt_min_op[idx] != 0)
	    continue;

	  int_to_strp(ct, cts, 7, 3);

	  for (i=0; i < MOVES; i++)
	    {
	      for (j=0; j < 8; j++)
		tmp[j] = cps[cmv[i][j]];

	      cpm = b2_cp[str_to_int(tmp,7,2)];

	      for (j=0; j < 8; j++)
		tmp[j] = cts[cmv[i][j]];

	      if (ctw[i]) 
		ctw[i](tmp);

	      ctm = str_to_int(tmp,7,3);
	      cptm = cpm*C_TWIST + ctm;
	      cpt_mov[cpt_min[idx]][i].min = cpt_min[cptm]; 
	      cpt_mov[cpt_min[idx]][i].op= inv_op[cpt_min_op[cptm]]; 
	    }
	}
    }

  populated("cpt_mov");
}
#endif

init_seq()
{
  int i;

  mvlist1[0] = 0;

  if (QTM)
    mvlist1[1] = NIL;
  else
  {
    mvlist1[1] = 1;
    mvlist1[2] = NIL;
  } 

  for (i=0; i < MOVES; i++)
    mvlist2[i] = i;

  mvlist2[i] = NIL;
  
  if (QTM)
    {
      init_seq_gen(4,2);
      init_seq_gen2(4,2);
    }
  else
    init_seq_gen(6,3);
}

init_seq_gen(x, y)
     int x, y;
{
  int i, j, k;

  for (i=0; i < MOVES; i++)
    {
      for (j=k=0; j < i/x*x; j++)
	seq_gen[i][k++] = j;
      
      for (j=i/y*y+y; j < MOVES; j++)
	seq_gen[i][k++] = j;

      seq_gen[i][k] = NIL;
    }
}
 
init_seq_gen2(x, y)
     int x, y;
{
  int i, j, k;

  for (i=0; i < MOVES; i+=2)
    {
      for (j=k=0; j < i/x*x; j++)
	seq_gen2[i][k++] = j;

      for (j=i/y*y; j < MOVES; j++)
	{
	  seq_gen2[i][k] = j;

	  if (seq_gen2[i][k++] == i)
	    j++;
	}

      seq_gen2[i][k] = NIL;
    }
}

cbtw(s)		// corner back twist
     char *s;
{
  s[7] = cw[s[7]];	
  s[2] = ccw[s[2]];
  s[6] = cw[s[6]];	
  s[3] = ccw[s[3]];
}

cltw(s)		// corner left twist
     char *s;
{
  s[2] = cw[s[2]];	
  s[4] = ccw[s[4]];
  s[0] = cw[s[0]];	
  s[6] = ccw[s[6]];
}

crtw(s)		// corner right twist
     char *s;
{
  s[1] = cw[s[1]];	
  s[7] = ccw[s[7]]; 
  s[3] = cw[s[3]];	
  s[5] = ccw[s[5]]; 
}

cftw(s)		// corner front twist
     char *s;
{
  s[4] = cw[s[4]];	
  s[1] = ccw[s[1]];
  s[5] = cw[s[5]];	
  s[0] = ccw[s[0]];
}

ebtw(s)		// edge back twist
     char *s;
{
  s[3] = flip[s[3]];	
  s[6] = flip[s[6]];
  s[2] = flip[s[2]];	
  s[7] = flip[s[7]];
}

eftw(s)		// edge front twist
     char *s;
{
  s[0] = flip[s[0]]; 	
  s[5] = flip[s[5]];
  s[1] = flip[s[1]]; 	
  s[4] = flip[s[4]];
}

set_indexes()
{
  /*         00 01 02
             03 04 05
             06 07 08
    09 10 11 12 13 14 15 16 17 18 19 20
    21 22 23 24 25 26 27 28 29 30 31 32
    33 34 35 36 37 38 39 40 41 42 43 44
             45 46 47
             48 49 50
             51 52 53
  */

  char center_idx_init[6]={4,22,25,28,31,49};

  char 	corner_idx_init[8][3] =
    {
       6, 12, 11, 
      47, 38, 39, 
      51, 44, 33,  
       2, 18, 17,
      45, 35, 36,  
       8, 15, 14,  
       0,  9, 20, 
      53, 41, 42
    };

  char 	edge_idx_init[12][2] =
    { 
      24, 23,
      26, 27,
      30, 29,
      32, 21,
       7, 13,
      46, 37,
      52, 43,
       1, 19,
       3, 10,
       5, 16,
      50, 40,
      48, 34 
    };

  int i, j;

  for (i=0; i < 6; i++)
    center_idx[i] = center_idx_init[i];

  for (i=0; i < 8; i++)
    for (j=0; j < 3; j++)
      cnr_idx[i][j] = corner_idx_init[i][j];

  for (i=0; i < 12; i++)
    for (j=0; j < 2; j++)
      edg_idx[i][j] = edge_idx_init[i][j];
}

set_colors_6c(r, f, u, l, b, d)
     char r, f, u, l, b, d;
{
  int i, j;

  /*
    Corners:	
    --------------------------------------
    Front   Back (looking thru cube)
    0 5     6 3
    4 1     2 7
    --------------------------------------
    1st digit = position
    2nd digit = twist (1 = clockwise, 2 = counter-clockwise)
            60  30   
            00  50   
    61  02  01  52  51  32  31  62 
    22  41  42  11  12  71  72  21
            40  10 
            20  70 
  */

  char *cnr_loc[8][3] = 
    {
      &u, &f, &l, 
      &d, &f, &r, 
      &d, &b, &l, 
      &u, &b, &r,
      &d, &l, &f, 
      &u, &r, &f, 
      &u, &l, &b, 
      &d, &r, &b
    };

  /*
    Edges:
    --------------------------------------
    Front      Middle      Back
      4        8   9         7   
    0   1                  3   2
      5        B   A         6
    --------------------------------------

    1st digit = position
    2nd digit = twist (0 = sane, 1 = flipped)
             70
           80  90
             40
      81     41     91     71
    31  01 00  10 11  21 20  30
      B1     51     A1     61
             50
           B0  A0
             60
  */

  char *edg_loc[12][2] = 
    {
      &f, &l,
      &f, &r,
      &b, &r,
      &b, &l,
      &u, &f,
      &d, &f,
      &d, &b,
      &u, &b,
      &u, &l,
      &u, &r,
      &d, &r,
      &d, &l
    };    

  for (i=0; i < 8; i++)
    for (j=0; j < 3; j++)
      cnr[i][j] = *cnr_loc[i][j];

  for (i=0; i < 12; i++)
    for (j=0; j < 2; j++)
      edg[i][j] = *edg_loc[i][j];
}

convert_cnr_6c(s, cps, cts)
     char *s, *cps, *cts;
{
  int  i, x, y, z;
  char L, D, B, R, U, F;

  L = s[22];    D = s[49];    B = s[31];
  R = s[28];    U = s[4];     F = s[25];

  set_colors_6c(R, F, U, L, B, D);

  for (i=0; i < 8; i++)
    {
      x = s[cnr_idx[i][0]];
      y = s[cnr_idx[i][1]];
      z = s[cnr_idx[i][2]];

      if (x == U || x == D)
	{
	  cts[i] = 0;               // no twist
	  cps[i] = get_cps(x,y,z);
	}
      else if (y == U || y == D) 
	{
	  cts[i] = 1;	            // 1/3 clockwise twist
	  cps[i] = get_cps(y,z,x);
	}
      else 
	{
	  cts[i] = 2;	            // 1/3 counter-clockwise twist
	  cps[i] = get_cps(z,x,y);
	}
    }
  return(perm_to_int(cps,8));
}

get_cps(a, b, c)
     char a, b, c;
{
  int i;

  for (i=0; i < 8; i++)
    if ((cnr[i][0] == a) && (cnr[i][1] == b) && (cnr[i][2] == c))
      return(i);
}	

convert_edg_6c(s, eps, ets)
     char *s, *eps, *ets;
{	
  int i, x, y;
  char L, D, B, R, U, F;

  L = s[22];    D = s[49];    B = s[31];
  R = s[28];    U = s[4];     F = s[25];

  set_colors_6c(R, F, U, L, B, D);

  for (i=0; i < 12; i++)
    {
      x = s[edg_idx[i][0]];
      y = s[edg_idx[i][1]];

      if ((x == U || x == D) || 
	  ((x == F || x == B) && (y == L || y == R))) 
	{
	  ets[i] = 0;
	  eps[i] = get_eps(x, y);
	}
      else 
	{
	  ets[i] = 1;
	  eps[i] = get_eps(y, x);
	}
    }
}

get_eps(a, b)
     char a, b;
{
  int i; 

  for (i=0; i < 12; i++)
    if ((edg[i][0] == a) && (edg[i][1] == b))
      return(i);
}	

populate_cp6c_cpr()
{
  char s[8], t1[8], t2[8];
  int i, j, x1, x2;

  for (i=0; i < C_PERM; i++)
    {
      int_to_perm(i, s, 8);

      for (j=x1=x2=0; j < 8; j++)
	if (s[j]/4 == 0)
	  t1[x1++] = s[j];
	else
	  t2[x2++] = s[j]-4;

      cp6c_cpr[i] = perm_to_int(t1,4)*24 + perm_to_int(t2,4);
    }
  populated("cp6c_cpr");
}

ep6c_epr(s, epr)
     char *s, *epr;
{
  char t0[4], t1[4], t2[4];
  int i, x0, x1, x2;

  /* example:

       ep6c: 3768B9042A15
       ep3c: 011222010201
             ------------
     epr[0]: 3     0 2 1   3021 -> 19
     epr[1]:  32    0   1  3201 -> 22
     epr[2]:    031   2    0312 ->  4
 */

  for (i=x0=x1=x2=0; i < 12; i++)
    if (s[i]>>2 == 0)
      t0[x0++] = s[i];
    else if (s[i]>>2 == 1)
      t1[x1++] = s[i]-4;
    else 
      t2[x2++] = s[i]-8;		
  
  epr[0] = perm_to_int(t0, 4);
  epr[1] = perm_to_int(t1, 4);
  epr[2] = perm_to_int(t2, 4);
}

show_dist_counts(dist, n, min)
     unsigned char *dist;
     int n, min;
{
  int i, count[20], cumulative[20], total=1;

  dist[0] = 0;

  for (i=0; i < 20; i++) 	
    count[i] = 0;

  for (i=0; i < n; i++) 	
    count[dist[i]]++;

  for (i=1; i < 20; i++)	
    {
      total += count[i];
      cumulative[i] = total;
    }

  for (i=min; i < 20; i++)
    if (count[i] != 0) 
      show_dist_count_line(i, count[i]);

  fflush(stdout);
}

show_dist_count_line(mv, count)
     int mv, count;
{
  printf("%5d    %9d\n", mv, count);
  fflush(stdout);
}

copy(dst, src, n)
     char *dst, *src;
     int n;
{	
  int i;
  for(i=0; i < n; i++)
    dst[i] = src[i] - ((src[i] > '9') ? 55 : 48);
}

load_dist_file(fname, arr, n)
     char *fname;
     unsigned char *arr;
     int n;
{	
  int ret;
	    
  printf("Loading %s: ", (char*)fname+4); 
  printf("%3.0f MB\n", (float)n/MEG); 
  fflush(stdout);
  ret = load_bin_file(fname, arr, n, CHAR);
  fflush(stdout);
  return(ret);
}

parity(s, len)
     char *s, len;
{
  int i, n;
  char x, tmp[12];

  for (i = 0; i < len; i++) 
    tmp[i] = s[i];

  for (i=n=0; i < len; i++)
    while (tmp[i] != i)
      {	
	x = tmp[i];
	tmp[i] = tmp[x];
	tmp[x] = x;
	n++;
      }

  return(n%2);
}

load_ept_min_ops()
{	
  int i, j, n, ix;

  open_file("dat/ept_min_ops.dat", "r");  // assigns fp

  for (i=ix=0; i < N_EPT_MIN_OPS; i++)
    {
      for (j=0; j < 3; j++)
	fscanf(fp, "%d", &ept_min_ops[i][j]);

      n = ept_min_ops[i][2];
      n = (n == CUBE_SYM-1) ? 0 : n+3;

      for (j=3; j < n; j++)
	fscanf(fp, "%2d ", &ept_min_ops[i][j]);
    }

  fclose(fp);
  populated("ept_min_ops");
}

populate_ept_ops_indexes()
{
  int i, j, ep, ix;

  dependency("ept_min_ops", "populate_ept_ops_indexes");

  for (i=0; i < MIN_EP; i++)
    ept_ops_ix1[i] = NIL;

  for (i=0; i < N_EPT_OPS_IX2; i++)
    for (j=0; j < E_TWIST; j++)
      // op_info[i][j].idx = NIL;
      ept_ops_ix2[i][j] = NIL;

  for (i=ix=0; i < N_EPT_MIN_OPS; i++)
    {
      ep = ep_min[ept_min_ops[i][0]];

      if (ept_ops_ix1[ep] == NIL)
	ept_ops_ix1[ep] = ix++;

      // op_info[ix-1][ept_min_ops[i][1]].idx = i;
      ept_ops_ix2[ix-1][ept_min_ops[i][1]] = i;
    }

  populated("op_info");
  populated("ept_ops_ix1");
  populated("ept_ops_ix2");
}

chk_dup_3c(ep, et, cp, ct, n)
     int ep, et, cp, ct, n;
{	
  int i, ept, cpt;
  static int cfg[CFG_LIST_3C][3];

  ept = ep*E_TWIST + et;
  cpt = cp*C_TWIST + ct;

  for (i=0; i < cfg_idx; i++)
    if (cfg[i][0] == ept && cfg[i][1] == cpt && cfg[i][2] <= n)
      return(1);

  if (cfg_idx >= CFG_LIST_3C)
    {
      printf("ERROR: Max size exceeded in chk_dup_3c()\n");
      fflush(stdout);
      exit(1);
    }

  cfg[cfg_idx][0] = ept;
  cfg[cfg_idx][1] = cpt;
  cfg[cfg_idx++][2] = n;

  return(0);
}

get_file_size(file)
     char *file ;
{
  struct stat statbuf[1] ;
  int size = 0 ;

  if (stat(file, statbuf) != 0)
    size = -1 ;
  else
    size = statbuf->st_size ;

  return( size ) ;
}

show_distq_counts(dist, n, max_depth)
     unsigned char *dist;
     int n, max_depth;
{	
  int i, j, ct[20];

  for (i=0; i < 20; i++)
    ct[i] = 0;

  for (i=0; i < n; i++)
    for (j=0; j < 8; j+=2)
      ct[(dist[i]>>j)&3]++; 

  for (i=0; i < 4; i++)
    printf("%5d   %10d\n", i+max_depth-2, ct[i]);

  fflush(stdout);
}

get_distb_count(dist, n)
     unsigned char *dist;
     int n;
{
  unsigned int count, i, j, k;
  unsigned char bits[256];

  for (i=0; i < 256; i++)
    for (j=0, k=1, bits[i]=0; j < 8; j++, k*=2)
      if (i & k) bits[i]++;

  for (i=count=0; i < n; i++)
    count += bits[dist[i]];
  return(count);
}

init_op16e()
{
  int i, j, op1, op2;

  // symmetry operations that maintain consistent edge twist values 
  // for all edge position values

  char op_ud[16] = {0,5,6,7,8,21,22,23,24,29,30,31,32,45,46,47};

  /* for the symmetry operations that are not consistent, make the equivalent
     from a pair of operations using one of either UF or FR and one of the 16 
     consistent symmetries
  */

  for (i=0; i < 2; i++)
    {
      op1 = (i) ? OP_UF : OP_FR;

      for (j=0; j < 16; j++)
	{
	  op2 = op_ud[j];
	  op16e[op_op[op1][op2]].op1 = op1;
	  op16e[op_op[op1][op2]].op2 = op2;
	}
    }
  populated("op16e");
}

update_op16e()
{
  int i, j, op1, op2;

  char op_ud[16] = { 0, 5, 6, 7, 8,21,22,23,24,29,30,31,32,45,46,47};
  char op_fb[16] = {13,14,15,16,17,18,19,20,37,38,39,40,41,42,43,44};

  //  This updates op16e so that the 16 consistent sym ops point
  //  to the first 16 rows of et_sym

  for (i=0; i < 48; i++)
    op_new[i] = 0;

  for (i=j=0; i < 16; i++)
    op_new[op_ud[i]] = j++;

  for (i=0; i < CUBE_SYM; i++)
    {
      if (op16e[i].op1 == 0)
	op16e[i].op2 = op_new[i];
      else
	op16e[i].op2 = op_new[op16e[i].op2];
    }

  //  This updates op16e so that the slice 2 sym ops point to the second 
  //  16 rows of et_sym

  #if USE_ET_SYM32
  for (i=0; i < 48; i++)
    op_new[i] = 0;

  for (i=0, j=16; i < 16; i++)
    op_new[op_fb[i]] = j++;

  for (i=0; i < CUBE_SYM; i++)
    {
      if (op16e[i].op1 == OP_UF)
	op16e[i].op2 = op_new[i];
    }
  #endif
}

populate_b2_slice()
{
  int c, i, j, k;
  char s[12];

  for (i=k=0; i < 4096; i++)
    {
      int_to_str(i, s, 12, 2);

      for (c=j=0; j < 12; j++)
	if (s[j] == 1)
	  c++;

      if (c == 4)
        b2_slice[i] = k++;

    }
}

populate_ep_slice()
{
  int i, j, k;
  char s[12], t[12];

  for (i=0; i < E_PRM; i++)
    {
      int_to_strp(ep_b3[i], s, 11, 3);

      for (j=0; j < 3; j++)
	{
	  for (k=0; k < 12; k++)
	    t[k] = (s[k] == j) ? 1 : 0;

	  ep_slice[i][j] = b2_slice[str_to_int(t, 12, 2)];
	}
    }
  populated("ep_slice");
}

init_slice_map()  // see slice_map.c
{
  int i, j;
  char slice_map_init[CUBE_SYM][3] =    // 0=UD, 1=LR, 2=FB
    {
      0,1,2,0,2,1,1,2,0,0,2,1,1,2,0,0,1,2,1,0,2,0,1,2,
      1,0,2,0,2,1,1,2,0,0,2,1,1,2,0,2,1,0,2,0,1,2,1,0,
      2,0,1,2,1,0,2,0,1,2,1,0,2,0,1,1,0,2,0,1,2,1,0,2,
      0,1,2,0,2,1,1,2,0,0,2,1,1,2,0,0,1,2,1,0,2,0,1,2,
      1,0,2,0,2,1,1,2,0,0,2,1,1,2,0,2,1,0,2,0,1,2,1,0,
      2,0,1,2,1,0,2,0,1,2,1,0,2,0,1,1,0,2,0,1,2,1,0,2
    };
  for (i=0; i < CUBE_SYM; i++)
    for (j=0; j < 3; j++)
      slice_map[i][j] = slice_map_init[i][j];
}

ep6c_ep3c(s)
     char *s;
{
  int i;
  char tmp[12];

  for (i=0; i < 12; i++)
    tmp[i] = s[i]/4;

  return(b3_ep[str_to_int(tmp,11,3)]);
}

populate_slice_ep()
{
  int c, i, j, ix;
  char a[12], b[12];

  for (i=ix=0; i < 4096; i++)
    {
      int_to_str(i, a, 12, 2);
 
      for (c=j=0; j < 12; j++)
        if (a[j] == 1)
          c++;
 
      if (c == 4)
        {
          memcpy(b, a, 12);
 
          for (j=0; j < 12; j++)
            b[j] = b[j] ? 0 : 1;
           
          for (c=j=0; j < 12; j++)
            if (b[j] == 1 && c++ >= 4)
              b[j] = 2;
               
          slice_ep[ix][0] = b3_ep[str_to_int(b,11,3)];
          memcpy(b, a, 12);
 
          for (c=j=0; j < 12; j++)
            if (b[j] == 0 && c++ >= 4)
              b[j] = 2;
               
          slice_ep[ix][1] = b3_ep[str_to_int(b,11,3)];
          memcpy(b, a, 12);
 
          for (j=0; j < 12; j++)
            if (b[j])
              b[j] = 2;

          for (c=j=0; j < 12; j++)
            if (b[j] == 0 && c++ >= 4)
              b[j] = 1;
 
          slice_ep[ix++][2] = b3_ep[str_to_int(b,11,3)];
        }
    }
}

mk_eps_6c(eps_6c, eps_3c, s)
     char *eps_6c, *eps_3c, *s;
{
  int i, x, y, z;

  for (i=x=0, y=4, z=8; i < 12; i++)
    {
      if (eps_3c[i] == 0)
	eps_6c[i] = s[x++];
      
      else if (eps_3c[i] == 1)
	eps_6c[i] = s[y++] + 4;
      
      else if (eps_3c[i] == 2)
	eps_6c[i] = s[z++] + 8;
    }
}

mk_hexd_arr(arr, n)
     unsigned char *arr;
     int n;
{
  int i;

  for (i=0; i < n; i+=2)
    arr[i/2] = arr[i+1]*16 + arr[i];
}

check_gen_depth(n, use_dist, dist_depth)
     int n;
     char *use_dist, *dist_depth;
{
  if (use_dist[n])
    if (dist_depth[n] < 1 || dist_depth[n] > 15)
      {
	printf("ERROR: Invalid D%d_GEN_DEPTH: %d, range is 1-15\n", 
	       n, dist_depth[n]);
	return(1);
      }
  return(0);
}

make_cubestr(cubestr, cube)
     char *cubestr;
     struct s_cube *cube;
{
  int i, j;

  for  (i=0; i < 12; i++)
    for (j=0; j < 2; j++)
      cubestr[edg_idx[i][j]] = edg[cube->eps[i]][(cube->ets[i]+j)%2];

  for  (i=0; i < 8; i++)
    for (j=0; j < 3; j++)
      cubestr[cnr_idx[i][j]] = cnr[cube->cps[i]][(untwc[cube->cts[i]]+j)%3];
}

eps_to_ep3c(s)
     char *s;
{	
  int i;
  char tmp[12];

  for (i=0; i < 12; i++) 
    tmp[i] = s[i]/4;

  return(b3_ep[str_to_int(tmp,11,3)]);
}

verify_cubestr(s, cube)     // return codes: 0=ok  1=home  >1=error
     char *s;
     struct s_cube *cube;
{
  char check[12];
  int  i, pos, tw;

  set_indexes();
  convert_cnr_6c(s, cube->cps, cube->cts);
  convert_edg_6c(s, cube->eps, cube->ets);

  for (i=0; i < 8; i++)
    check[i] = 0;

  for (i=tw=0; i < 8; i++)
    {	 
      check[cube->cps[i]] = 1;
      tw += cube->cts[i];
    }
  for (i=pos=0; i < 8; i++)
    pos += check[i];

  if (pos != 8 || tw%3 != 0)
    return(INV_CUBE_CORNER);

  for (i=0; i < 12; i++)
    check[i] = 0;

  for (i=tw=0; i < 12; i++)
    {
      check[cube->eps[i]] = 1;
      tw += cube->ets[i];
    }
  for (i=pos=0; i < 12; i++)
    pos += check[i];

  if (pos != 12 || tw%2 != 0)
      return(INV_CUBE_EDGE);

  if (parity(cube->eps, 12) != parity(cube->cps, 8))
      return(INV_CUBE_PARITY);

  if (perm_to_int(cube->cps,8)  == 0 && str_to_int(cube->cts,7,3) == 0 &&
      perm_to_int(cube->eps,12) == 0 && str_to_int(cube->ets,11,2) == 0)
    return(HOME_CUBE);

  return(0);
}

cube_status_msg(n)
{
  if (n == HOME_CUBE)
    printf("No Moves Required\n");

  if (n == INV_CUBE_CORNER)
    printf("ERROR: Invalid Corner Configuration\n");

  if (n == INV_CUBE_EDGE)
    printf("ERROR: Invalid Edge Configuration\n");

  if (n == INV_CUBE_PARITY)
    printf("ERROR: Invalid Configuration (Parity)\n");
}

make_eps(eps, ep, epr)
     char *eps, *epr;
     int ep;
{
  int i, n;
  char eps_3c[12], eps_3r[12], ix[3];

  for (i=0; i < 3; i++)
    ix[i] = 0;

  int_to_strp(ep_b3[ep], eps_3c, 11, 3);

  for (i=0; i < 3; i++)
    int_to_perm(epr[i], &eps_3r[i*4], 4);
  
  for (i=0; i < 12; i++, ix[n]++)
    {
      n = eps_3c[i];
      eps[i] = n*4 + eps_3r[n*4+ix[n]];
    }
}

show_cube(centers, ep, epr, et, cp6c, ct)
     char *centers, *epr;
     int ep, et, cp6c, ct;
{
  int i;
  struct s_cube cube;
  char cubestr[FACELETS];

  for (i=0; i < 6; i++)
    cubestr[center_idx[i]] = centers[i];

  int_to_strp(ep_b3[ep], cube.ep, 11, 3);
  int_to_strp(et, cube.ets, 11, 2);
  int_to_perm(cp6c, cube.cps, 8);
  int_to_strp(ct, cube.cts, 7, 3);

  make_eps(cube.eps, 0, epr);

  make_cubestr(cubestr, &cube);
  show_cubestr(cubestr, 0);
}

show_cubestr(s, f)
     char *s, f;
{	
  int i, j;

  if (f)
    {
      for (i=0; i < FACELETS; i++)
	printf("%c", s[i]);
      
      printf("\n");
      return;
    }

  for (i=0; i < 9; i+=3)
    printf("    %c%c%c\n",   s[i], s[i+1], s[i+2]);

  for (; i < 45; i+=12)
    {
      for (j=0;  j < 12; j+=3)
	printf("%c%c%c ", s[i+j], s[i+j+1], s[i+j+2]);
      printf("\n");
    }

  for (; i < 54; i+=3)
    printf("    %c%c%c\n",   s[i], s[i+1], s[i+2]);

  printf("\n");
}

populate_min_ep()
{
  int i, ep;

  for (ep=i=0; ep < E_PRM; ep++)
    if (ep_min_op[ep] == 0)
      min_ep[i++] = ep;

  populated("min_ep");
}

#if (ET_SYM_METHOD == 1)
update_et_sym_m1()
{
  /* 
     This updates et_sym[] so that op16e[op].op2 can be replaced by just op,
     etsym can be obtained like this:

     if (op16e[op].op1 == 0)
       etsym = et_sym[et][op];
     else			      
        etsym = (op16e[op].op1 == OP_FR) ?
          et_sym[et_sym_FR[epi->s0][et]][op]:
          et_sym[et_sym_UF[epi->s1][et]][op];

     as opposed to this:

     if (op16e[op].op1 == 0)
       etsym = et_sym[et][op];
     else
       etsym = (op16e[op].op1 == OP_FR) ?
         et_sym[et_sym_FR[epi->s0][et]][op16e[op].op2]:
         et_sym[et_sym_UF[epi->s1][et]][op16e[op].op2];
  */

  int i, j, op, et_fr, et_uf;
  char op_lr[16] = { 1, 2, 3, 4, 9,10,11,12,25,26,27,28,33,34,35,36};
  char op_fb[16] = {13,14,15,16,17,18,19,20,37,38,39,40,41,42,43,44};

  for (i=0; i < 16; i++)
    {
      op = op_lr[i];

      for (j=0; j < E_TWIST; j++)
	et_sym[j][op] = et_sym[j][op16e[op].op2];
    }

  for (i=0; i < 16; i++)
    {
      op = op_fb[i];

      for (j=0; j < E_TWIST; j++)
        et_sym[j][op] = et_sym[j][op16e[op].op2];
    }
}
#endif

get_epr_mv(epr_mv, ep, epr, mv)
     int ep, mv;
     char *epr_mv, *epr;
{
  int i, idx;

  for (i=0; i < 3; i++)
    {
      #if USE_EPR_MOV2
        idx = epr_mov_idx[ep_slice[ep][i]][mv];
	epr_mv[i] = epr_mov2[idx][epr[i]];
      #else
	epr_mv[i] = epr_mov[ep_slice[ep][i]][epr[i]][mv];
      #endif
    }
}

get_eprsym(eprsym, ep, epr, op)
     char *eprsym, *epr;
     int ep, op;
{
  int i;

  for (i=0; i < 3; i++)
    {
      eprsym[slice_map[op][i]] =
        #if USE_EPR_SYM2
        epr_sym2[epr_idx[op][ep_slice[ep][i]][i]][epr[i]];
        #else
        epr_sym[op][ep_slice[ep][i]][epr[i]][i];
        #endif
    }
}

init_map(map, op_FR, op_UR, reflect)
     char map[CUBE_SYM][FACELETS], *op_FR, *op_UR, *reflect;
{
  int i;

  for (i=0; i < FACELETS; i++)
    map[0][i] = i;

  memcpy(map[1],  op_FR,FACELETS);	// FR1
  memcpy(map[21], op_UR,FACELETS);	// UR1
  sym_op(map[2],  map[1],  op_UR);	// FR1 UR1
  sym_op(map[3],  map[2],  op_UR);	// FR1 UR2
  sym_op(map[4],  map[3],  op_UR);	// FR1 UR3
  sym_op(map[5],  map[1],  op_FR);	// FR2
  sym_op(map[6],  map[5],  op_UR);	// FR2 UR1
  sym_op(map[7],  map[6],  op_UR);	// FR2 UR2
  sym_op(map[8],  map[7],  op_UR);	// FR2 UR3
  sym_op(map[9],  map[5],  op_FR); 	// FR3
  sym_op(map[10], map[9],  op_UR);	// FR3 UR1
  sym_op(map[11], map[10], op_UR);	// FR3 UR2
  sym_op(map[12], map[11], op_UR);	// FR3 UR3
  sym_op(map[13], map[2],  map[9]);	// UF1
  sym_op(map[14], map[13], op_UR);	// UF1 UR1
  sym_op(map[15], map[14], op_UR);	// UF1 UR2
  sym_op(map[16], map[15], op_UR);	// UF1 UR3
  sym_op(map[17], map[7],  map[13]);	// UF3
  sym_op(map[18], map[17], op_UR);	// UF3 UR1
  sym_op(map[19], map[18], op_UR);	// UF3 UR2
  sym_op(map[20], map[19], op_UR);	// UF3 UR3
  sym_op(map[22], map[21], op_UR);	// UR2
  sym_op(map[23], map[22], op_UR);	// UR3
  memcpy(map[24], reflect, FACELETS);

  for (i=25; i < CUBE_SYM; i++)
      sym_op(map[i], map[i-24], reflect);
}

sym_op(dst, src, op)
     char *dst, *src, *op;
{
  int i;

  for (i=0; i < FACELETS; i++) 
      dst[i] = src[op[i]];
}

init_p2_dist()
{
  // for P2 dist array, there are no nodes at odd # depths less than 15, so
  // use this to compress 22 values into 16 

  int i;
  int out[16]={0,2,4,6,8,10,12,14,15,16,17,18,19,20,21,22};
  int in[24]={0,0,1,0,2,0,3,0,4,0,5,0,6,0,7,8,9,10,11,12,13,14,15,0};

  for (i=0; i < 16; i++)
    p2_dist_out[i] = out[i];

  for (i=0; i < 24; i++)
    p2_dist_in[i] = in[i];
}

#if USE_EPR_MOV2 == 0
populate_epr_mov()
{
  int i, j, k, n, x, mv;
  char s[12]={0,1,2,3,0,1,2,3,0,0,0,0};
  char t[12], epr[3], eps_3c[12], eps_6c[12];

  for (mv=0; mv < MOVES; mv++)
      for (i=0; i < SLICE_PRM; i++)
	{
	  int_to_strp(ep_b3[slice_ep[i][2]], eps_3c, 11, 3);
	  
	  for (j=0; j < 24; j++)
	    {
	      int_to_perm(j, &s[8], 4);
	      mk_eps_6c(eps_6c, eps_3c, s);

	      for (k=x=0; k < 12; k++) 
		{
		  n = eps_6c[emv[mv][k]]-8;

		  if (n >= 0)
		    t[x++] = n;
		}

	      epr_mov[i][j][mv] =perm_to_int(t, 4); 
	    }
	}
  populated("epr_mov");
}
#endif

#if USE_EPR_MOV2
populate_epr_mov2()
{
  int i, j, k, ix, mv;
  char s[12]={0,1,2,3,0,1,2,3,0,1,2,3}; 
  char t[12], epr[3];
  char tmp_map[24], eps_3c[12], eps_6c[12];

  for (mv=0; mv < MOVES; mv++)
    {
      for (i=0; i < SLICE_PRM; i++)
	{
	  int_to_strp(ep_b3[slice_ep[i][2]], eps_3c, 11, 3);
	  
	  for (j=0; j < 24; j++)
	    {
	      int_to_perm(j, &s[8], 4);
	      mk_eps_6c(eps_6c, eps_3c, s);
	      
	      for (k=0; k < 12; k++)
		t[k] = eps_6c[emv[mv][k]]; 
	      
	      ep6c_epr(t, epr);
	      tmp_map[j] = epr[2];

	      if (j == 0)
		{
		  ix = tmp_map[0];
		  epr_mov_idx[i][mv] = ix;
		  
		  if (epr_mov2[ix][0] != 0)
		    break;
		}
	    }

	  if (epr_mov2[ix][0] == 0)
	    memcpy(epr_mov2[ix], tmp_map, 24);
	}
    }
  populated("epr_mov2");
  populated("epr_mov_idx");
}
#endif

update_cube_in(cube)
  struct s_cube *cube;
{
  cube->cp6c = perm_to_int(cube->cps,8);
  cube->ct = str_to_int(cube->cts,7,3);
  cube->ep = eps_to_ep3c(cube->eps);
  cube->et = str_to_int(cube->ets,11,2);
  ep6c_epr(cube->eps, cube->epr);
}

update_cube_out(cube)
     struct s_cube *cube;
{
  int_to_perm(cube->cp6c, cube->cps, 8);
  int_to_strp(cube->ct, cube->cts, 7, 3);
  make_eps(cube->eps, cube->ep, cube->epr);
  int_to_strp(cube->et, cube->ets, 11, 2);
}    


copy_cube(dst, src)
     struct s_cube *dst, *src;
{
  memcpy(dst->eps, src->eps, 12);
  memcpy(dst->ets, src->ets, 12);
  memcpy(dst->cps, src->cps, 8);
  memcpy(dst->cts, src->cts, 8);
  dst->cp6c = src->cp6c;
  dst->ct = src->ct;
  dst->ep = src->ep;
  dst->et = src->et;
  memcpy(dst->epr, src->epr, 3);
}

load_cube(fname, s)
     char *fname, *s;
{
  int n;

  open_file(fname, "r");
  n = load_cube_fp(fp, s);
  fclose(fp);
  return(n);
}

load_cube_fp(fp, s)
     FILE *fp;
     char *s;
{	
  int i, len;

  for (i=0; i < FACELETS; i++)
    {
      if (fscanf(fp, " %c", &s[i]) == EOF)
	break;
      s[i] = toupper(s[i]);
    }

  len = i;

  if (len > 0 && len < FACELETS)
    {
      printf("\nERROR: Incomplete Cube Entered (%d of 54 facelets):", len);
      printf("\n       Data Read: ");

      for (i=0; i < len; i++)
	printf("%c", s[i]);

      printf("\n");
    }

  return(i);
}

init_cube2(c)
     struct s_cube2 *c;
{
  c->ep = 0;
  c->et = 0;
  c->epr[0] = 0;
  c->epr[1] = 0;
  c->epr[2] = 0;
  c->cp6c = 0;
  c->cpt.min = 0;
  c->cpt.op = 0;
  // c->epi = &ep_info[0];
}

/****************************************************************************/

#if USE_CHK_DUP_6C
chk_dup_6c(ep, et, epr, cp, ct, n)
     int ep, et, epr, cp, ct, n;
{	
  int i, ept, cpt;
  static int cfg[CFG_LIST_6C][4];

  ept = ep*E_TWIST + et;
  cpt = cp*C_TWIST + ct;

  for (i=0; i < cfg_idx; i++)
    if (cfg[i][0] == ept && cfg[i][1] == epr && 
	cfg[i][2] == cpt && cfg[i][3] <= n)
      return(1);

  if (cfg_idx >= CFG_LIST_6C)
    {
      printf("ERROR: Max size exceeded in chk_dup_6c()\n");
      fflush(stdout);
      exit(1);
    }

  cfg[cfg_idx][0] = ept;
  cfg[cfg_idx][1] = epr;
  cfg[cfg_idx][2] = cpt;
  cfg[cfg_idx++][3] = n;

  return(0);
}
#endif

#if USE_GET_EPRSYM_M1
get_eprsym_m1(sym, epi, epr, op)
char *sym, *epr, op;
struct s_info *epi;
{
  sym[slice_map[op][0]] = epr_sym[op][epi->s0][epr[0]][0];
  sym[slice_map[op][1]] = epr_sym[op][epi->s1][epr[1]][1];
  sym[slice_map[op][2]] = epr_sym[op][epi->s2][epr[2]][2];
}
#endif

#if USE_GET_EPRSYM_M2
get_eprsym_m2(sym, epi, epr, op)
char *sym, *epr, op;
struct s_info *epi;
{
  sym[slice_map[op][0]] = epr_sym2[epr_idx[op][epi->s0][0]][epr[0]];
  sym[slice_map[op][1]] = epr_sym2[epr_idx[op][epi->s1][1]][epr[1]];
  sym[slice_map[op][2]] = epr_sym2[epr_idx[op][epi->s2][2]][epr[2]];
}
#endif

#if USE_GET_MIN_OP_E6C
get_min_op_e6c(c)
struct S_CUBE *c;
{	
  char eprsym[3], eprtmp[3];
  int i, n, dif, min_op;
  int oplist[CUBE_SYM];
  long long min, sym;
  struct s_info *epi;

  n = ept_min_ops[c->ops_idx][2];

  if (n == 47)
    {
	c->op = epr_min_op[EPR(c->epr)];
	return;
    }

  for (i=0; i < n; i++)
    oplist[i] = ept_min_ops[c->ops_idx][i+3];

  GET_EPRSYM(eprtmp, c->epi, c->epr, c->op_ept);

  #if (EP_SYM_METHOD == 1)
  epi = &ep_info[min_ep[c->epi->min]];
  #else
  epi = &ep_info[min_ep[c->epm.min]];
  #endif

  min = EPR(eprtmp);

  for (i=dif=0; i < n; i++)
    {
      GET_EPRSYM(eprsym, epi, eprtmp, oplist[i]);
      sym = EPR(eprsym);

      if (sym < min)
	{
	  min = sym;
	  min_op = oplist[i];
	  dif = 1;
	}
    }

  if (dif)
    c->op = op_op[c->op_ept][min_op];
}
#endif

#if USE_EPR_MIN_OP
populate_epr_min_op()
{
  int i, ix=0, op, min, min_op, EPRsym;
  struct s_info *epi;
  char epr[3], eprsym[3];

  epi = &ep_info[0];

  for (epr[0]=0; epr[0] < 24; epr[0]++)
    for (epr[1]=0; epr[1] < 24; epr[1]++)
      for (epr[2]=0; epr[2] < 24; epr[2]++)
	{
	  min = EPR(epr);
	  min_op = 0;

	  for (op=1; op < CUBE_SYM; op++)
	    {
	      GET_EPRSYM(eprsym, epi, epr, op);

	      EPRsym = EPR(eprsym);


	      if (EPRsym < min)
		{
		  min = EPRsym;
		  min_op = op;
		}
	    }

	  epr_min_op[ix++] = min_op;
	}

  populated("epr_min_op");
}
#endif

get_dist_type(n)
     int n;
{
  if (n == 0) 
    return('B');
  else if (n == 1) 
    return('Q');
  else
    return('H');
    
}

blank_arrays()
{
  /* this can be used to show that these arrays are not used in 
     the main search loop
  */
  printf("The following arrays have been blanked (zero filled):\n");
  blank_array("b2_cp",      b2_cp,      sizeof(b2_cp));
  blank_array("b2_slice",   b2_slice,   sizeof(b2_slice));
  blank_array("b3_ep",      b3_ep,      sizeof(b3_ep));
  blank_array("cmv",        cmv,        sizeof(cmv));
  blank_array("cp6c_cp3c",  cp6c_cp3c,  sizeof(cp6c_cp3c));
  blank_array("cp6c_min",   cp6c_min,   sizeof(cp6c_min));
  blank_array("cpt_min",    cpt_min,    sizeof(cpt_min));
  blank_array("emv",        emv,        sizeof(emv));
  blank_array("ep_b3",      ep_b3,      sizeof(ep_b3));
  blank_array("ep_min",     ep_min,     sizeof(ep_min));
  blank_array("ep_slice",   ep_slice,   sizeof(ep_slice));
  blank_array("epr_min_op", epr_min_op, sizeof(epr_min_op));
  blank_array("min_cp6c",   min_cp6c,   sizeof(min_cp6c));
  blank_array("pop_list",   pop_list,   sizeof(pop_list));
  blank_array("slice_ep",   slice_ep,   sizeof(slice_ep));
  if (!QTM)
    blank_array("seq_gen2",   seq_gen2,   sizeof(seq_gen2));
  printf("\n");
}

blank_array(name, arr, size)
char *name, *arr;
int size;
{
  int i;

  printf("%-10s %6d bytes\n", name, size);
  for (i=0; i < size; i++)
    arr[i] = 0;
}

#if SHOW_EPT_STATS
init_ept_stats(p)
int p;
{
 ept_min_op_count[p] = 0;
 get_min_op_count[p] = 0;  
 second_etsym_count[p] = 0;
}

show_ept_stats(p)
int p;
{
  if (nodes[p] == 0) 
    nodes[p] = 1;

  if (nodes_total[p] == 0)
    nodes_total[p] = nodes[p];

  printf("\n");
  printf("Phase %d stats:\n", p+1);
  printf("Nodes = %d\n", nodes_total[p]);
  printf("EP min op not uniq  = %8d   %5.4f   ", ept_min_op_count[p],
         (float)ept_min_op_count[p]/nodes_total[p]);
  printf("expected = .0594\n");

  printf("EPT min op not uniq = %8d   %5.4f   ", get_min_op_count[p], 
	 (float)get_min_op_count[p]/nodes_total[p]);
  printf("expected = .0024\n");

  if (EPT_OP_METHOD == 2)
    {
      printf("Second etsym op     = %8d   %5.4f   ", second_etsym_count[p], 
	     (float)second_etsym_count[p]/nodes_total[p]);
      printf("expected = .0334\n");
    }
  printf("\n");
}
#endif

/****************************************************************************/

#if USE_OP16C
init_op16c()
{
  int i, j, op1, op2;
  int op_new[CUBE_SYM];

  // symmetry operations that maintain consistent (1-to-1 mapping) corner
  // twist values for all corner configs:

  char op_ud[16] = {0,1,3,5,7,9,11,22,24,25,27,29,31,33,35,46};

  /* for the symmetry operations that are not consistent, make the
     equivalent from a pair of operations using one of either op_UFc or
     op_URc and one of the 16 consistent symmetries.  OP_UFc can be any sym
     op from the group that contains op UF (13, see func init_map), op 2
     was chosen because it yields smaller conversion tables (ct_uf &
     ct_uf_ix).  Likewise for the OP_URc group (contains op UR=21) of which
     op 20 was chosen (to make ct_ur & ct_ur_ix).

     non-consistent symmetry op groups:
     UF: 2, 4, 10, 12, 13, 15, 17, 19, 26, 28, 34, 36, 37, 39, 41,43
     UR  6, 8, 14, 16, 18, 20, 21, 23, 30, 32, 38, 40, 42, 44, 45, 47
  */

  for (i=0; i < 2; i++)
    {
      op1 = (i) ? OP_UFc: OP_URc;

      for (j=0; j < 16; j++)
	{
	  op2 = op_ud[j];
	  op16c[op_op[op1][op2]].op1 = op1;
	  op16c[op_op[op1][op2]].op2 = op2;
	}
    }

  for (i=0; i < 48; i++)
    op_new[i] = 0;

  for (i=j=0; i < 16; i++)
    op_new[op_ud[i]] = j++;

  for (i=0; i < CUBE_SYM; i++)
    {
      if (op16c[i].op1 == 0)
	op16c[i].op2 = op_new[i];
      else
	op16c[i].op2 = op_new[op16c[i].op2];
    }
}
#endif

show_populated()
{
  int i;

  for (i=0; i < pop_list_ix; i++)
    printf("%s\n", pop_list[i]);
}

populated(arr)
char *arr;
{
  int i;
  
  for (i=0; i < pop_list_ix; i++)
    if (strncmp(pop_list[i], arr, N_POP_WIDTH) == 0)
      break;

  if (i == N_POP_LIST)
    {
      printf("ERROR: POP_LIST must be increased\n");
      exit(1);
    }

  if (i == pop_list_ix)
    {
      if (SHOW_DEPENDENCY_MSGS)
	  printf("DEP: Adding %s\n", arr);

      strncpy(pop_list[i], arr, N_POP_WIDTH);
      pop_list_ix++;
    }
}

dependency(arr, func)
char *arr, *func;
{
  int i;

  if (SHOW_DEPENDENCY_MSGS)
    printf("DEP: Checking %s\n", arr);

  for (i=0; i < pop_list_ix; i++)
    if (strncmp(pop_list[i], arr, N_POP_WIDTH) == 0)
      return;

  printf("ERROR: prerequisite array [%s] is not populated\n", arr);
  printf("       caller: %s()\n", func);
  exit(1);
}

#if USE_CP6C_INFO
populate_cp6c_info()
{
  int i;

  for (i=0; i < C_PERM; i++)
    {
      cp6c_info[i].min = cp6c_min[i];
      cp6c_info[i].op = cp6c_min_op[i];
    }
}
#endif

show_methods()
{
  printf("  ET_SYM_METHOD    = %d\n", ET_SYM_METHOD);
  printf("  CT_SYM_METHOD    = %d\n", CT_SYM_METHOD);
  printf("  EP_SYM_METHOD    = %d\n", EP_SYM_METHOD);
  printf("  CP6C_SYM_METHOD  = %d\n", CP6C_SYM_METHOD);
  printf("  EPR_MOV_METHOD   = %d\n", EPR_MOV_METHOD);
  printf("  EPR_SYM_METHOD   = %d\n", EPR_SYM_METHOD);
  printf("  EPT_OP_METHOD    = %d\n", EPT_OP_METHOD);
}
