#define C_PERM          40320   /* 6C corner perms */
#define C_TWIST         2187    /* corner twist */
#define E_PRM           34650   /* 3C edge perms */
#define E_PRMr          13824   /* 6C/3C edge perms */
#define E_TWIST         2048    /* edge twist (flip) */
#define FACELETS        54

char	untwc[3]; 
char	cnr[8][3], edg[12][2];

struct s_cube
{
  char cps[8];
  char cts[8];
  char eps[12];
  char ets[12];
};
