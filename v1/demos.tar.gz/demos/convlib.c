/* Author: Michael Feather 

   This file contains generic routines for converting between strings & 
   integers and between permutations & integers, 
*/

char last_digit[5][4]={0,0,0,0, 0,0,0,0, 0,1,0,0, 0,2,1,0, 2,1,0,3};
int exp1[10][15];
int fac[15];

init_conv()
{
  int i, j;

  for (i=2; i <= 4; i++)
    {
      exp1[i][1]=i;

      for (j=2; j <= 12; j++) 
	exp1[i][j] = exp1[i][j-1]*i;
    }

  for (fac[2]=2, i=3; i <= 12; i++)
    fac[i] = i*fac[i-1];
}

int_to_str(n, s, len, base)
     char *s; 
     int n, len, base;
{
  int i, j; 

  for (i=0, j=exp1[base][len-1]; i < len; n%=j, j/=base, i++) 
    s[i] = (n/j);
}

int_to_strp(n, s, len, base)  /* add parity digit */
     char *s; 
     int n, len, base;
{
  int i, j; 

  for (i=0, j=exp1[base][len-1]; i < len; n%=j, j/=base, i++) 
    s[i] = (n/j);

  for (i=j=0; i < len; i++) 
    j += s[i]; 

  s[len] = last_digit[base][j%base];
}

int_to_str_lim(n, s, len, base, lim)
     char *s;
     int n, len, base;
{
  int i, j, ct[10];

  for (i=0; i < base; i++) 
    ct[i] = 0;

  for (i=0, j=exp1[base][len-1]; i < len; n%=j, j/=base, i++)
    {
      s[i] = (n/j);
      ct[s[i]]++;

      if (ct[s[i]] > lim)
	return(0);
    }

  for (i=0; i < base; i++) 
    if (ct[i] < lim) 
      s[len] = i;

  return(1);
}

int_to_perm(n, s, len)
     char *s;
     int n, len;
{
  int i, j, k;
  char tmp[15];

  for (i=0; i < len; i++) 
    tmp[i] = i;

  len--;

  for (i=0, j=fac[len]; i < len; n%=j, j/=(len-i), i++)
    {
      s[i] = tmp[n/j]; 
      for (k=n/j; k < len-i; k++)
	tmp[k] = tmp[k+1];
    }

  s[len] = tmp[0];
}

str_to_int(s, len, base)
     char *s;
{
  int i, n;

  n = s[0];

  for (i=1; i < len; i++)
    {
      n *= base;
      n += s[i];
    }

  return(n);
}

perm_to_int(s, len)
     char *s;
{
  int i, j, k, q, v;

  for (q=0, i=len-2, j=1; i > 0; i--)
    {
      j *= len-(i+1);

      for (v=0, k=i+1; k < len; k++)
	if (s[i] > s[k]) 
	  v++;

      q +=j*v;
    }

  j *= len-1;
  q += s[0] *j;
  return q;
}
