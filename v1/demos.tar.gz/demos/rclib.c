#include <stdio.h>
#include "rc.h"

/*         00 01 02
           03 04 05
           06 07 08
  09 10 11 12 13 14 15 16 17 18 19 20
  21 22 23 24 25 26 27 28 29 30 31 32
  33 34 35 36 37 38 39 40 41 42 43 44
           45 46 47
           48 49 50
           51 52 53
*/
char center_idx[6] = {4,22,25,28,31,49};

char cnr_idx[8][3] =
{ { 6, 12, 11}, {47, 38, 39}, {51, 44, 33}, { 2, 18, 17},
  {45, 35, 36}, { 8, 15, 14}, { 0,  9, 20}, {53, 41, 42}
};

char edg_idx[12][2] =
{ {24, 23}, {26, 27}, {30, 29}, {32, 21}, { 7, 13}, {46, 37},
  {52, 43}, { 1, 19}, { 3, 10}, { 5, 16}, {50, 40}, {48, 34}
};

set_colors_6c(r, f, u, l, b, d)
     char r, f, u, l, b, d;
{
  int i, j;

  /*
    Corners:	
    --------------------------------------
    Front   Back (looking thru cube)
    0 5     6 3
    4 1     2 7
    --------------------------------------
    1st digit = position
    2nd digit = twist (1 = clockwise, 2 = counter-clockwise)
            60  30   
            00  50   
    61  02  01  52  51  32  31  62 
    22  41  42  11  12  71  72  21
            40  10 
            20  70 
  */

  char cnr_loc[8][3] = 
    {{u, f, l}, {d, f, r}, {d, b, l}, {u, b, r},
     {d, l, f}, {u, r, f}, {u, l, b}, {d, r, b}};

  /*
    Edges:
    --------------------------------------
    Front      Middle      Back
      4        8   9         7   
    0   1                  3   2
      5        B   A         6
    --------------------------------------

    1st digit = position
    2nd digit = twist (0 = sane, 1 = flipped)
             70
           80  90
             40
      81     41     91     71
    31  01 00  10 11  21 20  30
      B1     51     A1     61
             50
           B0  A0
             60
  */

  char edg_loc[12][2] = 
    {{f, l}, {f, r}, {b, r}, {b, l}, {u, f}, {d, f},
     {d, b}, {u, b}, {u, l}, {u, r}, {d, r}, {d, l}};

  for (i=0; i < 8; i++)
    for (j=0; j < 3; j++)
      cnr[i][j] = cnr_loc[i][j];

  for (i=0; i < 12; i++)
    for (j=0; j < 2; j++)
      edg[i][j] = edg_loc[i][j];
}

parity(s, len)
     char *s, len;
{
  int i, n;
  char x, tmp[12];

  for (i = 0; i < len; i++) 
    tmp[i] = s[i];

  for (i=n=0; i < len; i++)
    while (tmp[i] != i)
      {	
	x = tmp[i];
	tmp[i] = tmp[x];
	tmp[x] = x;
	n++;
      }

  return(n%2);
}

make_cubestr(cubestr, cube)
     char *cubestr;
     struct s_cube *cube;
{
  int i, j;

  for  (i=0; i < 12; i++)
    for (j=0; j < 2; j++)
      cubestr[edg_idx[i][j]] = edg[cube->eps[i]][(cube->ets[i]+j)%2];

  for  (i=0; i < 8; i++)
    for (j=0; j < 3; j++)
      cubestr[cnr_idx[i][j]] = cnr[cube->cps[i]][(untwc[cube->cts[i]]+j)%3];
}

show_cubestr(s, f)
     char *s, f;
{	
  int i, j;

  if (f)
    {
      for (i=0; i < FACELETS; i++)
	printf("%c", s[i]);
      
      printf("\n");
      return;
    }

  for (i=0; i < 9; i+=3)
    printf("    %c%c%c\n",   s[i], s[i+1], s[i+2]);

  for (; i < 45; i+=12)
    {
      for (j=0;  j < 12; j+=3)
	printf("%c%c%c ", s[i+j], s[i+j+1], s[i+j+2]);
      printf("\n");
    }

  for (; i < 54; i+=3)
    printf("    %c%c%c\n",   s[i], s[i+1], s[i+2]);

  printf("\n");
}


